jQuery(document).ready(function($) {
    var page = 1;
    var maxPages = parseInt(loadmore_params.max_pages);
    
    if (maxPages == 1) {
    	$('#load-more').hide();
    }

    $('#load-more').on('click', function(e) {
        e.preventDefault();
        var $this = $(this);
        $this.text('Loading...');

        var data = {
            'action': 'loadmore',
            'query': loadmore_params.query,
            'page': page,
            'security': loadmore_params.security
        };

        $.ajax({
            url: loadmore_params.ajaxurl,
            data: data,
            type: 'POST',
            success: function(response) {
                if (response) {
                    $('#posts-container').append(response);
                    page++;

                    if (page == maxPages) {
                        $this.hide();
                    } else {
                        $this.text('Load more posts');
                    }
                } else {
                    $this.hide();
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });

        console.log(maxPages);
        console.log(page);
    });
});
