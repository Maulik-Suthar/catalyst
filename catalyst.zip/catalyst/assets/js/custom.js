//=====================================//
// Ready jQuery
//=====================================//
jQuery(document).ready(function ($) {
  $(".menu-icon").click(function () {
    $(this).toggleClass("menu-close");
    $(".navigation-bar").toggleClass("slide-menu");
    $("body").addClass("body-fixed");
  });
  $(".sidebar-overlay, .close-menu").click(function () {
    $(".menu-icon").removeClass("menu-close");

    $(".navigation-bar").removeClass("slide-menu");

    $("body").removeClass("body-fixed");
  });
  $(".navbar-main li:has(ul)").prepend('<span class="arrow"></span>');
  $(".arrow").click(function () {
    $(this).siblings("ul").slideToggle("slow");

    $(this).toggleClass("minus");
  });

  var header_height = $(".header-main").outerHeight();

  $(window).scroll(function () {
    if ($(this).scrollTop() > 350) {
      // $(".scrollTop").fadeIn();

      $(".header-main").addClass("has-sticky");
      $("body").addClass("sticky-header");
      $("body").css("padding-top", header_height);
    } else {
      // $(".scrollTop").fadeOut();

      $(".header-main").removeClass("has-sticky");
      $("body").removeClass("sticky-header");
      $("body").css("padding-top", 0);
    }

    var x = $(document).scrollTop();
    if (x > 100) {
      $(".back-to-top").addClass("active");
    } else {
      $(".back-to-top").removeClass("active");
    }
  });
  $(".back-to-top").click(function () {
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  });

  // home-slider
  if ($(".home-sliders").length) {
    var homeSlider = new Swiper(".home-sliders", {
      slidesPerView: 1,
      loop: true,
      speed: 1200,
      autoplay: {
        delay: 7000,
        disableOnInteraction: true,
      },
      pagination: {
        el: ".home-slide-pagination .swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".homeslide-arrow .swiper-button-next",
        prevEl: ".homeslide-arrow .swiper-button-prev",
      },
    });
  }

  // latest-sliders
  if ($(".latest-sliders").length) {
    var latestSlider = new Swiper(".latest-sliders", {
      loop: true,
      speed: 1000,
      autoplay: {
        delay: 2000,
        disableOnInteraction: true,
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        480: {
          slidesPerView: 1,
        },
        568: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
        1600: {
          slidesPerView: 4,
        },
      },
    });
  }

  // provide-sliders
  if ($(".provide-sliders").length) {
    var latestSlider = new Swiper(".provide-sliders", {
      loop: true,
      speed: 1000,
      autoplay: {
        delay: 2000,
        disableOnInteraction: true,
      },
      pagination: {
        el: ".provide-pagination .swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        480: {
          slidesPerView: 1,
        },
        568: {
          slidesPerView: 2,
        },
        768: {
          slidesPerView: 3,
        },
      },
    });
  }

  $(".location-collaborators-logo-slider").slick({
    speed: 5000,
    autoplay: true,
    autoplaySpeed: 0,
    centerMode: true,
    cssEase: "linear",
    slidesToShow: 1,
    slidesToScroll: 1,
    variableWidth: true,
    infinite: true,
    initialSlide: 1,
    arrows: false,
    buttons: false,
    focusOnSelect: false,
    pauseOnHover:false,
    pauseOnFocus: false 
  });

  $(".service-categories li:has(ul)").prepend('<span class="service-arrow"></span>');
  $(".service-arrow").click(function () {
    var $parentLi = $(this).parent("li");
    $(".service-categories li").not($parentLi).removeClass("show").find("ul").slideUp("slow");
    $(".service-categories li").not($parentLi).find(".service-arrow").removeClass("minus");
    $parentLi.toggleClass("show");
    $(this).toggleClass("minus");
    $(this).siblings("ul").slideToggle("slow");
  });

  $(".select-cat-button").click(function () {
    $(".service-categories").slideToggle();
    $(".select-cat-button").toggleClass("show");
  });

  var sections = $(".take-to-section");

  $(window).on("scroll", function () {
    var cur_pos = $(this).scrollTop();

    sections.each(function () {
      var top = $(this).offset().top - 150,
        bottom = top + $(this).outerHeight() - 50;

      if (cur_pos >= top && cur_pos <= bottom) {
        $(".go-to-section").removeClass("active");
        sections.removeClass("active");
        $(this).addClass("active");
        $('.go-to-section[href="#' + $(this).attr("id") + '"]').addClass("active");
      }
    });
  });

  $(".go-to-section").on("click", function () {
    var $el = $(this),
      id = $el.attr("href");
    $("html, body").animate(
      {
        scrollTop: $(id).offset().top - (header_height + 20),
      },
      500
    );

    return false;
  });

  // book-appointment-slider
  if ($(".book-appointment-slider").length) {
    var bookAppointmentSlider = new Swiper(".book-appointment-slider", {
      loop: true,
      centeredSlides: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      autoplay: {
        delay: 7000,
        disableOnInteraction: true,
      },

      breakpoints: {
        568: {
          slidesPerView: 2,
          spaceBetween: 15,
        },
        1024: {
          slidesPerView: 3,
          spaceBetween: 22,
        },
      },
    });
  }
  // newly-blog-slider
  if ($(".newly-blog-slider").length) {
    var newlyBlogSlider = new Swiper(".newly-blog-slider", {
      loop: true,
      slidesPerView: "auto",
      breakpoints: {
        568: {
          spaceBetween: 15,
        },
        1024: {
          spaceBetween: 24,
        },
      },
      navigation: {
        nextEl: ".newly-blog-arrow .swiper-button-next",
        prevEl: ".newly-blog-arrow .swiper-button-prev",
      },
    });
  }

  if ($(".medicare-parts-slider").length) {
    var medicareSlider = new Swiper(".medicare-parts-slider", {
      spaceBetween: 20,
      loop: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        640: {
          slidesPerView: 2,
        },
        1000: {
          slidesPerView: 3,
        },
        1280: {
          pagination: false,
          slidesPerView: 4,
        },
      },
    });
  }

  if ($(".testimonial-slider").length) {
    var testimonialSlider = new Swiper(".testimonial-slider", {
      loop: true,
      effect: "coverflow",
      //grabCursor: true,
      centeredSlides: true,
      coverflowEffect: {
        rotate: 0,
        stretch: 0,
        depth: 200,
        modifier: 3.5,
      },
      autoplay: false,
      // keyboard: {
      //   enabled: true,
      // },
      // mousewheel: {
      //   thresholdDelta: 70,
      // },
      spaceBetween: 30,
      breakpoints: {
        640: {
          slidesPerView: 1,
        },
        1024: {
          slidesPerView: 1.885,
        },
      },
      navigation: {
        nextEl: ".testimonial-arrow .swiper-button-next",
        prevEl: ".testimonial-arrow .swiper-button-prev",
      },
    });

    // Bind click event to.video-play buttons
    //   $(".testimonial-slider").on("click", ".video-play", function () {
    //     $(this).addClass("d-none");
    //     var iframeSrc = $(this).closest(".testimonial-box").data("video-url");
    //     var iframe = $(this).siblings("iframe");
    //     if (iframe.attr("src") === "") {
    //       iframe.attr("src", iframeSrc + "?autoplay=1");
    //     }
    //   });

    //   // Trigger click event on the current slide's.video-play button
    //   testimonialSlider.on("slideChange", function () {
    //     var activeSlide = $(
    //       testimonialSlider.slides[testimonialSlider.activeIndex]
    //     );
    //     var videoPlayButton = activeSlide.find(".video-play");
    //     var iframe = activeSlide.find("iframe");

    //     if (videoPlayButton.hasClass("d-none")) {
    //       // Resume video playback
    //       iframe.attr("src", iframe.attr("src") + "&autoplay=1");
    //     } else {
    //       videoPlayButton.trigger("click");
    //     }
    //   });
    //   testimonialSlider.slideTo(1, false, false);
    // }
    testimonialSlider.on("slideChange", function () {
      var iframes = $(testimonialSlider.slides).find("iframe");

      iframes.each(function () {
        var iframe = $(this);
        var player = iframe[0].contentWindow;
        if (player && typeof player.postMessage === "function") {
          player.postMessage('{"method":"pause"}', "*");
        }
      });
    });
    //testimonialSlider.slideTo(1, false, false);
    $(".testimonial-sec .swiper-button-next").trigger("click");
  }
  $(".video-play").on("click", function () {
    $(this).addClass("d-none");
    var iframeSrc = $(this).closest(".testimonial-box").data("video-url");
    var iframe = $(this).siblings("iframe");
    if (iframe.attr("src") === "") {
      iframe.attr("src", iframeSrc + "?autoplay=1");
    }
  });

  $(".selectFilter").click(function () {
    $(this).next().slideToggle();
    // $(this).toggleClass("active");
  });
  $(".selectFilter").text($(".filterDropdown li .active").text());

  // Note : This code is important
  // $(".video-play").on("click", function () {
  //   $(this).addClass("d-none");
  //   var iframeSrc = $(this).closest(".testimonial-box").data("video-url");
  //   var iframe = $(this).siblings("iframe")[0]; // Get the iframe element
  //   iframe.contentWindow.location.href = iframeSrc + "?autoplay=1";
  // });

  $(".filter-toggle-btn button, .filter-toggle-btn > .filter-box-title").on("click", function (event) {
    event.stopPropagation();
    $(".filter-toggle-btn").toggleClass("active");
  });

  $(document).on("click", function (event) {
    if (!$(event.target).closest(".filter-toggle-btn").length) {
      $(".filter-toggle-btn").removeClass("active");
    }
  });



  //add
  $('.filter-wrap .filter-dropdown input[type="radio"]').on("change", function () {
    var selectedLabel = $(this).next("label").text();
    $(".filter-wrap .filter-box-title").text(selectedLabel);
    $(".filter-toggle-btn").removeClass("active");
  });

  // $(".with-scrollbar").niceScroll({
  //   cursorwidth: "7px",
  //   cursorborder: "none",
  //   cursorcolor: "#cccccc",
  //   background: "#EFEFEF",
  //   autohidemode: false,
  //   railpadding: { top: 0, right: 0, left: 0, bottom: 0 },
  // });

  $(".find-location-filter-btn").click(function () {
    $(this).toggleClass("active");
    $(".find-location-filter").toggleClass("active");
    // $(".with-scrollbar").getNiceScroll().resize();
  });

  $(document).click(function (e) {
    if (!$(e.target).is('.find-location-filter-btn,.find-location-filter-btn *')) {
      $(".find-location-filter-btn").removeClass('active');
      $(".find-location-filter").removeClass('active');
    }
  });

  $(".filter-box .filter-dropdown input").on("change", function (e) {
    $(".filter-box #search").val("");
  });


  $(".btn-dropdown-booknow").click(function () {
    $(".btn-dropdown-booknow").removeClass('active');
    $(this).toggleClass("active");
  });

  $(document).click(function (e) {
    if (!$(e.target).is('.btn-dropdown-booknow,.btn-dropdown-booknow *,.profile-btn-dropdown, .profile-btn-dropdown *')) {
      $(".btn-dropdown-booknow").removeClass('active');
    }
  });

});

//=====================================//
// On Load jQuery
//=====================================//
jQuery(window).on("load", function () {
  if (jQuery(window).width() > 1024) {
    jQuery(".with-scrollbar").mCustomScrollbar({
      scrollbarPosition: "outside",
      scrollInertia: 100,
      mouseWheelPixels: 100,
    });
  }
  // jQuery(document).on('click', '.serviceBtn', function () {
  //   jQuery(".service-modal-content .cms-con").mCustomScrollbar("destroy");
  //   setTimeout(function(){
  //     jQuery(".service-modal-content .cms-con").mCustomScrollbar({
  //       scrollbarPosition: "outside",
  //     });
  //   },100);
  // });
});
