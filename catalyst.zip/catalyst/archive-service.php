<?php /* Template Name: Our Services */
// global $display_service_post;
get_header(); ?>

<div class="page-head">
    <div class="container-fluid">
        <div class="sec-head">
            <h1 class="sec-title">Our Services</h1>
        </div>
    </div>
</div>

<section class="our-services">
    <div class="container-fluid">
        <div class="row">
            <?php // get_sidebar('service'); 
            ?>
            <div class="col-md-12">
                <div class="services-inner">
                    <?php
                    $service_args = array(
                        'post_type'      => 'service',
                        'posts_per_page' => '-1',
                        'orderby' => 'title',
                        'order'   => 'ASC',
                    );

                    $service_loop = new WP_Query($service_args);
                    while ($service_loop->have_posts()) : $service_loop->the_post(); ?>
                        <div class="services-row row wow animate__fadeInUp serviceBx" data-wow-delay="0.1s">
                            <div class="col-sm-5">
                                <div class="services-left">
                                    <div class="services-img">
                                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php echo get_the_title(get_the_id()); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="services-con">
                                    <div class="sec-head">
                                        <div class="sec-title"><?php echo get_the_title(get_the_id()); ?></div>
                                        <div class="service-content">
                                            <?php $content = apply_filters('the_content', get_the_content()); ?>
                                            <div class="cms-con">
                                                <?php echo $content; ?>
                                            </div>
                                            <?php /*
                                            id = "content-<?php echo get_the_id(); ?>"
                                            $content = apply_filters('the_content', get_the_content()); ?>
                                            <div class="service-02">
                                                <div class="cms-con">
                                                    <?php echo $content; ?>
                                                </div>
                                            </div>
                                            */ ?>
                                        </div>
                                    </div>
                                    <button class="learn-toggle-button learn-more-btn serviceBtn" data-bs-toggle="modal" data-bs-target="#serviceModal">Learn more<span></span></button>
                                    <!-- <button class="learn-toggle-button learn-more-btn serviceBtn" data-target="content-<?php //echo get_the_id(); 
                                                                                                                            ?>">Learn more<span></span></button> -->
                                </div>
                            </div>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- <div class="modal service-modal fade" id="serviceModal">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0 p-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="row g-0">
                    <div class="col-lg-5">
                        <div class="service-img-box">
                            <img src="" alt="">
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="service-modal-content">
                            <div class="sec-head mb-0">
                                <h3 class="sec-title"></h3>
                            </div>
                            <div class="cms-con"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->
<?php get_footer(); ?>
<script>
    jQuery(document).ready(function($) {
        $('.serviceBtn').click(function() {
            var title = $(this).prev('.sec-head').find('.sec-title').text();
            var content = $(this).prev('.sec-head').find('.cms-con').html();
            var imgSrc = $(this).parents('.services-row').find('img').attr('src');
            $('.modal').find('.sec-title').text(title);
            $('.modal').find('.cms-con').html(content);
            $('.modal').find('img').attr('src', imgSrc);
        });
        // const serviceContents = $('.service-content');
        // serviceContents.each(function() {
        //     $(this).css('--contentHeight', $(this).prop('scrollHeight') + 'px');
        //     var animtionTime = $(this).prop('scrollHeight') / 500;
        //     if (animtionTime <= 1) {
        //         animtionTime = 1;
        //     }
        //     $(this).css('--contentanimtion', animtionTime + 's');
        //     if ($(this).prop('scrollHeight') > 80) {
        //         $(this).addClass('short-content');
        //     } else {
        //         $(this).parent().next('.learn-toggle-button').addClass('d-none');
        //     }
        // });

        // $('.learn-toggle-button').click(function() {
        //     var contentId = $(this).attr('data-target');
        //     var content = $('#' + contentId);
        //     var button = $(this);
        //     content.toggleClass('long-content');
        //     if (content.hasClass('long-content')) {
        //         content.toggleClass('short-content');
        //     } else {
        //         setTimeout(function() {
        //             content.toggleClass('short-content');
        //         }, 900)
        //     }

        //     button.toggleClass('learn-toggle-button Learn-less');

        //     button.html(button.hasClass('Learn-less') ? 'Learn Less <span></span>' : 'Learn More <span></span>');
        // });
    });
</script>