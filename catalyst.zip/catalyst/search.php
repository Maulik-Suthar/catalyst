<?php

/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package catalyst
 */

get_header();
?>


<div class="search-title text-center common-sec">
	<div class="sec-head">
		<h2 class="sec-title">Blog</h2>
	</div>
</div>

<section class="blog-listing common-sec pt-0">
	<div class="container">
		<div class="blog-listing-filter">

			<form role="search" method="get" class="search-form" action="<?php echo site_url(); ?>">
				<div class="blog-listing-filter-search filter-box wow animate__fadeInUp">
					<input class="form-control border-0 bg-transparent search-field" type="search" placeholder="Search for a Post" value="<?php echo get_search_query(); ?>" name="s">
					<input type="hidden" name="post_type" value="post">
					<button type="submit" class="btn-square btn-blue search-submit"><i class="icon-search"></i></button>
				</div>
			</form>

			<div class="blog_category position-relative">
				<span class="selectFilter d-md-none">Select Category</span>
				<ul class="filterDropdown">
					<li><a class="blogcate_btn active" href="<?php echo get_permalink(get_option('page_for_posts')); ?>" title="All Posts">All Posts</a></li>
					<?php
					$categories = get_categories();
					$queried_object = get_queried_object_id();
					foreach ($categories as $category) {  ?>
						<li><a class="blogcate_btn <?php if ($queried_object == $category->term_id) echo 'active'; ?>" href="<?php echo get_category_link($category->term_id); ?>"><?php echo $category->name; ?></a></li>
					<?php } ?>
				</ul>
			</div>

		</div>
	</div>
	<div class="container-fluid" id="blogListing">

		<?php
		if (have_posts()) :
			echo '<div id="posts-container" class="row justify-content-center">';
			while (have_posts()) : the_post();
				echo '<div class="col-xxl-3 col-xl-4 col-lg-3 col-lg-4 col-sm-6">';
				get_template_part('template-parts/content', 'post');
				echo '</div>';
			endwhile;
			wp_reset_postdata();
			echo '</div>';
		else :
			get_template_part('template-parts/content', 'none');
		endif;
		?>
		<div class="row">
			<div class="col-12 text-center">
				<button id="load-more" type="button" class="btn-link btn-dark wow animate__fadeInUp" data-wow-delay=".1s">Load more posts</button>
			</div>
		</div>

	</div>
</section>


<script>
	document.addEventListener("DOMContentLoaded", function() {
		// Parse query string
		const queryString = window.location.search;
		const urlParams = new URLSearchParams(queryString);
		const filter = urlParams.get('s');
		if (filter) {
			jQuery(window).scrollTop(jQuery("#blogListing").offset().top - 160);
		}
	});
</script>
<?php
// get_sidebar();
get_footer();
