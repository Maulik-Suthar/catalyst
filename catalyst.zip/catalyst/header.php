<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package catalyst
 */
$path = get_stylesheet_directory_uri();
$version = 1.9;
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Permissions-Policy" content="geolocation=(self 'https://maps.googleapis.com')">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $path ?>/assets/img/favicon.png" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/slick.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/animate.compat.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/swiper-bundle.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/mCustomScrollbar.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/theme-icons.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/style.css?v=<?php echo $version; ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/responsive.css?v=<?php echo $version; ?>">

    <!-- extra css -->
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/new-style.css?v=<?php echo $version; ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $path; ?>/assets/css/c-style.css?v=<?php echo $version; ?>">
</head>

<body <?php body_class(); ?>>
    <div class="loader-wrapper d-none">
        <div class="loader">
            <div class="loader-inner">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <?php wp_body_open(); ?>
    <div class="wrapper">

        <header class="header-main">
            <div class="container-fluid">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto col-sm-4 col-lg-2">
                        <a class="site-logo" href="<?php echo site_url(); ?>" title="<?php echo bloginfo('name'); ?>">
                            <?php
                            $header_logo = get_field('logo', 'option');
                            if (!empty($header_logo)) {
                            ?>
                                <img src="<?php echo $header_logo['url']; ?>" alt="<?php echo bloginfo('name'); ?>">
                            <?php
                            } else {
                            ?>
                                <img src="<?php echo $path; ?>/assets/img/logo.svg" alt="<?php echo bloginfo('name'); ?>" />
                            <?php } ?>
                        </a>
                    </div>
                    <div class="col-auto col-sm-8 col-lg-10">
                        <div class="sidebar-overlay"></div>
                        <div class="d-flex align-items-center head-right">
                            <div class="navigation-bar">
                                <nav class="navbar-main">
                                    <div class="mb-menu-logo">
                                        <a class="menu-logo" href="<?php echo site_url(); ?>" title="<?php echo bloginfo('name'); ?>">
                                            <?php
                                            $header_logo = get_field('logo', 'option');
                                            if (!empty($header_logo)) { ?>
                                                <img src="<?php echo $header_logo['url']; ?>" alt="<?php echo bloginfo('name'); ?>">
                                            <?php } else { ?>
                                                <img src="<?php echo $path; ?>/assets/img/logo.svg" alt="<?php echo bloginfo('name'); ?>" />
                                            <?php } ?>
                                        </a>
                                        <span class="close-menu"></span>
                                    </div>
                                    <div class="nav-menu-main">
                                        <?php wp_nav_menu(array(
                                            'menu_id'        => 'top-menu',
                                            'menu'            => 'Top Menu',
                                            'container'       => '',
                                            'container_class' => 'mainMenu',
                                            'container_id'    => '',
                                            'menu_class'      => '',
                                            'menu_id'         => '',
                                            'fallback_cb'     => 'wp_page_menu',
                                            'before'          => '',
                                            'after'           => '',
                                            'link_before'     => '',
                                            'link_after'      => '',
                                            'items_wrap'      => '<ul>%3$s</ul>',
                                        )); ?>
                                    </div>
                                </nav>
                            </div>
                            <?php
                            $book_now_btn = get_field('book_now_btn', 'option');
                            if (!empty($book_now_btn)) { ?>
                                <a href="<?php echo $book_now_btn['url']; ?>" target="<?php echo $book_now_btn['target']; ?>" class="head-btn btn btn-orange"><?php echo $book_now_btn['title']; ?></a>
                            <?php } ?>
                            <div class="menu-icon"><span></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>