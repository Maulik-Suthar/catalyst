<?php
get_header();
$path = get_stylesheet_directory_uri();
$pageId = get_the_ID();
$loc_title = get_the_title($pageId);
$google_business_name = get_field('google_business_name', $pageId);
$loc_logo = get_field('clinic_logo', $pageId);
$loc_logo_final = get_term_meta($loc_logo, 'logo', true);
$loc_imgs = get_field('clinic_image', $pageId);
$loc_address = get_field('address', $pageId);
$loc_city = get_field('city', $pageId);
$loc_state = get_field('state', $pageId);
$loc_zipcode = get_field('zipcode', $pageId);
$loc_phone = get_field('phone', $pageId);
$loc_fax = get_field('fax', $pageId);
$loc_website = get_field('website_url', $pageId);
$serviceIds = get_field('select_services', $pageId);
$blogIds = get_field('select_blog', $pageId);
// $boking_url = get_field('boking_url', $pageId);

$book_online_link = get_field('boking_url', $pageId);
$book_online_link_2 = get_field('book_online_location_second', $pageId);

$patient_portal_link = get_field('patient_portal_link', 'option');
$select_display_reviews = get_field('select_display_reviews');


$review_location_zero = get_field('review_location_zero', $pageId);
$reviewActive = '';
$elfsight_reviews = get_field('elfsight_location');
if (!$review_location_zero) {
    if ($elfsight_reviews) {
        $reviewActive = $elfsight_reviews;
    } else {
        $reviewActive = '';
    }
}

// print_r($loc_logo);
//$opening_hours = get_field('opening_hours', $pageId);

$welcome_content = get_field('welcome_content', $pageId);
$welcome_img = get_field('welcome_img', $pageId);
$insurance_content = get_field('insurance_content', $pageId);

$insurance_cats = get_terms(array(
    'taxonomy' => 'insurance_categories',
    'object_ids' => $pageId,
    'hide_empty' => false,
));


$placeId = get_field('place_id', $pageId);
// $places_details = fetch_google_place_details();
// $rating = $places_details[$placeId]['rating'];
// $ratingTotal = $places_details[$placeId]['user_ratings_total'];


// $citydata = get_locations_metafileds('location','city');
// print_r($citydata);
// echo '<br/><br/><br/>';
// $assd = get_locations_metafileds_to_ids('location','city','Ahmedabad');
// echo '<pre>';
// print_r($assd);

// $workingHours = array(
//     'Monday' => get_field('Monday', $post->ID),
//     'Tuesday' => get_field('Tuesday', $post->ID),
//     'Wednesday' => get_field('Wednesday', $post->ID),
//     'Thursday' => get_field('Thursday', $post->ID),
//     'Friday' => get_field('Friday', $post->ID),
//     'Saturday' => get_field('Saturday', $post->ID),
//     'Sunday' => get_field('Sunday', $post->ID)
// );

// foreach ($workingHours as $day => $schedule) {
//     echo "<div class='time-row'><span>{$day}:</span> ";
//     if (!empty($schedule['hour']['start']) && !empty($schedule['hour']['end']) || !empty($schedule['after_hour']['start']) && !empty($schedule['after_hour']['end'])) {
//         if (!empty($schedule['hour']['start']) && !empty($schedule['hour']['end'])) {
//             echo "{$schedule['hour']['start']} - {$schedule['hour']['end']}";
//         }
//         if (!empty($schedule['after_hour']['start']) && !empty($schedule['after_hour']['end'])) {
//             echo "<br/>{$schedule['after_hour']['start']} - {$schedule['after_hour']['end']}";
//         }
//     } else {
//         echo "Closed";
//     }
//     echo "</div>";
// }
?>



<section class="book-appointment-sec common-sec pb-0">
    <div class="container">
        <div class="book-appointment-con">
            <?php if (!empty($loc_logo)) : ?>
                <div class="book-appointment-logo">
                    <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
                </div>
            <?php endif; ?>

            <div class="sec-head">
                <h1 class="sec-title wow animate__fadeInUp mb-0">Welcome to <?php echo $loc_title; ?></h1>
            </div>
            <div class="btn-wrap">
                <?php /*if (!empty($boking_url)) : ?>
                    <a href="<?php echo $boking_url['url']; ?>" target="<?php echo (!empty($boking_url['target'])) ? $boking_url['target'] : '_self'; ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay=".1s">Book Online</a>
                <?php endif; */ ?>

                <?php if (!empty($book_online_link_2)) : ?>
                    <div class="profile-btns wow animate__fadeInUp" data-wow-delay="0.5s">
                        <button title="Book Online" class="btn btn-orange mx-auto btn-dropdown-booknow">Book Online</button>
                        <div class="profile-btn-dropdown">
                            <?php if (!empty($book_online_link)) : ?>
                                <a href="<?php echo $book_online_link['url']; ?>" target="<?php echo ($book_online_link['target'] != '') ? $book_online_link['target'] : '_self'; ?>" title="Normal Hours">Normal Hours</a>
                            <?php endif; ?>
                            <?php if (!empty($book_online_link_2)) : ?>
                                <a href="<?php echo $book_online_link_2['url']; ?>" target="<?php echo ($book_online_link_2['target'] != '') ? $book_online_link_2['target'] : '_self'; ?>" title="Extended Hours">Extended Hours</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else : ?>
                    <?php if (!empty($book_online_link)) : ?>
                        <div class="profile-btns  wow animate__fadeInUp" data-wow-delay="0.5s">
                            <a href="<?php echo $book_online_link['url']; ?>" target="<?php echo ($book_online_link['target'] != '') ? $book_online_link['target'] : '_self'; ?>" title="Book Online" class="btn btn-orange mx-auto">Book Online</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>


                <?php if (!empty($loc_phone)) : ?>
                    <a href="tel:<?php echo str_replace(array(' ', '-'), '', $loc_phone); ?>" title="Call Now" class="btn btn-outline-orange wow animate__fadeInUp" data-wow-delay=".2s">Call: <span class="text-decoration-underline"><?php echo $loc_phone; ?></span></a>
                <?php endif; ?>
            </div>
        </div>
        <div class="book-appointment-slider swiper position-relative wow animate__fadeInUp">
            <div class="swiper-wrapper">
                <?php
                if ($loc_imgs) :
                    foreach ($loc_imgs as $image) : ?>
                        <div class="swiper-slide">
                            <div class="swiper-slide-img">
                                <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                            </div>
                        </div>
                <?php
                    endforeach;
                endif;
                ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
</section>
<section class="location-detail-sec common-sec">
    <div class="container">
        <div class="location-inner">
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="location-detail-box wow animate__fadeInUp">
                        <div class="location-detail-box-icon">
                            <img src="<?php echo $path; ?>/assets/img/location.svg" alt="location-icon">
                        </div>
                        <div class="location-detail-box-con">
                            <div class="location-detail-box-title">Location:</div>
                            <p>
                                <?php echo $loc_title; ?> </br>
                                <?php echo $loc_address; ?>
                            </p>
                            <p><?php echo $loc_city; ?>, <?php echo $loc_state; ?> <?php echo $loc_zipcode; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="location-detail-box location-phone-cal wow animate__fadeInUp" data-wow-delay=".2s">
                        <div class="location-detail-box-icon">
                            <img src="<?php echo $path; ?>/assets/img/phone.svg" alt="phone-icon">
                        </div>
                        <div class="location-detail-box-con style-2">
                            <?php if (!empty($loc_phone)) : ?>
                                <p><span>Phone:</span> <a href="tel:<?php echo str_replace(array(' ', '-'), '', $loc_phone); ?>" title="Call Now"><?php echo $loc_phone; ?></a></p>
                            <?php endif; ?>
                            <?php if (!empty($loc_fax)) : ?>
                                <p><span>Fax:</span> <a href="javascript:;"><?php echo $loc_fax; ?></a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="location-detail-box location-hour-col wow animate__fadeInUp" data-wow-delay=".3s">
                        <div class="location-detail-box-icon">
                            <img src="<?php echo $path; ?>/assets/img/hours.svg" alt="hours-icon">
                        </div>
                        <div class="location-detail-box-con">
                            <div class="location-detail-box-title"><?php echo $loc_title; ?> Hours:</div>
                            <!-- <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p> -->
                            <?php get_opening_hours($pageId); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center">
            <?php if (!empty($patient_portal_link)) : ?>
                <a href="<?php echo $patient_portal_link['url']; ?>" target="<?php echo ($patient_portal_link['target'] != '') ? $patient_portal_link['target'] : '_self'; ?>" title="Patient Portal" class="btn btn-yellow wow fadeInUp" data-wow-delay="0.3s">Patient Portal</a>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php
include get_template_directory() . '/inc/custom-location.php';
?>

<section class="about-village-sec common-sec">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-7 col-md-7 col-lg-8">
                <div class="about-village-con">
                    <div class="sec-head">
                        <h2 class="sec-title mb-0 wow animate__fadeInUp"><?php echo $loc_title; ?></h2>
                    </div>
                    <div class="cms-con wow animate__fadeInUp" data-wow-delay=".1s">
                        <?php echo $welcome_content; ?>
                    </div>
                </div>
            </div>
            <?php if (!empty($welcome_img)) : ?>
                <div class="col-sm-5 col-md-5 col-lg-4">
                    <div class="about-village-img d-inline-block wow animate__fadeInRight" data-wow-delay=".2s">
                        <?php echo wp_get_attachment_image($welcome_img, 'full'); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
$args = array(
    'post_type'      => 'provider',
    'posts_per_page' => '-1',
    'meta_query'     => array(
        array(
            'key'   => 'location',
            'value' => $pageId,
            'compare' => 'like'
        )
    ),
    'meta_key' => 'last_name',
    'orderby' => 'meta_value',
    'order'   => 'ASC',
);
$loop = new WP_Query($args);
if ($loop->have_posts()) :
?>
    <section class="providers-sec common-sec leadership-sec">
        <div class="container">
            <div class="sec-head text-center">
                <h3 class="sec-title mb-0 wow animate__fadeInUp" data-wow-delay=".1s">Learn more about the providers at<br> <?php echo get_the_title(); ?></h3>
            </div>
            <div class="accordion" id="leadershipAccordion">
                <?php
                while ($loop->have_posts()) : $loop->the_post();
                    get_template_part('template-parts/content', 'provider');
                endwhile;
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php
if ($serviceIds) {

    $service_args = array(
        'post_type'      => 'service',
        'posts_per_page' => '-1',
        'orderby' => 'title',
        'order'   => 'ASC',
        'post__in' => $serviceIds,
    );
    $service_loop = new WP_Query($service_args);
    if ($service_loop->have_posts()) :
?>
        <section class="services-sec common-sec bg-grey">
            <div class="container">
                <div class="sec-head text-center">
                    <h4 class="sec-title mb-0 wow animate__fadeInUp">Services:<br> <?php echo $loc_title; ?></h4>
                </div>

                <div class="services-boxes">
                    <?php while ($service_loop->have_posts()) : $service_loop->the_post(); ?>
                        <div class="services-row row wow animate__fadeInUp serviceBx" data-wow-delay="0.1s">
                            <div class="col-sm-5">
                                <div class="services-left">
                                    <div class="services-img">
                                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="service-img">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="services-con">
                                    <div class="sec-head">
                                        <h3 class="sec-title"><?php echo get_the_title(get_the_id()); ?></h3>
                                        <div class="service-content">
                                            <?php $content = apply_filters('the_content', get_the_content()); ?>
                                            <div class="cms-con">
                                                <?php echo $content; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="learn-toggle-button learn-more-btn serviceBtn" data-bs-toggle="modal" data-bs-target="#serviceModal">Learn more<span></span></button>
                                    <!-- <button class="learn-toggle-button learn-more-btn serviceBtn" data-target="content-<?php //echo get_the_id(); 
                                                                                                                            ?>">Learn more<span></span></button> -->
                                </div>
                            </div>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata(); ?>
                    <!-- <div class="text-center services-view-all">
                        <a href="<?php echo site_url(); ?>/services/" class="btn btn-yellow wow animate__fadeInUp" data-wow-delay="0.5s">View All</a>
                    </div> -->
                </div>
            </div>
        </section>
<?php endif;
} ?>


<?php if ($blogIds) { ?>
    <section class="latest-blog common-sec pb-0">
        <div class="container-fluid">
            <div class="sec-head text-center border-bottom-0">
                <h4 class="sec-title wow animate__fadeInUp">Blog:<br> <?php echo $loc_title; ?></h4>
            </div>
            <div class="latest-sliders swiper position-relative">
                <div class="swiper-wrapper">
                    <?php
                    $count = 1;
                    $args = array('post__in' => $blogIds, 'post_type' => 'post', 'order' => 'ASC');
                    $recent_posts = get_posts($args);
                    foreach ($recent_posts as $post) {
                    ?>
                        <div class="swiper-slide">
                            <div class="news-col">
                                <?php get_template_part('template-parts/content', 'post'); ?>
                            </div>
                        </div>
                    <?php } ?>
                    <?php wp_reset_query(); ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>
<?php } ?>


<?php if (!empty($insurance_cats) && !is_wp_error($insurance_cats)) : ?>
    <section class="insurance-sec common-sec">
        <div class="container">
            <div class="sec-head text-center wow animate__fadeInUp">
                <div class="sec-title">Insurance</div>
                <?php echo $insurance_content; ?>
            </div>
            <div class="insurance-boxes">
                <div class="row justify-content-center align-items-center">
                    <?php
                    foreach ($insurance_cats as $insurance_cat) {
                        $insurance_logo = get_field('logo', 'insurance_categories_' . $insurance_cat->term_id);
                        if (!empty($insurance_logo)) { ?>
                            <div class="col-lg-3 col-6">
                                <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".2s">
                                    <img src="<?php echo esc_url($insurance_logo['url']); ?>" alt="<?php echo $insurance_logo['alt']; ?>">
                                </div>
                            </div>
                    <?php }
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if ($reviewActive != '') : ?>
    <section class="write-review-sec common-sec position-relative" id="<?php echo $placeId; ?>">
        <div class="container-fluid">
            <div class="write-review-con wow animate__fadeInUp">
                <div class="write-review-box d-flex align-items-center justify-content-between">
                    <div class="write-review-img">
                        <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
                    </div>
                    <div class="loc_result">
                        <?php echo $reviewActive; ?>
                    </div>
                </div>
                <?php if (!empty($placeId)) : ?>
                    <div class="text-center">
                        <a href="https://search.google.com/local/writereview?placeid=<?php echo $placeId; ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay=".1s" target="_blank">Write Review</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
get_footer();
?>