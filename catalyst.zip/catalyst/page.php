<?php

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */

get_header();
?>
<section class="cms-sec style-3">
	<div class="container-fluid">
		<?php
		while (have_posts()) :
			the_post();
		?>
			<div class="sec-head">
				<h1 class="sec-title"><?php the_title(); ?></h1>
				<span class="date">Last updated: May 2024</span>
			</div>
			<div class="cms-con">
				<?php the_content(); ?>
			</div>
		<?php
		endwhile;
		?>
	</div>
</section>
<?php
// get_sidebar();
get_footer();
