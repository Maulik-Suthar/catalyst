<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package catalyst
 */

get_header();
?>

<?php while (have_posts()) : the_post(); ?>
    <section class="blog-details-sec common-sec">
        <div class="container-fluid">
            <div class="sec-head">
                <h1 class="sec-title wow animate__fadeInUp"><?php the_title('') ?></h1>
                <?php /*
            <p class="wow animate__fadeInUp" data-wow-delay=".1s">                
                <?php
                    $excerpt = get_the_excerpt(); 
                    $excerpt = substr($excerpt, 0, 160);
                    if (strlen($excerpt) > 120) {
                        $excerpt = substr($excerpt, 0, strrpos($excerpt, ' ')) . '...';
                    }
                    echo $excerpt;
                    ?>
              </p> */ ?>
            </div>
            <div class="blog-details-info wow animate__fadeInUp" data-wow-delay=".2s">
                <?php /*
                $categories = get_the_category();
                if (!empty($categories) && $categories[0]->name !== 'Uncategorized') {
                ?>
                    <span>
                        <?php echo esc_html($categories[0]->name); ?>
                    </span>
                <?php
                }
                */ ?>
                <span><?php catalyst_posted_on(); ?></span>
            </div>
            <?php if (has_post_thumbnail()) { ?>
                <div class="blog-details-img wow animate__fadeInUp" data-wow-delay=".3s">
                    <?php the_post_thumbnail('full'); ?>
                </div>
            <?php } ?>
            <div class="blog-details-con wow animate__fadeInUp" data-wow-delay=".1s">
                <div class="row">
                    <div class="col-xl-9 col-lg-8">
                        <div class="cms-con style-2">
                            <?php the_content(); ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4">
                        <div class="blog-details-recent">
                            <div class="row">
                                <?php
                                $args = array(
                                    'post_type'      => 'post',
                                    'posts_per_page' => '3',
                                    'post__not_in' => array(get_the_ID())
                                );
                                $recent_posts = new WP_Query($args);
                                while ($recent_posts->have_posts()) : $recent_posts->the_post();
                                    $post = $recent_posts->post;
                                    $content = get_the_content();
                                ?>
                                    <div class="col-lg-12 col-sm-6">
                                        <?php get_template_part('template-parts/content', 'post'); ?>
                                    </div>
                                <?php
                                endwhile;
                                wp_reset_postdata();
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php endwhile; // End of the loop. 
?>


<?php
$current_post_id = get_the_ID();
$categories = get_the_category($current_post_id);

if ($categories) {
    $category_ids = array();
    foreach ($categories as $category) {
        $category_ids[] = $category->term_id;
    }
}
?>

<section class="latest-blog style-2 common-sec pt-0">
    <div class="container-fluid">
        <div class="sec-head border-bottom-0">
            <h2 class="sec-title wow animate__fadeInUp" data-wow-delay="0.1s">You may also like to read</h2>
        </div>

        <div class="latest-sliders swiper position-relative">
            <div class="swiper-wrapper">

                <?php
                $related_posts_args = array(
                    'post__not_in' => array($current_post_id), // Exclude current post
                    'posts_per_page' => 4, // Number of related posts to display
                    'category__in' => $category_ids, // Only posts from the same categories
                    'orderby' => 'rand', // Order by random
                );
                $related_posts_query = new WP_Query($related_posts_args);
                while ($related_posts_query->have_posts()) : $related_posts_query->the_post();
                    $post = $related_posts_query->post;
                    $content = get_the_content();
                ?>
                    <div class="swiper-slide">
                        <div class="news-col">
                            <?php get_template_part('template-parts/content', 'post'); ?>
                        </div>
                    </div>
                <?php
                endwhile;
                wp_reset_postdata();
                ?>

            </div>

            <div class="swiper-pagination"></div>
        </div>

    </div>
</section>
<?php
get_footer();
