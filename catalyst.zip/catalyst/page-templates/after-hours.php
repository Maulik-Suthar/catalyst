<?php /* Template Name: After Hours */
get_header();
$path = get_stylesheet_directory_uri();
?>

<?php
$about_catalyst_title = get_field('about_catalyst_title');
$about_catalyst_description = get_field('about_catalyst_description');
$about_catalyst_image_first = get_field('about_catalyst_image_first');
if ($about_catalyst_title || $about_catalyst_description || $about_catalyst_image_first) :
?>
    <section class="about-sec pediatric-about-sec after-hours-sec">
        <div class="container-fluid g-0">
            <div class="row align-items-center g-0">
                <div class="col-lg-6">
                    <div class="about-con">
                        <div class="sec-head">
                            <div class="about-title-shape">
                                <img src="<?php echo $path; ?>/assets/img/after-about-title-shape.svg" alt="about-title-shape">
                            </div>
                            <?php if (!empty($about_catalyst_title)) { ?>
                                <h1 class="sec-title"><?php echo $about_catalyst_title ?></h1>
                            <?php } ?>
                            <?php if (!empty($about_catalyst_description)) { ?>
                                <p class="about-description"><?php echo $about_catalyst_description ?></p>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php if ($about_catalyst_image_first) : ?>
                    <div class="col-lg-6">
                        <div class="about-img-wrap">
                            <?php if (!empty($about_catalyst_image_first)) { ?>
                                <div class="about-img">
                                    <img src="<?php echo $about_catalyst_image_first['url']; ?>" alt="<?php echo $about_catalyst_image_first['alt']; ?>" />
                                </div>
                            <?php } ?>
                            <div class="about-img"></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$catalyst_physician_title = get_field('catalyst_physician_title');
$catalyst_physician_description = get_field('catalyst_physician_description');
$catalyst_physician_img = get_field('catalyst_physician_img');
if ($catalyst_physician_title || $catalyst_physician_description || $catalyst_physician_img) :
?>
    <section class="essentials-sec common-sec after-essentials-sec">
        <div class="container">
            <div class="essentials-con">
                <div class="sec-head text-center mb-0">
                    <?php if (!empty($catalyst_physician_title)) { ?>
                        <h2 class="sec-title"><?php echo $catalyst_physician_title ?></h2>
                    <?php } ?>
                    <?php if (!empty($catalyst_physician_description)) { ?>
                        <p><?php echo $catalyst_physician_description ?></p>
                    <?php } ?>
                </div>
                <div class="after-essentials-left-img"></div>
                <?php if (!empty($catalyst_physician_img)) { ?>
                    <div class="essentials-right-img">
                        <img src="<?php echo $catalyst_physician_img['url']; ?>" alt="<?php echo $catalyst_physician_img['alt']; ?>" />
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$walk_in_locations_title = get_field('walk_in_locations_title');
$select_locations = get_field('select_locations');
if (!empty($select_locations)) :
?>
<section class="pediatric-locations common-sec">
    <div class="container-fluid">
        <?php if (!empty($walk_in_locations_title)) { ?>
            <div class="sec-head text-center">
                <h2 class="sec-title wow animate__fadeInUp"><?php echo $walk_in_locations_title ?></h2>
            </div>
        <?php } ?>

        <div class="row">
            <?php
                $args = array(
                    'post_type'      => 'location',
                    'post_status' => 'publish',
                    'posts_per_page' => '-1',
                    'orderby' => 'title',
                    'order'   => 'ASC',
                    'meta_query' => $meta_query,
                    'orderby' => 'post__in',
                    'post__in' => $select_locations,
                );
                $loop = new WP_Query($args);
                $post_titles = array();
                while ($loop->have_posts()) : $loop->the_post();
                    get_template_part('template-parts/content', 'service-location');
                    $location_data = get_location_data($post, $post->ID);
                    $locations[] = $location_data;
                    $locations_data[] = get_the_title();
                endwhile;
                wp_reset_postdata();
                ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php
get_footer();
?>