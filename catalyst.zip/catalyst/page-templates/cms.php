<?php /* Template Name: CMS */
get_header();
$path = get_stylesheet_directory_uri();
?>
<section class="cms-sec">
    <div class="container-fluid">
        <div class="row">
            <?php if (have_rows('cms')) : ?>
                <div class="col-auto">
                    <nav class="item-list">
                        <ul>
                            <?php while (have_rows('cms')) : the_row();
                                $cms_title = get_sub_field('cms_title'); ?>
                                <li><a class="go-to-section <?php echo (get_row_index() == 1) ? 'active' : ''; ?>" href="#simple-list-item-<?php echo get_row_index(); ?>"><?php echo $cms_title; ?></a></li>
                            <?php endwhile; ?>
                        </ul>
                    </nav>
                </div>
            <?php endif; ?>
            <div class="col-lg-9">
                <div class="sec-head">
                    <h1 class="sec-title"><?php the_title(); ?></h1>
                    <?php $last_updated_date = get_field('last_updated_date'); ?>
                    <?php echo ($last_updated_date != '') ? '<span class="date">Last updated: ' . $last_updated_date . '</span>' : ''; ?>
                </div>
                <div class="cms-con">
                    <?php the_content(); ?>
                </div>
                <?php if (have_rows('cms')) : ?>
                    <?php while (have_rows('cms')) : the_row();
                        $cms_title = get_sub_field('cms_title');
                        $cms_description = get_sub_field('cms_description'); ?>
                        <div id="simple-list-item-<?php echo get_row_index(); ?>" class="take-to-section">
                            <h2 class="item-title"><?php echo $cms_title; ?></h2>
                            <div class="cms-con">
                                <?php echo $cms_description; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php
get_footer();
?>