<?php /* Template Name: FAQ */
get_header();
$path = get_stylesheet_directory_uri();
?>

<?php
$faqs_title = get_field('faqs_title');
$faqs_description = get_field('faqs_description');
if ($faqs_title || $faqs_description) :
?>
    <section class="faq-head-sec">
        <div class="container">
            <div class="sec-head text-center">
                <h4 class="sec-sub-title">FAQs</h4>
                <?php if (!empty($faqs_title)) { ?>
                    <h1 class="sec-title"><?php echo $faqs_title ?></h1>
                <?php } ?>
                <?php if (!empty($faqs_description)) { ?>
                    <p class="faq-head-description"><?php echo $faqs_description ?></p>
                <?php } ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
if (have_rows('faqs')) : ?>
    <section class="faq-sec common-sec">
        <div class="container">

            <?php
            $faqsitem = 1;
            while (have_rows('faqs')) : the_row();
                $faq_title = get_sub_field('faq_title');
            ?>

                <h2 class="faq-title"><?php the_sub_field('faq_title'); ?></h2>
                <div class="faq-wrapper">
                    <div class="accordion" id="faq<?php echo $faqsitem; ?>">

                        <?php
                        $faqList = 1;
                        while (have_rows('faq_list')) : the_row();
                            $faq_head_title = get_sub_field('faq_head_title');
                            $faq_details = get_sub_field('faq_details');
                        ?>
                            <div class="accordion-item">
                                <button class="accordion-button <?php echo ($faqList == 1) ? '' : 'collapsed'; ?>" data-bs-toggle="collapse" data-bs-target="#faq<?php echo $faqsitem; ?>-<?php echo $faqList; ?>">
                                    <span><?php the_sub_field('faq_head_title'); ?></span>
                                    <span class="faq-arrow"></span>
                                </button>
                                <div id="faq<?php echo $faqsitem; ?>-<?php echo $faqList; ?>" class="accordion-collapse collapse <?php echo ($faqList == 1) ? 'show' : ''; ?>" data-bs-parent="#faq<?php echo $faqsitem; ?>">
                                    <div class="cms-con">
                                        <?php the_sub_field('faq_details'); ?>
                                    </div>
                                </div>
                            </div>
                        <?php $faqList++;
                        endwhile; ?>

                    </div>
                </div>

            <?php $faqsitem++;
            endwhile; ?>

        </div>
    </section>
<?php endif; ?>

<?php
get_footer();
?>