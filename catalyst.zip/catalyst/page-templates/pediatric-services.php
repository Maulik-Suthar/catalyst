<?php /* Template Name: Pediatric Services */
get_header();
$path = get_stylesheet_directory_uri();
?>

<?php
$about_logo = get_field('about_logo');
$about_catalyst_title = get_field('about_catalyst_title');
$about_catalyst_description = get_field('about_catalyst_description');
$about_catalyst_image_first = get_field('about_catalyst_image_first');
$about_catalyst_image_second = get_field('about_catalyst_image_second');
if ($about_logo || $about_catalyst_title || $about_catalyst_description || $about_catalyst_image_first || $about_catalyst_image_second) :
?>
    <section class="about-sec pediatric-about-sec pb-0">
        <div class="container-fluid g-0">
            <div class="row align-items-center g-0">
                <div class="col-lg-6">
                    <div class="about-con">
                        <?php if (!empty($about_logo)) { ?>
                            <div class="about-logo">
                                <img src="<?php echo $about_logo['url']; ?>" alt="<?php echo $about_logo['alt']; ?>" />
                            </div>
                        <?php } ?>
                        
                        <div class="sec-head">
                            <div class="about-title-shape">
                                <img src="<?php echo $path; ?>/assets/img/about-title-shape.svg" alt="about-title-shape">
                            </div>
                            <?php if (!empty($about_catalyst_title)) { ?>
                                <h1 class="sec-title"><?php echo $about_catalyst_title ?></h1>
                            <?php } ?>
                            <?php if (!empty($about_catalyst_description)) { ?>
                                <p class="about-description"><?php echo $about_catalyst_description ?></p>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php if ($about_catalyst_image_first || $about_catalyst_image_second) : ?>
                    <div class="col-lg-6">
                        <div class="about-img-wrap">
                            <?php if (!empty($about_catalyst_image_first)) { ?>
                                <div class="about-img">
                                    <img src="<?php echo $about_catalyst_image_first['url']; ?>" alt="<?php echo $about_catalyst_image_first['alt']; ?>" />
                                </div>
                            <?php } ?>
                            <div class="about-img"></div>                            
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$physician_owned_title = get_field('physician_owned_title');
$physician_owned_details = get_field('physician_owned_details');
$physician_owned_image = get_field('physician_owned_image');
if ($physician_owned_title || $physician_owned_details || $physician_owned_image) :
?>
    <section class="physician-owned-sec common-sec parents-pro-sec">
        <div class="container-fluid">
            <div class="physician-owned-inner">
                <div class="row align-items-center">
                    <div class="col-md-7 col-sm-12">
                        <div class="physician-con">
                            <div class="sec-head wow animate__fadeInUp" data-wow-delay="0.1s">
                                <?php if (!empty($physician_owned_title)) { ?>
                                    <h2 class="sec-title">
                                        <?php echo $physician_owned_title ?>
                                    </h2>
                                <?php } ?>
                            </div>
                            <?php if (!empty($physician_owned_details)) { ?>
                                <div class="cms-con wow animate__fadeInUp" data-wow-delay="0.2s">
                                    <?php echo $physician_owned_details ?>
                                </div>
                            <?php } ?>
                            <?php if (!empty($learn_more_btn)) { ?>
                                <a href="<?php echo $learn_more_btn['url']; ?>" target="<?php echo $learn_more_btn['target']; ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $learn_more_btn['title']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <?php if (!empty($physician_owned_image)) { ?>
                            <div class="physician-owned-img">
                                <img src="<?php echo $physician_owned_image['url']; ?>" alt="<?php echo $physician_owned_image['alt']; ?>" />
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$groups_leadership_title = get_field('groups_leadership_title');
$groups_leadership_description = get_field('groups_leadership_description');
$select_provides = get_field('select_providers');
?>

<?php if (!empty($select_provides)) : ?>
    <section class="leadership-sec pediatric-leadership-sec common-sec pt-0 ">
        <div class="container">
            <div class="leadership-head text-center">
                <?php if (!empty($groups_leadership_title)) { ?>
                    <div class="sec-head mb-0">
                        <h2 class="sec-title"><?php echo $groups_leadership_title ?></h2>
                    </div>
                <?php } ?>
                <?php if (!empty($groups_leadership_description)) { ?>
                    <div class="leadership-description">
                        <?php echo $groups_leadership_description ?>
                    </div>
                <?php } ?>
            </div>
            <div class="accordion" id="leadershipAccordion">
                <?php
                $args = array(
                    'post_type'      => 'provider',
                    'posts_per_page' => '-1',
                    'orderby' => 'post__in',
                    'post__in' => $select_provides,
                );
                $loop = new WP_Query($args);
                while ($loop->have_posts()) : $loop->the_post();
                    get_template_part('template-parts/content', 'provider');
                endwhile;
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$pediatric_service_title = get_field('pediatric_service_title');
$pediatric_services_details = get_field('pediatric_services_details');
$pediatric_services_image = get_field('pediatric_services_image');
if ($pediatric_service_title || $pediatric_services_details || $pediatric_services_image) :
?>
<section class="pediatric-services common-sec">
    <div class="container-fluid">
        <div class="row align-items-center flex-row-reverse">
            
            <div class="col-sm-7 col-md-7 col-lg-8">
                <div class="pediatric-services-con">
                    <?php if (!empty($pediatric_service_title)) { ?>
                        <div class="sec-head">
                            <h2 class="sec-title mb-0 wow animate__fadeInUp"><?php echo $pediatric_service_title ?></h2>                        
                        </div>
                    <?php } ?>
                    <?php if (!empty($pediatric_services_details)) { ?>
                        <div class="cms-con wow animate__fadeInUp" data-wow-delay=".1s">
                            <?php echo $pediatric_services_details ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <div class="col-sm-5 col-md-5 col-lg-4">
                <?php if (!empty($pediatric_services_image)) { ?>
                    <div class="pediatric-services-img d-inline-block wow animate__fadeInLeft" data-wow-delay=".2s">                    
                        <img src="<?php echo $pediatric_services_image['url']; ?>" alt="<?php echo $pediatric_services_image['alt']; ?>" />
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php
$view_our_locations_title = get_field('view_our_locations_title');
$select_locations = get_field('select_locations');
if (!empty($select_locations)) :
?>
<section class="pediatric-locations common-sec">
    <div class="container-fluid">
        <div class="sec-head text-center">
            <h2 class="sec-title wow animate__fadeInUp"><?php echo $view_our_locations_title ?></h2>
        </div>
        <div class="row">

            <?php
                $args = array(
                    'post_type'      => 'location',
                    'post_status' => 'publish',
                    'posts_per_page' => '-1',
                    'orderby' => 'title',
                    'order'   => 'ASC',
                    'meta_query' => $meta_query,
                    'orderby' => 'post__in',
                    'post__in' => $select_locations,
                );
                $loop = new WP_Query($args);
                $post_titles = array();
                while ($loop->have_posts()) : $loop->the_post();
                    get_template_part('template-parts/content', 'service-location');
                    $location_data = get_location_data($post, $post->ID);
                    $locations[] = $location_data;
                    $locations_data[] = get_the_title();
                endwhile;
                wp_reset_postdata();
                ?>

        </div>
    </div>
</section>
<?php endif; ?>

<?php
$blogIds = get_field('select_blog', $pageId);
$blogs_main_title = get_field('blogs_main_title');
$explore_more_btn = get_field('explore_more_btn');
if ($blogIds) { ?>
<section class="latest-blog common-sec pt-0">
    <div class="container-fluid">
        <div class="sec-head">
            <?php if (!empty($blogs_main_title)) { ?>
                <h2 class="sec-title wow animate__fadeInUp" data-wow-delay="0.1s"><?php echo $blogs_main_title ?></h2>
            <?php } ?>
            <?php if(!empty($explore_more_btn)){ ?>
                <a href="<?php echo $explore_more_btn['url']; ?>" target="<?php echo $explore_more_btn['target']; ?>" class="btn btn-orange wow animate__fadeInUp d-sm-block d-none" data-wow-delay="0.2s"><?php echo $explore_more_btn['title']; ?></a>
            <?php } ?>
        </div>

        <div class="latest-sliders swiper position-relative">
            <div class="swiper-wrapper">
                <?php
                    $count = 1;
                    $args = array('post__in' => $blogIds, 'post_type' => 'post', 'order' => 'ASC', 'orderby' => 'post__in');
                    $recent_posts = get_posts($args);
                    foreach ($recent_posts as $post) {
                    ?>
                    <div class="swiper-slide">
                        <div class="news-col">
                            <?php get_template_part('template-parts/content', 'post'); ?>
                        </div>
                    </div>
                <?php } ?>
                <?php wp_reset_query(); ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
        <div class="text-center d-sm-none">
            <?php if(!empty($explore_more_btn)){ ?>        
                <a href="<?php echo $explore_more_btn['url']; ?>" target="<?php echo $explore_more_btn['target']; ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $explore_more_btn['title']; ?></a>
            <?php } ?>
        </div>
    </div>
</section>
<?php } ?>

<?php
get_footer();
?>