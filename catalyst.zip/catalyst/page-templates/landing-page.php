<?php /* Template Name: Landing Page */
get_header();
$path = get_stylesheet_directory_uri();
$location = get_field('location');
$sub_title = get_field('sub_title');
$title = get_field('title');
$left_image = get_field('left_image');
$right_image = get_field('right_image');
$button = get_field('button');
$short_description = get_field('short_description');

if ($location != null) {
    $loc_logo = get_field('location');
    $loc_logo_final = get_term_meta($loc_logo, 'logo', true);

    $term = get_term_by('id', $loc_logo, 'location_categories');

    if ($term->name == "VHP Frisco") {
        $sectionStyle = '';
        $buttonClass = 'btn-blue';
    } elseif ($term->name == "FHCA") {
        $sectionStyle = 'style-2';
        $buttonClass = 'btn-blue btn-blue-light';
    } elseif ($term->name == "VHP Frisco Peds") {
        $sectionStyle = 'style-3';
        $buttonClass = 'btn-orange';
    } elseif ($term->name == "NETIMA") {
        $sectionStyle = 'style-4';
        $buttonClass = 'btn-light btn-light-sky';
    } else {
        $sectionStyle = '';
        $buttonClass = 'btn-orange';
    }
}

?>

 <?php /* <section class="partners-sec <?php echo $sectionStyle; ?>">
    <div class="container-fluid p-0">
        <div class="partner-row">
            <div class="partner-col-left">
                <div class="partner-image-container-left">
                    <div class="image-box-1"></div>
                    <?php if (!empty($left_image)) : ?>
                        <div class="image-box-2">
                            <img src="<?php echo $left_image['url']; ?>" alt="<?php echo $left_image['alt']; ?>">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="partner-col-center">
                <div class="partner-content text-center">
                    <div class="sec-head mb-0">
                        <div class="partner-title-shape mx-auto d-inline-block"></div>
                        <?php echo (!empty($sub_title)) ? '<h4 class="sec-sub-title">' . $sub_title . '</h4>' : ''; ?>
                        <?php echo (!empty($title)) ? '<h1 class="sec-title">' . $title . '</h1>' : ''; ?>
                        <?php if (!empty($button)) : ?>
                            <a href="<?php echo $button['url']; ?>" target="<?php echo (!empty($button['target'])) ? $button['target'] : '_self'; ?>" class="btn <?php echo (!empty($buttonClass)) ? $buttonClass : 'btn-orange'; ?>">View Locations</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="partner-col-right">
                <div class="partner-image-container-right">
                    <?php if (!empty($loc_logo)) : ?>
                        <div class="image-box-1 f">
                            <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($right_image)) : ?>
                        <div class="image-box-2">
                            <img src="<?php echo $right_image['url']; ?>" alt="<?php echo $right_image['alt']; ?>">
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($left_image)) : ?>
                        <div class="image-box-3">
                            <img src="<?php echo $left_image['url']; ?>" alt="<?php echo $left_image['alt']; ?>">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section> */ ?>


    <section class="about-sec landing-banner-sec <?php echo $sectionStyle; ?>">
        <div class="container-fluid g-0">
            <div class="row align-items-center g-0">
                <div class="col-lg-7">
                    <div class="about-con">
                        <div class="sec-head mb-0">                            
                            <?php echo (!empty($title)) ? '<h1 class="sec-title">' . $title . '</h1>' : ''; ?>
                            <?php echo (!empty($sub_title)) ? '<h2 class="sub-title">' . $sub_title . '</h2>' : ''; ?>
                            <?php if (!empty($short_description)) { ?>
                                <p class="about-desc"><?php echo $short_description; ?></p>                            
                            <?php } ?>
                            <?php if (!empty($button)) : ?>
                            <a href="<?php echo $button['url']; ?>" target="<?php echo (!empty($button['target'])) ? $button['target'] : '_self'; ?>" class="btn <?php echo (!empty($buttonClass)) ? $buttonClass : 'btn-orange'; ?>">View Locations</a>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                    <div class="col-lg-5">
                        <div class="about-img-wrap">
                            <?php if (!empty($loc_logo)) : ?>
                                <div class="about-img">
                                    <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
                                </div>
                            <?php endif; ?>                            
                        </div>
                    </div>                
            </div>
        </div>
    </section>

<?php
$profile_title = get_field('profile_title');
$profile_details = get_field('profile_details');
$profile_image = get_field('profile_image');
if ($physician_owned_title || $profile_details || $profile_image) :
?>
<section class="landing-profile-sec <?php echo $sectionStyle; ?>">
    <div class="container-fluid">
        <div class="landing-profile-wrap">
            <div class="profile-top-shape"></div>
            <div class="profile-bottom-shape"></div>
            <div class="landing-profile-inner">
                <div class="landing-profile">
                    <?php if (!empty($profile_image)) { ?>
                        <div class="landing-profile-img">
                            <img src="<?php echo $profile_image['url']; ?>" alt="<?php echo $profile_image['alt']; ?>" />
                        </div>
                    <?php } ?>

                    <?php if (!empty($profile_title)) { ?>
                        <h3 class="landing-profile-title">
                            <?php echo $profile_title ?>
                        </h2>
                    <?php } ?>                    
                    
                </div>
                <?php if (!empty($profile_details)) { ?>
                <div class="landing-profile-Details">
                    <p><?php echo $profile_details ?></p>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php include get_template_directory() . '/inc/custom-location.php';

get_footer();
?>