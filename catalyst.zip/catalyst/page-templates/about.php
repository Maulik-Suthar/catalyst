<?php /* Template Name: About */
get_header();
$path = get_stylesheet_directory_uri();
?>

<?php
$about_catalyst_title = get_field('about_catalyst_title');
$about_catalyst_description = get_field('about_catalyst_description');
$about_catalyst_image_first = get_field('about_catalyst_image_first');
// $about_catalyst_image_second = get_field('about_catalyst_image_second');
if ($about_catalyst_title || $about_catalyst_description || $about_catalyst_image_first) :
?>
    <section class="about-sec">
        <div class="container-fluid g-0">
            <div class="row align-items-center g-0">
                <div class="col-lg-6">
                    <div class="about-con">
                        <div class="sec-head mb-0">
                            <div class="about-title-shape">
                                <img src="<?php echo $path; ?>/assets/img/about-title-shape.svg" alt="about-title-shape">
                            </div>
                            <?php if (!empty($about_catalyst_title)) { ?>
                                <h1 class="sec-title"><?php echo $about_catalyst_title ?></h1>
                            <?php } ?>
                            <?php if (!empty($about_catalyst_description)) { ?>
                                <p class="about-description"><?php echo $about_catalyst_description ?></p>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php if ($about_catalyst_image_first) : ?>
                    <div class="col-lg-6">
                        <div class="about-img-wrap">
                            <?php if (!empty($about_catalyst_image_first)) { ?>
                                <div class="about-img">
                                    <img src="<?php echo $about_catalyst_image_first['url']; ?>" alt="<?php echo $about_catalyst_image_first['alt']; ?>" />
                                </div>
                            <?php } ?>
                            <div class="about-img"></div>
                            <?php /* if (!empty($about_catalyst_image_second)) { ?>
                                <div class="about-img">
                                    <img src="<?php echo $about_catalyst_image_second['url']; ?>" alt="<?php echo $about_catalyst_image_second['alt']; ?>" />
                                </div>
                            <?php } */ ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php
$our_purpose_sec_hide = get_field('our_purpose_sec_hide');
if (!$our_purpose_sec_hide) {
?>
    <section class="our-sec common-sec pb-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="nav nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                        <?php
                        $our_purpose_list_tab = 1;
                        while (have_rows('our_purpose')) : the_row();
                            $our_purpose_title = get_sub_field('our_purpose_title');
                            $our_purpose_title_image = get_sub_field('our_purpose_title_image');
                        ?>
                            <button class="nav-link <?php echo ($our_purpose_list_tab == 1) ? 'active' : ''; ?> wow fadeInUp" data-wow-delay="0.<?php echo $our_purpose_list_tab; ?>s" data-bs-toggle="pill" data-bs-target="#v-pills-<?php echo $our_purpose_list_tab; ?>" type="button" role="tab" aria-controls="v-pills-purpose" aria-selected="<?php echo ($our_purpose_list_tab == 1) ? 'true' : 'false'; ?>">
                                <?php if (!empty($our_purpose_title_image)) : ?>
                                    <div class="nav-img-box">
                                        <img src="<?php echo $our_purpose_title_image['url']; ?>" alt="<?php echo $our_purpose_title ?>">
                                        <img src="<?php echo $path; ?>/assets/img/star-icon.svg" alt="star-icon">
                                    </div>
                                <?php endif; ?>
                                <span>
                                    <?php echo $our_purpose_title ?>
                                </span>
                            </button>
                        <?php $our_purpose_list_tab++;
                        endwhile; ?>
                    </div>
                </div>
                <div class="col-12">
                    <div class="tab-content accordion wow fadeInUp" data-wow-delay=".4s" id="v-pills-tabContent">
                        <?php
                        $our_purpose_list = 1;
                        while (have_rows('our_purpose')) : the_row();
                            $our_purpose_title = get_sub_field('our_purpose_title');
                            $our_purpose_description = get_sub_field('our_purpose_description');
                            $our_purpose_image = get_sub_field('our_purpose_image');
                        ?>
                            <div class="accordion-item">
                                <button class="accordion-button d-lg-none d-none <?php echo ($our_purpose_list == 1) ? '' : 'collapsed'; ?>" data-bs-toggle="collapse" data-bs-target="#v-pills-<?php echo $our_purpose_list; ?>" aria-expanded="<?php echo ($our_purpose_list == 1) ? 'true' : 'false'; ?>" aria-controls="v-pills-purpose">
                                    <?php echo $our_purpose_title ?>
                                </button>
                                <div class="tab-pane <?php echo ($our_purpose_list == 1) ? 'active' : ''; ?> accordion-collapse collapse <?php echo ($our_purpose_list == 1) ? 'show' : ''; ?>" data-bs-parent="#v-pills-tabContent" id="v-pills-<?php echo $our_purpose_list; ?>" role="tabpanel" aria-labelledby="home-tab">
                                    <div class="our-con" style="background-image: url('<?php echo $our_purpose_image['url']; ?>');">
                                        <div class="our-content-box">
                                            <div class="our-title"><?php echo $our_purpose_title ?></div>
                                            <div class="our-description"><?php echo $our_purpose_description ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php $our_purpose_list++;
                        endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php } ?>

<?php
$groups_leadership_title = get_field('groups_leadership_title');
$groups_leadership_description = get_field('groups_leadership_description');
$select_provides = get_field('select_providers');
?>

<?php if (!empty($select_provides)) : ?>
    <section class="leadership-sec common-sec">
        <div class="container">
            <div class="leadership-head text-center">
                <?php if (!empty($groups_leadership_title)) { ?>
                    <div class="sec-head mb-0">
                        <h2 class="sec-title"><?php echo $groups_leadership_title ?></h2>
                    </div>
                <?php } ?>
                <?php if (!empty($groups_leadership_description)) { ?>
                    <div class="leadership-description">
                        <?php echo $groups_leadership_description ?>
                    </div>
                <?php } ?>
            </div>
            <div class="accordion" id="leadershipAccordion">
                <?php
                $args = array(
                    'post_type'      => 'provider',
                    'posts_per_page' => '-1',
                    'orderby' => 'post__in',
                    'post__in' => $select_provides,
                );
                $loop = new WP_Query($args);
                while ($loop->have_posts()) : $loop->the_post();
                    get_template_part('template-parts/content', 'provider');
                endwhile;
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$about_info_section_hide = get_field('about_info_section_hide');
if (!$about_info_section_hide) :
    if (have_rows('about_info')) :
?>
        <section class="about-info-sec common-sec">
            <div class="container-fluid">
                <?php while (have_rows('about_info')) : the_row();
                    $about_info_description = get_sub_field('about_info_description');
                    $about_info_button = get_sub_field('about_info_button');
                    $about_info_image = get_sub_field('about_info_image');
                ?>
                    <div class="row align-items-center position-relative">
                        <div class="col-lg-6">
                            <?php if (!empty($about_info_image)) : ?>
                                <div class="about-info-img-box wow zoomIn" data-wow-duration="1.5s">
                                    <img src="<?php echo $about_info_image['url']; ?>" alt="<?php echo $about_info_image['alt']; ?>">
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6">
                            <div class="about-info-content-box">
                                <?php echo (!empty($about_info_description)) ? '<div class="about-info-description wow fadeInUp">' . $about_info_description . '</div>' : '' ?>
                                <?php if (!empty($about_info_button)) : ?>
                                    <a href="<?php echo $about_info_button['url']; ?>" target="<?php echo (!empty($about_info_button['target'])) ? $about_info_button['target'] : '_self'; ?>" class="btn btn-orange wow fadeInUp" data-wow-delay="0.3s"><?php echo $about_info_button['title']; ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </section>
<?php
    endif;
endif;
get_footer();
?>