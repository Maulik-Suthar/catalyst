<?php /* Template Name: Contact */
get_header();
$path = get_stylesheet_directory_uri();

$contact_title = get_field('contact_title');
$contact_description = get_field('contact_description');
if ($contact_title || $contact_description) :
?>
    <section class="faq-head-sec style-2">
        <div class="container">
            <div class="sec-head text-center mb-0 wow fadeInUp">
                <?php if (!empty($contact_title)) { ?>
                    <h1 class="sec-title"><?php echo $contact_title ?></h1>
                <?php } ?>
                <?php if (!empty($contact_description)) { ?>
                    <p class="faq-head-description wow fadeInUp" data-wow-delay="0.2s"><?php echo $contact_description ?></p>
                <?php } ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$medical_emergency_description = get_field('medical_emergency_description');
$medical_emergency_title = get_field('medical_emergency_title');
if ($medical_emergency_description || $medical_emergency_title) : ?>
    <section class="medical-emergency-sec">
        <div class="container">
            <?php if (!empty($medical_emergency_description)) : ?>
                <div class="medical-emergency-head text-center wow fadeInUp" data-wow-delay=".4s">
                    <div class="cms-con">
                        <?php echo $medical_emergency_description; ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (!empty($medical_emergency_title)) : ?>
                <div class="medical-emergency-box text-center">
                    <span></span>
                    <div class="medical-emergency-title wow fadeInUp" data-wow-delay=".6s"><?php echo $medical_emergency_title; ?></div>
                    <span></span>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
<?php
$message_section_title = get_field('message_section_title');
$messages = get_field('messages');
$message_button = get_field('message_button');
$message_second_button = get_field('message_second_button');
?>
<section class="please-click-sec">
    <div class="container">
        <?php if ($message_section_title != '') : ?>
            <div class="sec-head text-center wow fadeInUp">
                <div class="sec-title"><?php echo $message_section_title; ?></div>
            </div>
        <?php endif; ?>
        <?php if (have_rows('messages')) : ?>
            <div class="row row-cols-lg-3 row-cols-md-2 row-cols-1 g-4">
                <?php
                $aniCount = 2;
                while (have_rows('messages')) : the_row();
                    $message_icon = get_sub_field('message_icon');
                    $message_title = get_sub_field('message_title');
                    $message_description = get_sub_field('message_description');
                    $message_link = get_sub_field('message_link');
                ?>
                    <div class="col">
                        <div class="please-click-box wow fadeInUp" data-wow-delay="0.<?php echo $aniCount; ?>s">
                            <?php if (!empty($message_icon)) : ?>
                                <a href="<?php echo (!empty($message_link['url'])) ? $message_link['url'] : '#'; ?>" target="<?php echo (!empty($message_link['target'])) ? $message_link['target'] : '_self'; ?>" class="please-click-icon-box">
                                    <img src="<?php echo $message_icon['url']; ?>" alt="<?php echo $message_icon['alt']; ?>">
                                </a>
                            <?php endif; ?>
                            <div class="please-click-content-box">
                                <?php if ($message_title != '') : ?>
                                    <a href="<?php echo (!empty($message_link['url'])) ? $message_link['url'] : '#'; ?>" class="please-click-title" target="<?php echo (!empty($message_link['target'])) ? $message_link['target'] : '_self'; ?>"><?php echo $message_title; ?></a>
                                <?php endif; ?>
                                <?php if (!empty($message_description)) : ?>
                                    <div class="please-click-description">
                                        <?php echo $message_description; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php $aniCount++;
                endwhile; ?>
            </div>
        <?php endif; ?>
        <div class="please-click-button-wrapper text-center wow fadeInUp" data-wow-delay=".4s">
            <?php if (!empty($message_button)) : ?>
                <a href="<?php echo $message_button['url']; ?>" target="<?php echo (!empty($message_button['target'])) ? $message_button['target'] : '_self'; ?>" class="btn btn-orange"><?php echo $message_button['title']; ?></a>
            <?php endif; ?>
            <br>
            <br>
            <?php if (!empty($message_second_button)) : ?>
                <a href="<?php echo $message_second_button['url']; ?>" target="<?php echo (!empty($message_second_button['target'])) ? $message_second_button['target'] : '_self'; ?>" class="btn btn-orange"><?php echo $message_second_button['title']; ?></a>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php
get_footer();
?>