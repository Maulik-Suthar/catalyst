<?php /* Template Name: Locations */
get_header();
$path = get_stylesheet_directory_uri();
$cities = get_locations_metafileds('location', 'city');
?>

<?php
$find_location_title = get_field('find_location_title');
$find_location_description = get_field('find_location_description');
$view_location_btn = get_field('view_location_btn');
$patient_portal_btn = get_field('patient_portal_btn');
$find_location_first_img = get_field('find_location_first_img');
$find_location_second_img = get_field('find_location_second_img');
$find_location_third_img = get_field('find_location_third_img');
$find_location_logo_img = get_field('find_location_logo_img');

$location_cats = get_terms(array(
    'taxonomy' => 'location_categories',
    'hide_empty' => false,
));




if ($find_location_title || $find_location_description || $view_location_btn || $patient_portal_btn || $find_location_first_img || $find_location_second_img || $find_location_third_img || $find_location_logo_img) :
?>
    <section class="find-location-sec banner-find-location">
        <div class="container-fluid g-0">
            <div class="row align-items-center g-0">
                <div class="col-lg-7">
                    <div class="find-location-con">
                        <div class="sec-head">
                            <?php if (!empty($find_location_title)) { ?>
                                <h1 class="sec-title"><?php echo $find_location_title ?></h1>
                            <?php } ?>
                            <?php if (!empty($find_location_description)) { ?>
                                <p><?php echo $find_location_description ?></p>
                            <?php } ?>
                        </div>
                        <div class="btn-wrap justify-content-start">
                            <?php if (!empty($view_location_btn)) { ?>
                                <a href="<?php echo $view_location_btn['url']; ?>" target="<?php echo $view_location_btn['target']; ?>" class="btn btn-orange"><?php echo $view_location_btn['title']; ?></a>
                            <?php } ?>
                            <?php /* if(!empty($patient_portal_btn)){ ?>
                            <a href="<?php echo $patient_portal_btn['url']; ?>" target="<?php echo $patient_portal_btn['target']; ?>" class="btn btn-yellow"><?php echo $patient_portal_btn['title']; ?></a>
                        <?php } */ ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="find-location-img-wrap">
                        <?php if (!empty($find_location_first_img)) { ?>
                            <div class="find-location-img">
                                <img src="<?php echo $find_location_first_img['url']; ?>" alt="<?php echo $find_location_first_img['alt']; ?>" />
                            </div>
                        <?php } ?>
                        <?php if (!empty($find_location_second_img)) { ?>
                            <div class="find-location-img">
                                <img src="<?php echo $find_location_second_img['url']; ?>" alt="<?php echo $find_location_second_img['alt']; ?>" />
                            </div>
                        <?php } ?>
                        <?php if (!empty($find_location_third_img)) { ?>
                            <div class="find-location-img">
                                <img src="<?php echo $find_location_third_img['url']; ?>" alt="<?php echo $find_location_third_img['alt']; ?>" />
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-12">
                    <?php if (!empty($find_location_logo_img)) { ?>
                        <div class="location-collaborators-logo-slider">
                            <?php foreach ($location_cats as $location_cat) { ?>
                                <div class="logo-item logo-<?php echo $location_cat->term_id; ?>">
                                    <?php $logo = get_term_meta($location_cat->term_id, 'logo', true);
                                    if (!empty($logo)) {
                                        echo wp_get_attachment_image($logo, 'full');
                                    } ?>
                                </div>
                            <?php }
                            ?>
                        </div>
                    <?php }
                    // Logo Old
                    // $count = 0;
                    // $items_per_group = 2;
                    // foreach ($location_cats as $location_cat) {
                    //     if ($count % $items_per_group == 0) {
                    //         echo '<div class="logo-group">';
                    //     }
                    //     echo '<div class="loc-logo loc-logo-' . $location_cat->term_id . '">';
                    //     $logo = get_term_meta($location_cat->term_id, 'logo', true);
                    //     if (!empty($logo)) {
                    //         echo wp_get_attachment_image($logo, 'full');
                    //     }
                    //     echo '</div>';
                    //     if (($count + 1) % $items_per_group == 0 || $count == count($location_cats) - 1) {
                    //         echo '</div>';
                    //     }
                    //     $count++;
                    // }
                    ?>
                    <!-- <img src="<?php //echo $find_location_logo_img['url'];  
                                    ?>" alt="<?php //echo $find_location_logo_img['alt']; 
                                                ?>" /> -->
                </div>
            </div>
        </div>
    </section>

<?php endif; ?>

<?php
include get_template_directory() . '/inc/custom-location.php';
?>

<?php
get_footer();
?>

<script>
    // function autoActiveClass(items, index, className, time) {
    //     index = index % items.length;
    //     items.removeClass(className);
    //     items.eq(index).addClass(className);
    //     setTimeout(function() {
    //         autoActiveClass(items, index + 1, className, time)
    //     }, time);
    // }
    // autoActiveClass(jQuery('.logo-group'), 0, 'active', 3000);
    // autoActiveClass(jQuery('.loc-logo'), 0, 'active', 3000);
</script>