<?php /* Template Name: New portal */
get_header();
$path = get_stylesheet_directory_uri();
?>


<?php
$join_us_title = get_field('join_us_title');
$join_us_sub_title = get_field('join_us_sub_title');
$join_us_details = get_field('join_us_details');
$apply_now_btn = get_field('apply_now_btn');
$join_us_image = get_field('join_us_image');
if ($join_us_title || $join_us_sub_title || $join_us_details || $apply_now_btn || $join_us_image) :
?>
    <section class="join-us-sec patient-portal-sec">
        <div class="container-fluid">
            <div class="join-us-inner">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="join-us-con">
                            <?php if (!empty($join_us_title)) { ?>
                                <div class="sec-head  wow animate__fadeInUp" data-wow-delay="0.1s">
                                    <h1 class="sec-title"><?php echo $join_us_title ?></h1>
                                </div>
                            <?php } ?>
                            <?php if (!empty($join_us_sub_title)) { ?>
                                <h2 class="sec-sub-title wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $join_us_sub_title ?></h2>
                            <?php } ?>
                            <?php if (!empty($join_us_details)) { ?>
                                <p class="wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $join_us_details ?></p>
                            <?php } ?>
                            <?php if (!empty($apply_now_btn)) { ?>
                                <a href="<?php echo $apply_now_btn['url']; ?>" target="<?php echo $apply_now_btn['target']; ?>" class="mx-lg-2 mt-2 mt-md-0 btn btn-orange  wow animate__fadeInUp" data-wow-delay="0.4s"><?php echo $apply_now_btn['title']; ?></a>
                            <?php } ?>
                            <a href="#old-portal" class="btn btn-orange mx-0 mx-lg-2 mt-2 mt-md-0 wow animate__fadeInUp" data-wow-delay="0.4s">Old Patient Portal</a>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <?php if (!empty($join_us_image)) { ?>
                            <div class="join-us-img">
                                <img src="<?php echo $join_us_image['url']; ?>" alt="<?php echo $join_us_image['alt']; ?>" />
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>    

<?php
$old_portal_title = get_field('old_portal_title');
?>
    <section class="common-sec portal-account-sec pt-0" id="old-portal">
        <div class="container-fluid">
            <?php if (!empty($old_portal_title)) { ?>
                <div class="sec-head  wow animate__fadeInUp" data-wow-delay="0.1s">
                    <h2 class="sec-title text-center"><?php echo $old_portal_title ?></h2>
                </div>
            <?php } ?>                        
            <div class="row">
                <?php
                $count = 1;
                while (have_rows('old_portal_list')) : the_row();
                    $old_portal_logo = get_sub_field('old_portal_logo');
                    $portal_title = get_sub_field('portal_title');
                    $old_portal_btn = get_sub_field('old_portal_btn');
                    $count1 = $count / 10;
                ?>
                <div class="col-sm-4 col-12 portal-col wow animate__fadeInUp" data-wow-delay="<?php echo $count1; ?>s">
                    <div class="portal-box">
                        <?php if (!empty($old_portal_logo)) { ?>
                            <div class="portal-icon">
                                <img src="<?php echo $old_portal_logo['url']; ?>" alt="<?php echo $old_portal_logo['alt']; ?>" />
                            </div>
                        <?php } ?>                        
                        <div class="portal-con">
                            <?php if (!empty($portal_title)) { ?>
                                <h3 class="portal-title"><?php echo $portal_title ?></h3>
                            <?php } ?>                            
                            <?php if (!empty($old_portal_btn)) { ?>
                                <a href="<?php echo $old_portal_btn['url']; ?>" target="<?php echo $old_portal_btn['target']; ?>" class="btn btn-blue"><?php echo $old_portal_btn['title']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php $count++;
                endwhile; ?>    
            </div>
        </div>
    </section>

    <?php
    $need_additional_title = get_field('need_additional_title');
    $need_additional_details = get_field('need_additional_details');    
    if ($need_additional_title || $need_additional_details) :
    ?>
    <section class="need-additional-sec common-sec pt-0">
        <div class="container-fluid">
            <div class="need-additional-wrap">
                <div class="title-shape wow animate__fadeInUp">
                    <img src="<?php echo $path; ?>/assets/img/title-shape.svg" alt="title-shape">
                </div>
                <?php if (!empty($need_additional_title)) { ?>
                    <div class="sec-head wow animate__fadeInUp" data-wow-delay="0.1s">
                        <h2 class="sec-title"><?php echo $need_additional_title ?></h2>
                    </div>
                <?php } ?>
                <?php if (!empty($need_additional_details)) { ?>
                    <p class="wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $need_additional_details ?></p>
                <?php } ?>
            </div>
        </div>
    </section>
    <?php endif; ?> 

<?php
get_footer();
?>