<?php /* Template Name: Homepage */
get_header();
$path = get_stylesheet_directory_uri();
?>

<section class="banner-sec">
	<div class="container-fluid">
		<div class="banner-wrapper">
			<div class="home-sliders swiper position-relative">
				<div class="swiper-wrapper">
					<?php
					while (have_rows('banner')) : the_row();
						$banner_img = get_sub_field('banner_img');
						$banner_img_logo = get_sub_field('banner_img_logo');
						$banner_title = get_sub_field('banner_title');
						$banner_description = get_sub_field('banner_description');
						$banner_btn = get_sub_field('banner_btn');
						$banner_style_second = get_sub_field('banner_style_second');
					?>
						<div class="swiper-slide">
							<?php if ($banner_style_second == true) { ?>

								<div class="banner-inner-sec banner-style-second">
									<div class="circle-top-shape"></div>
									<div class="circle-bottom-shape"></div>
									<?php if (!empty($banner_img)) { ?>
										<div class="banner-img">
											<img src="<?php echo $banner_img['url']; ?>" alt="<?php echo $banner_img['alt']; ?>" />
										</div>
									<?php } ?>
									<div class="banner-caption">
										<div class="sec-head">
											<?php if (!empty($banner_title)) { ?>
												<?php echo (get_row_index() == 1) ? '<h1 class="sec-title">' : '<h2 class="sec-title">'; ?><?php echo $banner_title ?><?php echo (get_row_index() == 1) ? '</h1>' : '</h2>'; ?>
											<?php } ?>
											<?php if (!empty($banner_description)) { ?>
												<div class="banner-second-title"><?php echo $banner_description ?></div>
											<?php } ?>
											<?php if (!empty($banner_btn)) { ?>
												<a href="<?php echo $banner_btn['url']; ?>" target="<?php echo $banner_btn['target']; ?>" class="btn btn-orange"><?php echo $banner_btn['title']; ?></a>
											<?php } ?>
										</div>
									</div>
								</div>
								
							<?php } else { ?>
								<div class="banner-inner-sec">
									<?php if (!empty($banner_img)) { ?>
										<div class="banner-img">
											<img src="<?php echo $banner_img['url']; ?>" alt="<?php echo $banner_img['alt']; ?>" />
										</div>
									<?php } ?>
									<div class="banner-caption">
										<div class="sec-head">
											<?php if (!empty($banner_title)) { ?>
												<?php echo (get_row_index() == 1) ? '<h1 class="sec-title">' : '<h2 class="sec-title">'; ?><?php echo $banner_title ?><?php echo (get_row_index() == 1) ? '</h1>' : '</h2>'; ?>
											<?php } ?>
											<?php if (!empty($banner_description)) { ?>
												<div class="banner-second-title"><?php echo $banner_description ?></div>
											<?php } ?>
											<?php if (!empty($banner_btn)) { ?>
												<a href="<?php echo $banner_btn['url']; ?>" target="<?php echo $banner_btn['target']; ?>" class="btn btn-orange"><?php echo $banner_btn['title']; ?></a>
											<?php } ?>
										</div>
									</div>
								</div>
							<?php } ?>
						</div>
					<?php endwhile; ?>
				</div>
			</div>
			<div class="home-slide-pagination">
				<div class="swiper-pagination"></div>
			</div>
			<div class="homeslide-arrow">
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
			</div>
			<div class="search-bar-sec">
				<div class="filter-wrap">
					<?php include get_template_directory() . '/inc/provider-form.php'; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
if (have_rows('provider')) : ?>
	<section class="common-sec provider-sec">
		<div class="container-fluid">
			<div class="provider-wrapper provide-sliders swiper position-relative">
				<div class="swiper-wrapper">
					<?php
					$count = 1;
					while (have_rows('provider')) : the_row();
						$provider_image = get_sub_field('provider_image');
						$provider_icon_bg = get_sub_field('provider_icon_bg');
						$provider_icon = get_sub_field('provider_icon');
						$provider_sub_title = get_sub_field('provider_sub_title');
						$provider_title = get_sub_field('provider_title');
						$provider_btn = get_sub_field('provider_btn');
						$count1 = $count / 10;
					?>
						<div class="swiper-slide">
							<div class="provider-list item-<?php echo $count; ?>">
								<div class="provider-box">
									<?php if (!empty($provider_image)) { ?>
										<div class="provider-img">
											<img src="<?php echo $provider_image['url']; ?>" alt="<?php echo sanitize_title($provider_title) ?>-img" />
										</div>
									<?php } ?>
									<div class="provider-con">
										<?php if (!empty($provider_icon)) { ?>
											<div class="provider-icon" style="background-color: <?php echo $provider_icon_bg ?>;">
												<img src="<?php echo $provider_icon['url']; ?>" alt="<?php echo sanitize_title($provider_sub_title) ?>-icon" />
											</div>
										<?php } ?>
										<div class="provider-con-inner">
											<?php if (!empty($provider_sub_title)) { ?>
												<span class="provider-subtitle"><?php echo $provider_sub_title ?></span>
											<?php } ?>
											<?php if (!empty($provider_title)) { ?>
												<h3 class="provider-title"><?php echo $provider_title ?></h3>
											<?php } ?>
											<?php
											if (!empty($provider_btn)) { ?>
												<a href="<?php echo $provider_btn['url']; ?>" target="<?php echo $provider_btn['target']; ?>" class="btn btn-orange"><?php echo $provider_btn['title']; ?></a>
											<?php } ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php $count++;
					endwhile; ?>
				</div>
			</div>
			<div class="provide-pagination">
				<div class="swiper-pagination"></div>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php
$physician_owned_title = get_field('physician_owned_title');
$physician_owned_details = get_field('physician_owned_details');
$physician_owned_image = get_field('physician_owned_image');
$learn_more_btn = get_field('learn_more_btn');
if ($physician_owned_title || $physician_owned_details || $physician_owned_image || $learn_more_btn) :
?>
	<section class="physician-owned-sec">
		<div class="container-fluid">
			<div class="physician-owned-inner">
				<div class="row align-items-center">
					<div class="col-md-7 col-sm-12">
						<div class="physician-con">
							<div class="sec-head wow animate__fadeInUp" data-wow-delay="0.1s">
								<?php if (!empty($physician_owned_title)) { ?>
									<h2 class="sec-title">
										<?php echo $physician_owned_title ?>
									</h2>
								<?php } ?>
							</div>
							<?php if (!empty($physician_owned_details)) { ?>
								<div class="cms-con wow animate__fadeInUp" data-wow-delay="0.2s">
									<?php echo $physician_owned_details ?>
								</div>
							<?php } ?>
							<?php if (!empty($learn_more_btn)) { ?>
								<a href="<?php echo $learn_more_btn['url']; ?>" target="<?php echo $learn_more_btn['target']; ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $learn_more_btn['title']; ?></a>
							<?php } ?>
						</div>
					</div>
					<div class="col-md-4">
						<?php if (!empty($physician_owned_image)) { ?>
							<div class="physician-owned-img">
								<img src="<?php echo $physician_owned_image['url']; ?>" alt="<?php echo $physician_owned_image['alt']; ?>" />
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>


<?php
include get_template_directory() . '/inc/custom-location.php';
?>

<?php
$connected_care_section_title = get_field('connected_care_section_title');
$connected_care_description = get_field('connected_care_description');
if (have_rows('connected_list')) :
?>
	<section class="connected-sec">
		<div class="container-fluid">
			<div class="connected-wrapper">
				<div class="connect-round-top-sm"></div>
				<div class="connect-round-top-lg"></div>
				<div class="connect-round-top"></div>
				<div class="connect-round-bottom"></div>
				<div class="connected-inner">
					<div class="sec-head text-center wow animate__fadeInUp" data-wow-delay="0.1s">
						<?php if (!empty($connected_care_section_title)) { ?>
							<h2 class="sec-title">
								<?php echo $connected_care_section_title ?>
							</h2>
						<?php } ?>
						<?php if (!empty($connected_care_description)) { ?>
							<p><?php echo $connected_care_description ?></p>
						<?php } ?>
					</div>
					<ul class="connected-list">
						<?php
						$item = 1;
						while (have_rows('connected_list')) : the_row();
							$connected_icon = get_sub_field('connected_icon');
							$connected_title = get_sub_field('connected_title');
							$item1 = $item / 10;
						?>
							<li class="wow animate__fadeInUp" data-wow-delay="<?php echo $item1; ?>s">
								<div class="connected-box">
									<?php if (!empty($connected_icon)) { ?>
										<div class="connect-icon">
											<img src="<?php echo $connected_icon['url']; ?>" alt="<?php echo $connected_icon['alt']; ?>" />
										</div>
									<?php } ?>
									<?php if (!empty($connected_title)) { ?>
										<div class="connect-title"><?php echo $connected_title ?></div>
									<?php } ?>
								</div>
							</li>
						<?php $item++;
						endwhile; ?>
					</ul>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php
$turning_image = get_field('turning_image');
$turning_title = get_field('turning_title');
$turning_details = get_field('turning_details');
$turning_btn = get_field('turning_btn');
if ($turning_image || $turning_title || $turning_details || $turning_btn) :
?>
	<section class="turning-sec">
		<div class="container-fluid">
			<div class="turning-inner">
				<div class="row align-items-center">
					<div class="col-sm-6 turning-col-left">
						<?php if (!empty($turning_image)) { ?>
							<div class="turning-img wow animate__fadeInLeft" data-wow-delay="0.1s">
								<img src="<?php echo $turning_image['url']; ?>" alt="<?php echo $turning_image['alt']; ?>" />
							</div>
						<?php } ?>
					</div>
					<div class="col-sm-6 turning-col-right">
						<div class="turning-con">
							<div class="sec-head wow animate__fadeInUp" data-wow-delay="0.1s">
								<?php if (!empty($turning_title)) { ?>
									<h2 class="sec-title"><?php echo $turning_title ?></h2>
								<?php } ?>
							</div>
							<?php if (!empty($turning_details)) { ?>
								<div class="cms-con wow animate__fadeInUp" data-wow-delay="0.2s">
									<?php echo $turning_details ?>
								</div>
							<?php } ?>
							<?php if (!empty($turning_btn)) { ?>
								<a href="<?php echo $turning_btn['url']; ?>" target="<?php echo $turning_btn['target']; ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $turning_btn['title']; ?></a>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php
$testimonials_title = get_field('testimonials_title');
$testimonials_description = get_field('testimonials_description');
$testimonials_hide = get_field('testimonials_hide');
if (!$testimonials_hide) {
?>
	<section class="testimonial-sec">
		<div class="container-fluid">
			<div class="sec-head text-center">
				<?php if (!empty($testimonials_title)) { ?>
					<h2 class="sec-title wow animate__fadeInUp" data-wow-delay="0.1s"><?php echo $testimonials_title ?></h2>
				<?php } ?>
				<?php if (!empty($testimonials_description)) { ?>
					<p class="wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $testimonials_description ?></p>
				<?php } ?>
			</div>
			<div class="testimonial-slider overflow-hidden">
				<div class="swiper-wrapper">
					<?php
					while (have_rows('testimonials')) : the_row();
						$testimonials_video_url = get_sub_field('testimonials_video_url');
						$testimonials_video_img = get_sub_field('testimonials_video_img');
					?>
						<div class="swiper-slide">
							<div class="testimonial-box" data-video-url="<?php echo $testimonials_video_url ?>">
								<div class="video-play">
									<div class="icon"></div>
									<img src="<?php echo $testimonials_video_img['url']; ?>" alt="<?php echo $testimonials_video_img['alt']; ?>" />
								</div>
								<iframe src="" width="100%" height="518" frameborder="0" allow="autoplay; fullscreen" webkitAllowFullScreen mozAllowFullScreen allowFullScreen playsinline></iframe>
							</div>
						</div>
					<?php endwhile; ?>
				</div>
			</div>
			<div class="testimonial-arrow">
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
			</div>
		</div>
	</section>
<?php } ?>
<section class="latest-blog common-sec">
	<div class="container-fluid">
		<div class="sec-head">
			<h2 class="sec-title wow animate__fadeInUp" data-wow-delay="0.1s">Stay updated on the latest <br>life and health news</h2>
			<a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn btn-orange wow animate__fadeInUp d-sm-block d-none" data-wow-delay="0.2s">Explore More</a>
		</div>

		<div class="latest-sliders swiper position-relative">
			<div class="swiper-wrapper">
				<?php
				$count = 1;
				$args = array('numberposts' => '4', 'post_type' => 'post', 'order' => 'ASC');
				$recent_posts = get_posts($args);
				foreach ($recent_posts as $post) {
				?>
					<div class="swiper-slide">
						<div class="news-col">
							<?php get_template_part('template-parts/content', 'post'); ?>
						</div>
					</div>
				<?php } ?>
				<?php wp_reset_query(); ?>
			</div>
			<div class="swiper-pagination"></div>
		</div>
		<div class="text-center d-sm-none">
			<a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn btn-orange wow animate__fadeInUp" data-wow-delay="0.2s">Explore More</a>
		</div>
	</div>
</section>

<?php
get_footer();
?>