<?php /* Template Name: Individual Location */
get_header();
$path = get_stylesheet_directory_uri();
?>
<section class="book-appointment-sec common-sec pb-0">
    <div class="container">
        <div class="book-appointment-con">
            <div class="book-appointment-logo">
                <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/vhp.jpg" alt="village-health">
            </div>
            <div class="sec-head">
                <h1 class="sec-title wow animate__fadeInUp mb-0">Welcome to Frisco <br>Medical Village</h1>
            </div>
            <div class="btn-wrap">
                <a href="#" class="btn btn-orange wow animate__fadeInUp" data-wow-delay=".1s">Book Online</a>
                <a href="tel:817-283-2888" class="btn btn-outline-orange wow animate__fadeInUp" data-wow-delay=".2s">Call: <span class="text-decoration-underline">817-283-2888</span></a>
            </div>
        </div>
        <div class="book-appointment-slider swiper position-relative wow animate__fadeInUp">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="swiper-slide-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/book-apointment-1.jpg" alt="book-apointment-img">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="swiper-slide-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/book-apointment-2.jpg" alt="book-apointment-img">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="swiper-slide-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/book-apointment-3.jpg" alt="book-apointment-img">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="swiper-slide-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/book-apointment-1.jpg" alt="book-apointment-img">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="swiper-slide-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/book-apointment-2.jpg" alt="book-apointment-img">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="swiper-slide-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/book-apointment-3.jpg" alt="book-apointment-img">
                    </div>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
</section>
<section class="location-detail-sec common-sec">
    <div class="container">
        <div class="row">
            <div class="col-lg-auto col-sm-6">
                <div class="location-detail-box wow animate__fadeInUp">
                    <div class="location-detail-box-icon">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/location.svg" alt="icon-img">
                    </div>
                    <div class="location-detail-box-con">
                        <h6 class="location-detail-box-title">Location:</h6>
                        <p>Village Health Partners – Frisco Medical Village Clinic 9990 Dallas Pkwy #200</p>
                        <p>Frisco, TX 75033</p>
                    </div>
                </div>
            </div>
            <div class="col-lg col-sm-6">
                <div class="location-detail-box justify-content-lg-center justify-content-sm-end wow animate__fadeInUp" data-wow-delay=".2s">
                    <div class="location-detail-box-icon">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/phone.svg" alt="icon-img">
                    </div>
                    <div class="location-detail-box-con style-2">
                        <p><span>Phone:</span> <a href="tel:214-387-8288">214-387-8288</a></p>
                        <p><span>Fax:</span> <a href="tel:214-387-8288">214-387-8288</a></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-auto col-sm-6">
                <div class="location-detail-box wow animate__fadeInUp" data-wow-delay=".3s">
                    <div class="location-detail-box-icon">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/hours.svg" alt="icon-img">
                    </div>
                    <div class="location-detail-box-con">
                        <h6 class="location-detail-box-title">Village Health Hours:</h6>
                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                        <div class="accordion" id="hoursAccordian">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#hoursAccordian1" aria-expanded="false" aria-controls="hoursAccordian1">View After-hours</button>
                                </h2>
                                <div id="hoursAccordian1" class="accordion-collapse collapse" data-bs-parent="#hoursAccordian">
                                    <div class="accordion-body">
                                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#hoursAccordian2" aria-expanded="false" aria-controls="hoursAccordian2">View Holiday-hours</button>
                                </h2>
                                <div id="hoursAccordian2" class="accordion-collapse collapse" data-bs-parent="#hoursAccordian">
                                    <div class="accordion-body">
                                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                                        <p><span>Monday - Friday:</span> 07:00AM - 4:30PM</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about-village-sec common-sec">
    <div class="container-fluid g-0">
        <div class="row g-0">
            <div class="col-xl">
                <div class="about-village-con">
                    <div class="sec-head">
                        <h2 class="sec-title mb-0 wow animate__fadeInUp">Frisco Medical Village</h2>
                    </div>
                    <div class="cms-con wow animate__fadeInUp" data-wow-delay=".1s">
                        <p>Welcome to Village Health Partners-Frisco Medical Village, dedicated to providing quality medical care to our community by meeting the needs of each and every patient with respect and professional service. As a one-stop comprehensive medical village we offer a variety of services ranging from family medicine, women's and men's health, pediatrics, radiology, lab services, dermatology, gynecology and more. This progressive approach behind a medical village allows patients to have all of their medical needs met in one location, eliminating the need to travel to different doctor offices. Our goal is to provide a warm and compassionate environment that inspires mutual trust and confidence from our patients. Our physicians are known for their strong commitment to patient education. Through education, we enable and encourage our patients to become active participants in their healthcare.</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-auto text-end">
                <div class="about-village-img d-inline-block wow animate__fadeInRight" data-wow-delay=".2s">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/about-village.jpg" alt="about-village-img">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="providers-sec common-sec">
    <div class="container">
        <div class="sec-head text-center">
            <h3 class="sec-title mb-0 wow animate__fadeInUp" data-wow-delay=".1s">Learn more about the providers at Frisco Medical Village Clinic</h3>
        </div>
        <div class="providers-list">
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".2s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-1.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Dr. Bradley Sprenger</h5>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".3s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-2.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Dr. Heather Sheffield</h5>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".4s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-3.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Dr. Jacob Standard</h5>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".5s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-4.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Dr. Jamison Albracht</h5>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".6s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-5.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Dr. Madhavi Ampajwala</h5>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".7s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-6.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Brett Driver</h5>
                    <span class="providers-item-sub-title">FNP-C Advanced Practitioner</span>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".8s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-7.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Seethu Abraham</h5>
                    <span class="providers-item-sub-title">FNP-C Advanced Practitioner</span>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
            <div class="providers-item wow animate__fadeInUp" data-wow-delay=".9s">
                <div class="providers-item-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctors-8.jpg" alt="doctor-img">
                </div>
                <div class="providers-item-con">
                    <h5 class="providers-item-title">Sweta Manek</h5>
                    <span class="providers-item-sub-title">FNP-C Advanced Practitioner</span>
                </div>
                <a href="#" class="btn btn-outline-orange">View Details</a>
            </div>
        </div>
    </div>
</section>
<section class="services-sec common-sec bg-grey">
    <div class="container">
        <div class="sec-head text-center">
            <h4 class="sec-title mb-0 wow animate__fadeInUp">Services: Your Title Goes Here</h4>
        </div>
        <div class="services-boxes">
            <div class="services-box wow animate__fadeInLeft" data-wow-delay="0.1s">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="services-box-img">
                            <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/services-1.jpg" alt="service-img">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="services-box-con">
                            <h5 class="services-box-title">Telehealth</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing. Vestibulum nibh est, semper eu turpis in, gravida lobortis purus. Etiam tincidunt eleifend purus, in.</p>
                        </div>
                        <a href="#" class="btn-link-yellow">Learn more <span class="arrow-right"></span></a>
                    </div>
                </div>
            </div>
            <div class="services-box wow animate__fadeInRight" data-wow-delay="0.2s">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="services-box-img">
                            <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/services-2.jpg" alt="service-img">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="services-box-con">
                            <h5 class="services-box-title">Lab Services</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing. Vestibulum nibh est, semper eu turpis in, gravida lobortis purus. Etiam tincidunt eleifend purus, in.</p>
                        </div>
                        <a href="#" class="btn-link-yellow">Learn more <span class="arrow-right"></span></a>
                    </div>
                </div>
            </div>
            <div class="services-box wow animate__fadeInLeft" data-wow-delay="0.3s">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="services-box-img">
                            <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/services-3.jpg" alt="service-img">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="services-box-con">
                            <h5 class="services-box-title">Urgent Care</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing. Vestibulum nibh est, semper eu turpis in, gravida lobortis purus. Etiam tincidunt eleifend purus, in.</p>
                        </div>
                        <a href="#" class="btn-link-yellow">Learn more <span class="arrow-right"></span></a>
                    </div>
                </div>
            </div>
            <div class="text-center">
                <a href="#" class="btn btn-yellow wow animate__fadeInUp" data-wow-delay="0.5s">View All</a>
            </div>
        </div>
    </div>
</section>
<section class="insurance-sec common-sec">
    <div class="container">
        <div class="sec-head text-center">
            <h4 class="sec-title wow animate__fadeInUp">Insurance</h4>
            <p class="wow animate__fadeInUp" data-wow-delay=".1s">Our Physicians are in-network and contracted with the major insurance companies including HMO, PPO, Medicare and Medicare Advantage plans at select locations. Please visit their websites to verify your benefits coverage.</p>
        </div>
        <div class="insurance-boxes">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".2s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-1.jpg" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".3s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-2.jpg" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".4s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-3.jpg" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".5s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-4.jpg" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".6s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-5.jpg" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".7s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-6.jpg" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".8s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-7.jpg" alt="insurance-img">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="write-review-sec common-sec position-relative">
    <div class="container-fluid">
        <div class="write-review-con wow animate__fadeInUp">
            <div class="write-review-box d-flex align-items-center justify-content-between">
                <div class="write-review-img">
                    <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/vhp.jpg" alt="write-review-img">
                </div>
                <p>Rating <b>5.0</b> <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/5-stars.svg" alt="stars" /> 56 Reviews</p>
            </div>
            <div class="text-center">
                <a href="#" class="btn btn-orange wow animate__fadeInUp" data-wow-delay=".1s">Write Review</a>
            </div>
        </div>
    </div>
</section>
<?php
get_footer();
?>