<?php /* Template Name: Individual Bio */
get_header();
$path = get_stylesheet_directory_uri();
?>

<div class="find-location-nav-btns">
    <button type="button" onclick="getLocation()" class="btn btn-outline-secondary nearBy">Near me</button>
    <button type="button" onclick="getOpenToday()" class="btn btn-outline-secondary openNow">Open Now</button>
    <button type="button" onclick="getInsurance()" class="btn btn-outline-secondary insuranceAcc">Insurance Accepted</button>
</div>


<div id="locations-inputs">
    <input type="hidden" id="user-lat" value="">
    <input type="hidden" id="user-lon" value="">
    <input type="hidden" id="user-open-now" value="">
    <input type="hidden" id="user-insurance" value="">
</div>


<div>
    <input type="checkbox" id="sort-by-location" name="sort_by_location">
    <label for="sort-by-location">Sort by Current Location</label>
</div>
<div>
    <input type="checkbox" id="sort-by-hours" name="sort_by_hours">
    <label for="sort-by-hours">Sort by Current Opening Hours</label>
</div>
<div>
    <input type="checkbox" id="sort-by-insurance" name="sort_by_insurance">
    <label for="sort-by-insurance">Show Only Posts with Insurance Accepted</label>
</div>

<button id="sort-posts">Sort Posts</button>
<div id="sorted-posts"></div>



<script>
    jQuery('#locations-inputs input').val('');
    function getLocation() {
        jQuery('.nearBy').toggleClass('active');
        var openNow = jQuery('#user-open-now').val();
        var insurance = jQuery('#user-insurance').val();

        if (jQuery('.nearBy').hasClass('active')) {
            jQuery('#user-lat').val(23.0923318);
            jQuery('#user-lon').val(72.5286857);
            var latitude = jQuery('#user-lat').val();
            var longitude = jQuery('#user-lon').val();
        }else{
            jQuery('#user-lat').val('');
            jQuery('#user-lon').val('');
            var latitude = '';
            var longitude = '';
        }

        // if (navigator.geolocation) {
        //     navigator.geolocation.getCurrentPosition(function(position) {
        //         var latitude = position.coords.latitude;
        //         var longitude = position.coords.longitude;
        //         jQuery('#user-lat').val(latitude);
        //         jQuery('#user-lon').val(longitude);
        //         console.log("Latitude: " + latitude + "<br>Longitude: " + longitude);
        //         //   document.getElementById("location").innerHTML = "Latitude: " + latitude + "<br>Longitude: " + longitude;
        //     });
        // } else {
        //     alert("Geolocation is not supported by this browser.");
        // }

        locationFilter(latitude, longitude, openNow, insurance);
    }

    function getOpenToday() {
        var latitude = jQuery('#user-lat').val()
        var longitude = jQuery('#user-lon').val();
        var openNow = jQuery('#user-open-now').val();
        var insurance = jQuery('#user-insurance').val();

        // console.log("Latitude: " + latitude + "<br>Longitude: " + longitude);
        locationFilter(latitude, longitude, openNow, insurance);
    }

    function getInsurance() {
        jQuery('.insuranceAcc').toggleClass('active');

        var latitude = jQuery('#user-lat').val()
        var longitude = jQuery('#user-lon').val();
        var openNow = jQuery('#user-open-now').val();
        var insurance = jQuery('.insuranceAcc').hasClass('active') ? '1' : '';
        jQuery('#user-insurance').val(insurance);
        locationFilter(latitude, longitude, openNow, insurance);
    }


    function locationFilter(latitude, longitude, openNow, insurance) {
        console.log("Latitude: " + latitude + "<br>Longitude: " + longitude + "<br>Open Now: " + openNow + "<br>Insurance: " + insurance);

        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'sort_posts_by_criteria',
                    lat: latitude,
                    lon: longitude,
                    sort_by_hours: openNow,
                    sort_by_insurance: insurance,
                })
            })
            .then(response => response.text())
            .then(data => {
                document.getElementById('location-wrapeer').innerHTML = data;
            })
            .catch(error => console.error('Error:', error));
    }

    // document.getElementById('sort-posts').addEventListener('click', function() {
    //     let lat = 23.0923318;
    //     let lon = 72.5286857;

    //     let sortByLocation = document.getElementById('sort-by-location').checked;
    //     let sortByHours = document.getElementById('sort-by-hours').checked;
    //     let sortByInsurance = document.getElementById('sort-by-insurance').checked;

    //     fetch('<?php //echo admin_url('admin-ajax.php'); ?>', {
    //             method: 'POST',
    //             headers: {
    //                 'Content-Type': 'application/x-www-form-urlencoded',
    //             },
    //             body: new URLSearchParams({
    //                 action: 'sort_posts_by_criteria',
    //                 lat: lat,
    //                 lon: lon,
    //                 sort_by_location: sortByLocation,
    //                 sort_by_hours: sortByHours,
    //                 sort_by_insurance: sortByInsurance,
    //             })
    //         })
    //         .then(response => response.text())
    //         .then(data => {
    //             document.getElementById('sorted-posts').innerHTML = data;
    //         })
    //         .catch(error => console.error('Error:', error));
    // });
</script>

 
<section class="bio-sec">
    <div class="container-fluid">
        <div class="bio-inner">
            <div class="row align-items-center flex-row-reverse">
                <div class="col-sm-12 col-lg-6">
                    <div class="profile-box">
                        <div class="profile wow animate__fadeInUp" data-wow-delay="0.1s">
                            <img class="profile-img" src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/profile-img.jpg" alt="profile-img">
                            <div class="profile-info-img">
                                <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/profile-info.png" alt="profile-info">
                            </div>
                        </div>
                        <p class=" wow animate__fadeInUp" data-wow-delay="0.2s">Northeast Tarrant Internal Medicine <br>Associates, Fort Worth Clinic</p>
                        <h3 class="profile-title wow animate__fadeInUp" data-wow-delay="0.3s">Dr. Mai F. Sharaf</h3>
                        <div class="profile-rate wow animate__fadeInUp" data-wow-delay="0.4s">
                            <label>Rating <span>5.0</span></label>
                            <div class="stars"><img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/5-stars.svg" alt=""></div>
                            <span>56 Reviews</span>
                        </div>
                        <div class="profile-btns  wow animate__fadeInUp" data-wow-delay="0.5s">
                            <a href="tel:817-283-2888" class="btn btn-outline-orange">Call: <span class="text-decoration-underline">817-283-2888</span></a>
                            <a href="#" title="Book Online" class="btn btn-orange">Book Online</a>
                        </div>

                    </div>
                </div>
                <div class="col-sm-12 col-lg-6">
                    <div class="bio-con">
                        <div class="sec-head">
                            <h1 class="sec-title  wow animate__fadeInUp" data-wow-delay="0.1s">Dr. Mai F. Sharaf</h1>
                            <p class=" wow animate__fadeInUp" data-wow-delay="0.2s">I am a board-certified in internal medicine physician with more than 20 years experience. As a physician, I believe we must listen to our patients and recognize their specific concerns to construct a successful health plan individualized to address their individual needs.</p>
                            <a href="#" title="Patient Portal" class="btn btn-yellow wow animate__fadeInUp" data-wow-delay="0.3s">Patient Portal</a>
                        </div>

                        <ul class="bio-info  wow animate__fadeInUp" data-wow-delay="0.4s">
                            <li>
                                <span>Education:</span>
                                Bachelor of Science, <br>University of Arkansas
                            </li>
                            <li>
                                <span>Degree:</span>
                                Doctor of Medicine, University of <br>Arkansas for Medical Sciences
                            </li>
                            <li>
                                <span>Specialty:</span>
                                Internal Medicine
                            </li>
                            <li>
                                <span>Languages:</span>
                                English
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>



    </div>
</section>


<section class="professional-organizations-sec pt-0">
    <div class="container-fluid">
        <h3 class="professional-title  wow animate__fadeInUp" data-wow-delay="0.1s">Professional Organizations</h3>
        <ul class="professional-list">
            <li class=" wow animate__fadeInUp" data-wow-delay="0.1s">
                <div class="professional-box">
                    ABIM Board Certified
                </div>
            </li>
            <li class=" wow animate__fadeInUp" data-wow-delay="0.2s">
                <div class="professional-box">
                    Fellow of the American College of Physicians
                </div>
            </li>
            <li class=" wow animate__fadeInUp" data-wow-delay="0.3s">
                <div class="professional-box">
                    Member of Tarrant County Medical Society
                </div>
            </li>
        </ul>
    </div>
</section>

<section class="bio-location-sec">
    <div class="container-fluid">
        <div class="row flex-row-reverse align-items-center">
            <div class="col-md-12 col-lg-7 col-xl-8">
                <div class="map  wow animate__fadeInUp" data-wow-delay="0.2s">
                    <img src="<?php echo $path; ?>/assets/img/map-img.jpg" alt="map-img">
                </div>
            </div>
            <div class="col-md-12 col-lg-5 col-xl-4">
                <div class="bio-location-details">
                    <div class="loc-row location-del wow animate__fadeInUp" data-wow-delay="0.1s">
                        <div class="loc-icon">
                            <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/location-icon.svg" alt="location-icon">
                        </div>
                        <div class="loc-dtl">
                            <label>Location:</label>
                            <span>Northeast Tarrant Internal Medicine Associates, Fort Worth Clinic</span>
                        </div>
                    </div>
                    <div class="loc-row  wow animate__fadeInUp" data-wow-delay="0.2s">
                        <div class="loc-icon">
                            <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/phone-icon.svg" alt="phone-icon">
                        </div>
                        <div class="loc-dtl">
                            <label>Phone:</label>
                            <a href="tel:2143878288">214-387-8288</a> <br>
                            <label>Fax:</label>
                            <a href="tel:2143878288">214-387-8289</a>
                        </div>
                    </div>

                    <div class="loc-row location-del  wow animate__fadeInUp" data-wow-delay="0.3s">
                        <div class="loc-icon">
                            <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/clock-icon.svg" alt="clock-icon">
                        </div>
                        <div class="loc-dtl">
                            <label>NEIMA Fort Worth Clinic:</label>
                            <div class="time-row">
                                <span>Monday:</span> 07:00AM - 4:30PM
                            </div>
                            <div class="time-row">
                                <span>Tuesday:</span> 07:00AM - 4:30PM
                            </div>
                            <div class="time-row">
                                <span>Wednesday:</span> 07:00AM - 4:30PM
                            </div>
                            <div class="time-row">
                                <span>Thursday:</span> 07:00AM - 4:30PM
                            </div>
                            <div class="time-row">
                                <span>Friday:</span> 07:00AM - 4:30PM
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<section class="providers-video-sec">
    <div class="container-fluid">
        <div class="sec-head text-center wow animate__fadeInUp" data-wow-delay="0.1s">
            <h2 class="sec-title">Provider Video</h2>
        </div>
        <div class="provider-video-sl wow animate__fadeInUp" data-wow-delay="0.2s">
            <div class="provider-video-box">
                <iframe src="https://player.vimeo.com/video/515823563" width="100%" height="518" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</section>

<section class="write-review-sec common-sec bio-write-review-sec position-relative pt-0">
    <div class="container-fluid">
        <div class="write-review-con wow animate__fadeInUp">
            <div class="write-review-box d-flex align-items-center justify-content-between">
                <div class="write-left">
                    <div class="write-review-img">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/doctor-review-profile.png" alt="doctor-review-profile">
                    </div>
                    <h4 class="review-title">Dr. Mai F. Sharaf</h4>
                </div>
                <p>Rating <b>5.0</b> <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/5-stars.svg" alt="stars" /> 56 Reviews</p>
            </div>
            <div class="text-center">
                <a href="#" class="btn btn-orange wow animate__fadeInUp" data-wow-delay=".1s" title="Write Review">Write Review</a>
            </div>
        </div>
    </div>
</section>

<section class="insurance-sec bio-insurance-sec common-sec gray-bg">
    <div class="container">
        <div class="sec-head text-center">
            <h4 class="sec-title wow animate__fadeInUp">Insurance</h4>
            <p class="wow animate__fadeInUp" data-wow-delay=".1s">Our Physicians are in-network and contracted with the major insurance companies including HMO, PPO, Medicare and Medicare Advantage plans at select locations. Please visit their websites to verify your benefits coverage.</p>
        </div>
        <div class="insurance-boxes">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".2s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img1-min.png" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".3s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img2-min.png" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".4s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img3-min.png" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".5s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img4-min.png" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".6s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img5-min.png" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".7s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img6-min.png" alt="insurance-img">
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".8s">
                        <img src="http://192.168.0.128/catalyst/wp-content/uploads/2024/06/insurance-img7-min.png" alt="insurance-img">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php
get_footer();
?>