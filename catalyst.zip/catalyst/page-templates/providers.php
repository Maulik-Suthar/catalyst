<?php /* Template Name: Providers */
get_header();

$path = get_stylesheet_directory_uri();
$hero_title = get_field('banner_title');
$hero_desc = get_field('banner_description');
$hero_img = get_field('banner_img');

if ($hero_title || $hero_desc ||  $hero_img) :
?>
    <section class="find-providers-sec">
        <div class="container-fluid">
            <div class="find-providers-inr" style="background-image: url(<?php echo $hero_img['url']; ?>);">
                <div class="find-providers-con">
                    <div class="sec-head">
                        <h1 class="sec-title wow animate__fadeInUp"><?php echo $hero_title ?></h1>
                        <p class="wow animate__fadeInUp" data-wow-delay=".1s"><?php echo $hero_desc ?></p>
                    </div>
                </div>
                <div class="filter-wrap">
                    <?php include get_template_directory() . '/inc/provider-form.php'; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>






<section id="providers" class="providers-sec leadership-sec common-sec">
    <div class="container">
        <div class="accordion" id="providerData">
            <?php
            //$provider_name = isset($_GET['provider_name']) ? sanitize_text_field($_GET['provider_name']) : '';
            //$last_page = providers_data_get($provider_name, 1);
            ?>
            <?php
                $default_posts_per_page = get_option('posts_per_page');
                session_start();
                $providerIds = isset($_SESSION['open_post_ids']) ? $_SESSION['open_post_ids'] : array();


                $searchCityZip = isset($_GET['search']) ? esc_attr($_GET['search']) : '';

                if ($_GET['search'] && empty($providerIds)) {
                    $_SESSION['open_post_ids'] = array();
                    header("location:".site_url()."/providers/");
                }

                $args_provi = array(
                    'post_type'      => 'provider',
                    'post_status'    => 'publish',
                    'posts_per_page' => -1,
                );
                $argsTotalNumbers = new WP_Query($args_provi);
                $ProviderTotalPages = ceil($argsTotalNumbers->found_posts / $default_posts_per_page);

                if ($searchCityZip && $providerIds) {
                    $args_provi['posts_per_page'] = $default_posts_per_page;
                    $args_provi['post__in'] = $providerIds[0];
                    $args_provi['orderby'] = 'post__in';
                } else {
                    $args_provi['posts_per_page'] = $default_posts_per_page;
                    $args_provi['meta_key'] = 'last_name';
                    $args_provi['orderby'] = 'meta_value';
                    $args_provi['order'] = 'ASC';
                }

                $args_provi_loop = new WP_Query($args_provi);
                if ($args_provi_loop->have_posts()) {
                    while ($args_provi_loop->have_posts()) {
                        $args_provi_loop->the_post();
                        get_template_part('template-parts/content', 'provider');
                    }
                    wp_reset_postdata();
                } else {
                    wp_send_json_error('No providers found.');
                }
                ?>
        </div>
        <?php if ($ProviderTotalPages > 1): ?>
            <div class="text-center mt-5">
                <button id="get_providers" type="button" class="btn-link btn-dark" data-last="<?php echo $ProviderTotalPages; ?>">Load more providers</button>
            </div>
        <?php endif ?>

        

    </div>
</section>
<?php
get_footer();
?>


<script>
    jQuery(document).ready(function($) {
        if ($('#providers-container').length >= $('#load-more-button').data('last')) {
            $('#load-more-button').hide();
        }

        var search = '<?php echo $provider_name; ?>';
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
        var currentPage = 2;
        $('#load-more-button').click(function(e) {
            e.preventDefault();
            var $this = $(this);
            $this.text('Loading...');
            $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {
                    action: 'provider_loadmore', // Note the change here
                    security: '<?php echo wp_create_nonce('provider_loadmore'); ?>',
                    search: search,
                    page: currentPage
                },
                success: function(response) {
                    if (response) {
                        $('#providers-container').append(response.data.html);
                        currentPage++;
                        if (response.data.page >= $('#load-more-button').data('last')) {
                            $('#load-more-button').hide();
                        } else {
                            $this.text('Load more providers');
                        }
                    } else {
                        $this.hide();
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                }
            });
        });


        var activeProvidePage = 1;
        $('#get_providers').click(function(e) {
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {
                    action: 'load_more_provi',
                    page: activeProvidePage,
                    search: '<?php echo $searchCityZip; ?>'
                },
                success: function(response) {
                    if (response) {
                        activeProvidePage++;
                        $('#providerData').append(response);
                        if (activeProvidePage == $('#get_providers').data('last')) {
                            $('#get_providers').hide();
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                }
            });
        });



    });
</script>