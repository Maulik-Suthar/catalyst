<?php /* Template Name: Medicare */
get_header();
$path = get_stylesheet_directory_uri();
?>
<?php
$banner_title = get_field('banner_title');
$banner_description = get_field('banner_description');
$banner_button = get_field('banner_button');
$banner_image = get_field('banner_image');
?>
<section class="medicare-sec">
    <div class="container-fluid">
        <div class="medicare-sec-inr" style="background-image: url('<?php echo $banner_image['url']; ?>');">
            <?php if ($banner_image != '') { ?>
                <div class="medicare-image d-sm-none">
                    <img src="<?php echo $banner_image['url']; ?>" alt="<?php echo $banner_image['alt']; ?>">
                </div>
            <?php } ?>
            <div class="medicare-con">
                <div class="sec-head">
                    <?php echo ($banner_title != '') ? '<h1 class="sec-title">' . $banner_title . '</h1>' : ''; ?>
                    <?php echo ($banner_description != '') ? '<p>' . $banner_description . '</p>' : ''; ?>
                </div>
                <?php if ($banner_button != '') : ?>
                    <a href="<?php echo $banner_button['url']; ?>" target="<?php echo ($banner_button['target'] != '') ? $banner_button['target'] : '_self'; ?>" class="btn btn-orange">Learn More</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php
$essentials_title = get_field('essentials_title');
$essentials_description = get_field('essentials_description');
$essentials_left_image = get_field('essentials_left_image');
$essentials_right_image = get_field('essentials_right_image');

if ($essentials_title && $essentials_description && $essentials_left_image && $essentials_right_image) : ?>
    <section class="essentials-sec common-sec">
        <div class="container">
            <div class="essentials-con">
                <div class="sec-head text-center mb-0">
                    <?php if ($essentials_title != '') { ?>
                        <h2 class="sec-title"><?php echo $essentials_title; ?></h2>
                    <?php } ?>
                    <?php if ($essentials_description != '') { ?>
                        <p><?php echo $essentials_description; ?></p>
                    <?php } ?>
                </div>
                <?php if ($essentials_left_image != '') { ?>
                    <div class="essentials-left-img">
                        <img src="<?php echo $essentials_left_image['url']; ?>" alt="<?php echo $essentials_left_image['alt']; ?>">
                    </div>
                <?php } ?>
                <?php if ($essentials_right_image != '') { ?>
                    <div class="essentials-right-img">
                        <img src="<?php echo $essentials_right_image['url']; ?>" alt="<?php echo $essentials_right_image['alt']; ?>">
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if (have_rows('benefits')) : ?>
    <section class="medicare-parts-sec common-sec">
        <div class="container-fluid">
            <div class="medicare-parts-slider swiper">
                <div class="swiper-wrapper">
                    <?php $i = 1;
                    while (have_rows('benefits')) : the_row(); ?>
                        <?php
                        $benefits_color_select = get_sub_field('benefits_color_select');
                        $benefits_name = get_sub_field('benefits_name');
                        $benefits_info = get_sub_field('benefits_info');
                        $benefits_image = get_sub_field('benefits_image');
                        $benefits_icon = get_sub_field('benefits_icon');
                        ?>
                        <?php if (!empty($benefits_name) && !empty($benefits_info) && !empty($benefits_image) && !empty($benefits_icon)) : ?>
                            <div class="swiper-slide <?php echo $benefits_color_select; ?>">
                                <div class="swiper-slide-img">
                                    <img src="<?php echo $benefits_image['url']; ?>" alt="<?php echo $benefits_image['alt']; ?>">
                                </div>
                                <div class="swiper-slide-icon">
                                    <img src="<?php echo $benefits_icon['url']; ?>" alt="<?php echo $benefits_icon['alt']; ?>">
                                </div>
                                <div class="swiper-slide-con">
                                    <div class="swiper-slide-title"><?php echo $benefits_name; ?></div>
                                    <p class="mb-0"><?php echo $benefits_info; ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>
<?php endif; ?>
<?php
$enroll_description = get_field('enroll_description');
$enroll_image = get_field('enroll_image');
if (!empty($enroll_description) && !empty($enroll_image)) : ?>
    <section class="enroll-medicare-sec">
        <div class="container-fluid">
            <div class="enroll-medicare-inr">
                <div class="row align-items-center g-0 flex-row-reverse">
                    <?php if (!empty($enroll_image)) : ?>
                        <div class="col-lg-6">
                            <div class="enroll-medicare-img">
                                <img src="<?php echo $enroll_image['url']; ?>" alt="<?php echo $enroll_image['alt']; ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($enroll_description)) : ?>
                        <div class="col-lg-6">
                            <div class="enroll-medicare-con">
                                <div class="cms-con mb-0">
                                    <?php echo $enroll_description; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$obligation_title = get_field('obligation_title');
$obligation_button = get_field('obligation_button');
$obligation_image = get_field('obligation_image');
?>
<?php if (!empty($obligation_title) && !empty($obligation_button) && !empty($obligation_image)) : ?>
    <section class="no-obligation-sec common-sec">
        <div class="container">
            <div class="no-obligation-inr">
                <?php if (!empty($obligation_image)) : ?>
                    <div class="no-obligation-img">
                        <img src="<?php echo $obligation_image['url']; ?>" alt="<?php echo $obligation_image['alt']; ?>">
                    </div>
                <?php endif; ?>
                <div class="no-obligation-con text-center">
                    <?php if (!empty($obligation_title)) : ?>
                        <div class="sec-head">
                            <div class="sec-title"><?php echo $obligation_title; ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($obligation_button)) : ?>
                        <a href="<?php echo $obligation_button['url']; ?>" target="<?php echo ($obligation_button['target'] != '') ? $obligation_button['target'] : '_self' ?>" class="btn btn-orange">Learn More</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
get_footer();
?>