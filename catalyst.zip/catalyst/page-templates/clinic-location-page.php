<?php /* Template Name: Clinic Location Page */
get_header();
$path = get_stylesheet_directory_uri();
?>

<section class="clinic-detsils-sec common-sec">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="clinic-detsils-slider">
					<div class="clinic-detsils-main">
						<div class="clinic-slider-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical.jpg" alt="">
						</div>
						<div class="clinic-slider-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical4.jpg" alt="">
						</div>
						<div class="clinic-slider-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical2.jpg" alt="">
						</div>
						<div class="clinic-slider-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical4.jpg" alt="">
						</div>
						<div class="clinic-slider-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical.jpg" alt="">
						</div>
					</div>
					<div class="clinic-detsils-nav">
						<div class="clinic-slider-nav-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical-nav.jpg" alt="">
						</div>
						<div class="clinic-slider-nav-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical-nav2.jpg" alt="">
						</div>
						<div class="clinic-slider-nav-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical-nav3.jpg" alt="">
						</div>
						<div class="clinic-slider-nav-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical-nav4.jpg" alt="">
						</div>
						<div class="clinic-slider-nav-img">
							<img src="http://192.168.29.101/catalyst/wp-content/uploads/2024/06/frisco-medical-nav.jpg" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<script>
	jQuery(document).ready(function($) {
		$('.clinic-detsils-main').slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: false,
			fade: true,
			infinite: true,
			autoplay: true,
			autoplaySpeed: 2000,
			asNavFor: '.clinic-detsils-nav'
		});
		$('.clinic-detsils-nav').slick({
			slidesToShow: 4,
			slidesToScroll: 1,
			asNavFor: '.clinic-detsils-main',
			dots: true,
			infinite: true,
			autoplay: true,
			autoplaySpeed: 2000,
			focusOnSelect: true
		});
	});
</script>
<?php
get_footer();
?>