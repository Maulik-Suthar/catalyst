<?php /* Template Name: Careers */
get_header();
$path = get_stylesheet_directory_uri();
?>

<?php
$join_us_title = get_field('join_us_title');
$join_us_details = get_field('join_us_details');
$apply_now_btn = get_field('apply_now_btn');
$join_us_image = get_field('join_us_image');
if ($join_us_title || $join_us_details || $apply_now_btn || $join_us_image) :
?>
    <section class="join-us-sec">
        <div class="container-fluid">
            <div class="join-us-inner">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="join-us-con">
                            <?php if (!empty($join_us_title)) { ?>
                                <div class="sec-head  wow animate__fadeInUp" data-wow-delay="0.1s">
                                    <h1 class="sec-title"><?php echo $join_us_title ?></h1>
                                </div>
                            <?php } ?>
                            <?php if (!empty($join_us_details)) { ?>
                                <p class="wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $join_us_details ?></p>
                            <?php } ?>
                            <?php if (!empty($apply_now_btn)) { ?>
                                <a href="<?php echo $apply_now_btn['url']; ?>" target="<?php echo $apply_now_btn['target']; ?>" class="btn btn-orange  wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $apply_now_btn['title']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <?php if (!empty($join_us_image)) { ?>
                            <div class="join-us-img">
                                <img src="<?php echo $join_us_image['url']; ?>" alt="<?php echo $join_us_image['alt']; ?>" />
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$clinical_services_title = get_field('clinical_services_title');
if (have_rows('clinical_services_list')) :
?>
    <section class="clinical-services-sec common-sec">
        <div class="container-fluid">
            <?php if (!empty($clinical_services_title)) { ?>
                <div class="sec-head">
                    <h2 class="sec-title wow animate__fadeInUp" data-wow-delay="0.1s"><?php echo $clinical_services_title ?></h2>
                </div>
            <?php } ?>
            <div class="row">
                <?php
                $count = 1;
                while (have_rows('clinical_services_list')) : the_row();
                    $services_image = get_sub_field('services_image');
                    $services_name = get_sub_field('services_name');
                    $services_details = get_sub_field('services_details');
                    $count1 = $count / 10;
                ?>
                    <div class="col-md-4 col-sm-6  wow animate__fadeInUp" data-wow-delay="<?php echo $count1; ?>s">
                        <div class="clinical-services-box">
                            <?php if (!empty($services_image)) { ?>
                                <div class="clinical-services-img">
                                    <img src="<?php echo $services_image['url']; ?>" alt="<?php echo $services_image['alt']; ?>" />
                                </div>
                            <?php } ?>
                            <div class="clinical-services-con">
                                <?php if (!empty($services_name)) { ?>
                                    <h3 class="clinical-services-title"><?php echo $services_name ?></h3>
                                <?php } ?>
                                <?php echo $services_details ?>
                            </div>
                        </div>
                    </div>
                <?php $count++;
                endwhile; ?>

            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$reputation_title = get_field('reputation_title');
if (have_rows('reputation_list')) :
?>
    <section class="reputation-sec common-sec pt-0">
        <div class="container-fluid">
            <?php if (!empty($reputation_title)) { ?>
                <div class="sec-head  wow animate__fadeInUp" data-wow-delay="0.1s">
                    <h2 class="sec-title text-center"><?php echo $reputation_title ?></h2>
                </div>
            <?php } ?>
            <div class="row">
                <?php
                $item = 1;
                while (have_rows('reputation_list')) : the_row();
                    $reputation_icon = get_sub_field('reputation_icon');
                    $reputation_label = get_sub_field('reputation_label');
                    $reputation_name = get_sub_field('reputation_name');
                    $item1 = $item / 10;
                ?>
                    <div class="col-md-3 col-6 reputation-col wow animate__fadeInUp" data-wow-delay="<?php echo $item1; ?>s">
                        <div class="reputation-box">
                            <?php if (!empty($reputation_icon)) { ?>
                                <div class="reputation-icon">
                                    <img src="<?php echo $reputation_icon['url']; ?>" alt="<?php echo $reputation_icon['alt']; ?>" />
                                </div>
                            <?php } ?>
                            <div class="reputation-con">
                                <?php if (!empty($reputation_label)) { ?>
                                    <span class="reputation-label"><?php echo $reputation_label ?></span>
                                <?php } ?>
                                <?php if (!empty($reputation_name)) { ?>
                                    <h3 class="reputation-title"><?php echo $reputation_name ?></h3>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php $item++;
                endwhile; ?>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php
$join_team_image = get_field('join_team_image');
$join_team_title = get_field('join_team_title');
$join_team_details = get_field('join_team_details');
$join_team_btn = get_field('join_team_btn');
if ($join_team_image || $join_team_title || $join_team_details || $join_team_btn) :
?>
    <section class="join-team-sec common-sec pt-0">
        <div class="container-fluid">
            <div class="join-team-inner">
                <div class="row align-items-center flex-row-reverse">
                    <div class="col-sm-6">
                        <?php if (!empty($join_team_image)) { ?>
                            <div class="join-team-img wow animate__fadeInRight" data-wow-delay="0.1s">
                                <img src="<?php echo $join_team_image['url']; ?>" alt="<?php echo $join_team_image['alt']; ?>" />
                            </div>
                        <?php } ?>
                    </div>
                    <div class="col-sm-6">
                        <div class="join-team-con">
                            <div class="sec-head wow animate__fadeInUp" data-wow-delay="0.1s">
                                <?php if (!empty($join_team_title)) { ?>
                                    <h2 class="sec-title">
                                        <?php echo $join_team_title ?>
                                    </h2>
                                <?php } ?>
                            </div>
                            <?php if (!empty($join_team_details)) { ?>
                                <div class="cms-con wow animate__fadeInUp" data-wow-delay="0.2s">
                                    <?php echo $join_team_details ?>
                                </div>
                            <?php } ?>
                            <?php if (!empty($join_team_btn)) { ?>
                                <a href="<?php echo $join_team_btn['url']; ?>" target="<?php echo $join_team_btn['target']; ?>" class="btn btn-orange  wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $join_team_btn['title']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$caring_culture_title = get_field('caring_culture_title');
$caring_culture_details = get_field('caring_culture_details');
$caring_culture_img_first = get_field('caring_culture_img_first');
$caring_culture_img_second = get_field('caring_culture_img_second');
$caring_culture_img_third = get_field('caring_culture_img_third');
if ($caring_culture_title || $caring_culture_details || $caring_culture_img_first || $caring_culture_img_second || $caring_culture_img_third) :
?>
    <section class="caring-sec">
        <div class="container-fluid g-0">
            <div class="row align-items-center g-0">
                <div class="col-sm-6">
                    <div class="caring-con">
                        <div class="sec-head">
                            <?php if (!empty($caring_culture_title)) { ?>
                                <h2 class="sec-title wow animate__fadeInUp" data-wow-delay="0.1s"><?php echo $caring_culture_title ?></h2>
                            <?php } ?>
                            <?php if (!empty($caring_culture_details)) { ?>
                                <p class="wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $caring_culture_details ?></p>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="caring-img-wrap">
                        <?php if (!empty($caring_culture_img_first)) { ?>
                            <div class="caring-img">
                                <img src="<?php echo $caring_culture_img_first['url']; ?>" alt="<?php echo $caring_culture_img_first['alt']; ?>" />
                            </div>
                        <?php } ?>
                        <?php if (!empty($caring_culture_img_second)) { ?>
                            <div class="caring-img">
                                <img src="<?php echo $caring_culture_img_second['url']; ?>" alt="<?php echo $caring_culture_img_second['alt']; ?>" />
                            </div>
                        <?php } ?>
                        <?php if (!empty($caring_culture_img_third)) { ?>
                            <div class="caring-img">
                                <img src="<?php echo $caring_culture_img_third['url']; ?>" alt="<?php echo $caring_culture_img_third['alt']; ?>" />
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
if (have_rows('company_healthcare_list')) :
?>
    <section class="company-paid-sec common-sec">
        <div class="container-fluid">
            <div class="company-paid-inner">
                <ul class="company-paid-list">
                    <?php
                    $comcount = 1;
                    while (have_rows('company_healthcare_list')) : the_row();
                        $company_healthcare_title = get_sub_field('company_healthcare_title');
                        $company_healthcare_details = get_sub_field('company_healthcare_details');
                        $comcount1 = $comcount / 10;
                    ?>
                        <li class="wow animate__fadeInUp" data-wow-delay="<?php echo $comcount1; ?>s">
                            <?php if (!empty($company_healthcare_title)) { ?>
                                <div class="company-title"><?php echo $company_healthcare_title ?></div>
                            <?php } ?>
                            <?php if (!empty($company_healthcare_details)) { ?>
                                <p><?php echo $company_healthcare_details ?></p>
                            <?php } ?>
                        </li>
                    <?php $comcount++;
                    endwhile; ?>
                </ul>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$faqs_title = get_field('faqs_title');
$faqs_description = get_field('faqs_description');
if ($faqs_title || $faqs_description) :
?>
    <section class="faq-head-sec career-faq-head-sec">
        <div class="container">
            <div class="sec-head text-center">
                <span class="sec-sub-title">FAQs</span>
                <?php if (!empty($faqs_title)) { ?>
                    <h2 class="sec-title"><?php echo $faqs_title ?></h2>
                <?php } ?>
                <?php if (!empty($faqs_description)) { ?>
                    <p class="faq-head-description"><?php echo $faqs_description ?></p>
                <?php } ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
if (have_rows('faq_list')) :
?>
    <section class="faq-sec common-sec career-faq-sec">
        <div class="container">
            <div class="faq-wrapper">
                <div class="accordion" id="faqOne">
                    <?php
                    $faqList = 1;
                    while (have_rows('faq_list')) : the_row(); ?>
                        <div class="accordion-item">
                            <button class="accordion-button <?php echo ($faqList == 1) ? '' : 'collapsed'; ?>" data-bs-toggle="collapse" data-bs-target="#faq-<?php echo $faqList; ?>">
                                <span><?php the_sub_field('faq_title'); ?></span>
                                <span class="faq-arrow"></span>
                            </button>
                            <div id="faq-<?php echo $faqList; ?>" class="accordion-collapse collapse <?php echo ($faqList == 1) ? 'show' : ''; ?>" data-bs-parent="#faqOne">
                                <div class="cms-con">
                                    <?php the_sub_field('faq_details'); ?>
                                </div>
                            </div>
                        </div>
                    <?php $faqList++;
                    endwhile; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
get_footer();
?>