<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */

get_header();
?>

<section class="newly-blog-sec common-sec">
	<div class="container-fluid g-0">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="sec-head">
					<h1 class="sec-title wow animate__fadeInUp" data-wow-delay=".1s">
						Stay Informed <br>with Our Insights
					</h1>
					<p class="wow animate__fadeInUp" data-wow-delay=".2s">Welcome to the Catalyst Physician Group Blog, your go-to resource for the latest in healthcare news, wellness tips, and updates from our community.</p>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="swiper newly-blog-slider wow animate__fadeInRight" data-wow-delay=".1s">
					<div class="swiper-wrapper">
						<?php
						$loop = new WP_Query(array('meta_key' => '_is_ns_featured_post', 'meta_value' => 'yes'));
						while ($loop->have_posts()) : $loop->the_post(); ?>
							<div class="swiper-slide">
								<a href="<?php the_permalink(); ?>" class="newly-blog-img d-block">
									<?php if (has_post_thumbnail()) {
										the_post_thumbnail('full');
									?>
									<?php } else { ?>
										<img src="<?php echo get_template_directory_uri(); ?>/assets/img/no-img.jpg" alt="">
									<?php } ?>
									<span><?php the_title('') ?></span>
								</a>
							</div>
						<?php endwhile;
						wp_reset_postdata();
						?>
					</div>
				</div>
				<div class="newly-blog-arrow">
					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="blog-listing common-sec pt-0">
	<div class="container">
		<div class="blog-listing-filter">
			<form role="search" method="get" class="search-form" action="<?php echo site_url(); ?>">
				<div class="blog-listing-filter-search filter-box wow animate__fadeInUp">
					<label for="blog-search" class="invisible">Search</label>
					<input class="form-control border-0 bg-transparent search-field" id="blog-search" type="search" placeholder="Search for a Post" value="<?php echo get_search_query(); ?>" name="s">
					<input type="hidden" name="post_type" value="post">
					<button type="submit" class="btn-square btn-blue search-submit"><i class="icon-search"></i> <span class="d-none">Search</span></button>
				</div>
			</form>
			<div class="blog_category position-relative">
				<span class="selectFilter d-md-none">Select Category</span>
				<?php echo blog_category_list(); ?>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<?php
		if (have_posts()) :
			echo '<div id="posts-container" class="row justify-content-center">';
			while (have_posts()) : the_post();
				echo '<div class="col-xxl-3 col-xl-4 col-lg-3 col-lg-4 col-sm-6">';
				get_template_part('template-parts/content', 'post');
				echo '</div>';
			endwhile;
			wp_reset_postdata();
			echo '</div>';
		else :
			get_template_part('template-parts/content', 'none');
		endif;
		?>
		<div class="row">
			<div class="col-12 text-center">
				<button id="load-more" type="button" class="btn-link btn-dark wow animate__fadeInUp" data-wow-delay=".1s">Load more posts</button>
			</div>
		</div>
	</div>
</section>


<?php
get_footer();
