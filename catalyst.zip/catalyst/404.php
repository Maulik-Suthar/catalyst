<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package catalyst
 */

get_header();
?>

<section class="error-sec d-flex align-items-center">
	<div class="container">
		<div class="error-con">
			<div class="error-head">
				<div>
					<h1 class="error-title wow fadeInUp" data-wow-delay="0.2s">
						<b>4<span>0</span>4</b>
					</h1>
				</div>
				<div>
					<h2 class="error-subtitle wow fadeInUp" data-wow-delay="0.3s">Page Not Found</h2>
				</div>
				<div class="wow fadeInUp" data-wow-delay="0.4s">
					<p>We're sorry. the page you requested could not be found. Please go back to the home page.</p>
				</div>
				<div>
					<a href="<?php echo site_url(); ?>" class="btn btn-orange wow fadeInUp" data-wow-delay="0.5s">Go Home</a>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
