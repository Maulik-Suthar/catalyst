<?php

/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */

?>
<div class="services-row row wow animate__fadeInUp" data-wow-delay="0.1s">
	<div class="col-sm-6">
		<div class="services-left">
			<a href="<?php echo get_the_permalink(); ?>" class="services-img">
				<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php echo get_the_title(); ?>">
			</a>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="services-con">
			<div class="sec-head">
				<h3 class="sec-title"><?php echo get_the_title(); ?></h3>
				<p><?php echo get_the_excerpt(); ?></p>
			</div>
			<a href="<?php echo get_the_permalink(); ?>" title="Learn more" class="learn-more-btn">Learn more <span></span></a>
		</div>
	</div>
</div>