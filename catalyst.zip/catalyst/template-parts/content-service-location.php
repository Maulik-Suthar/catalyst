<?php

/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */
$noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';
$loc_title = get_the_title($post->ID);
$loc_phone = get_field('phone');
$loc_phone_text = get_field('phone_text');
$clinic_image = get_field('clinic_image');
$loc_address = get_field('address');
$loc_state = get_field('state');
$loc_city = get_field('city');
$loc_zip = get_field('zipcode');
$loc_logo = get_field('clinic_logo', $post->ID);
$loc_logo_final = get_term_meta($loc_logo, 'logo', true);
//$opening_hours = get_field('opening_hours', $post->ID);
$placeId = get_field('place_id', $post->ID);

$appointment_title = get_field('appointment_title');
$one_line_hours = get_field('one_line_hours');
$one_line_after_hours = get_field('one_line_after_hours');
$insurance_accepted = get_field('insurance_accepted');
$posts[] = $post;
// $places_details = fetch_google_place_details();
// print_r($workingHours);

$review_location_zero = get_field('review_location_zero', $post->ID);
$reviewActive = '';
$elfsight_reviews = get_field('elfsight_location', $post->ID);
if (!$review_location_zero) {
    if ($elfsight_reviews) {
        $reviewActive = $elfsight_reviews;
    } else {
        $reviewActive = '';
    }
}


$currentDay = date('l');
$todayHours = '';
$opening_hours = get_field($currentDay, $post->ID);
if (!empty($opening_hours['hour']['start']) && !empty($opening_hours['hour']['end'])) {
    $todayHours = 'Open today ' . $opening_hours['hour']['start'] . ' - ' . $opening_hours['hour']['end'];
} else {
    $todayHours = 'Today closed';
}

if ($clinic_image) {
    $first_image_url = $clinic_image[0]['url'];
} else {
    $first_image_url = $noImg;
}
// $lat = get_field('latitude');
// $lng = get_field('longitude');

// $location = array(
//     'position' => array(
//         'lat' => (float)$lat,
//         'lng' => (float)$lng,
//     ),
//     'title' => $loc_title,
//     'imageUrl' => $first_image_url,
//     'url' => get_permalink($post->ID)
// );
// $locations[] = $location;


?>

<div class="col-sm-6 our-locations-col">
    <div class="our-locations-box" id="<?php echo $placeId; ?>">
        <a class="our-locations-img" href="<?php the_permalink(); ?>">
            <img src="<?php echo $first_image_url; ?>" alt="<?php echo $loc_title; ?>">
        </a>
        <div class="our-locations-con">
            <?php
            if (is_page_template('page-templates/pediatric-services.php') && $appointment_title) {
                $tag = "Village Pediatrics, ";
                if (str_replace($tag, "", $appointment_title) == true) :
                    echo '<div class="our-location-title">' . ltrim($appointment_title, $tag) . '</div>';
                else :
                    echo '<div class="our-location-title">' . $appointment_title . '</div>';
                endif;
            } else {
                echo '<div class="our-location-title">' . $appointment_title . '</div>';
            }
            ?>
            <ul>
                <li><?php echo $loc_address; ?>, <?php echo $loc_city; ?>, <?php echo $loc_state; ?> <?php echo $loc_zip; ?></li>
                <?php if (!empty($loc_phone)) : ?>
                    <li><span><?php if (!empty($loc_phone_text)) : ?>Text: <a href="sms:<?php echo str_replace(array(' ', '-'), '', $loc_phone_text); ?>"><?php echo $loc_phone_text; ?></a> | <?php endif; ?>Call: <a href="tel:<?php echo str_replace(array(' ', '-'), '', $loc_phone); ?>"><?php echo $loc_phone; ?></a></span></li>
                <?php endif; ?>
                <?php
                if (is_page_template('page-templates/after-hours.php') && $one_line_after_hours) {
                    echo '<li>' . $one_line_after_hours . '</li>';
                }
                if (is_page_template('page-templates/pediatric-services.php') && $one_line_hours) {
                    echo '<li>' . $one_line_hours . '</li>';
                }
                ?>
            </ul>
        </div>
    </div>
</div>