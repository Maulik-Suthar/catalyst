<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */

?>

<div class="col-12">
	<div class="not-found-sec">
		<div class="error-con sec-head text-center">
			<h1 class="sec-title">Data Not Found</h1>
		</div>
	</div>
</div>

