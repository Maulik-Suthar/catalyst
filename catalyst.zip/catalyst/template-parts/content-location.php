<?php

/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */
$noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';
$loc_title = get_the_title($post->ID);
$loc_phone = get_field('phone');
$clinic_image = get_field('clinic_image');
$loc_address = get_field('address');
$loc_state = get_field('state');
$loc_city = get_field('city');
$loc_zip = get_field('zipcode');
$loc_logo = get_field('clinic_logo', $post->ID);
$loc_logo_final = get_term_meta($loc_logo, 'logo', true);
$loc_small_logo_final = get_term_meta($loc_logo, 'small_logo', true);

//$opening_hours = get_field('opening_hours', $post->ID);
$placeId = get_field('place_id', $post->ID);

$insurance_accepted = get_field('insurance_accepted');
$posts[] = $post;
// $places_details = fetch_google_place_details();
// print_r($workingHours);

$review_location_zero = get_field('review_location_zero', $post->ID);
$reviewActive = '';
$elfsight_reviews = get_field('elfsight_location', $post->ID);
if (!$review_location_zero) {
    if ($elfsight_reviews) {
        $reviewActive = $elfsight_reviews;
    } else {
        $reviewActive = '';
    }
}


$currentDay = date('l');
$todayHours = '';
$opening_hours = get_field($currentDay, $post->ID);
if (!empty($opening_hours['hour']['start']) && !empty($opening_hours['hour']['end'])) {
    $todayHours = 'Open today ' . $opening_hours['hour']['start'] . ' - ' . $opening_hours['hour']['end'];
} else {
    $todayHours = 'Today closed';
}

if ($clinic_image) {
    $first_image_url = $clinic_image[0]['url'];
} else {
    $first_image_url = $noImg;
}
// $lat = get_field('latitude');
// $lng = get_field('longitude');

// $location = array(
//     'position' => array(
//         'lat' => (float)$lat,
//         'lng' => (float)$lng,
//     ),
//     'title' => $loc_title,
//     'imageUrl' => $first_image_url,
//     'url' => get_permalink($post->ID)
// );
// $locations[] = $location;
?>
<div class="find-location-bx " id="<?php echo $placeId; ?>">
    <a class="find-location-bx-img d-block" href="<?php the_permalink(); ?>">
        <img src="<?php echo $first_image_url; ?>" alt="<?php echo $loc_title; ?>">
        <?php /* if ($loc_logo_final) : ?>
            <div class="find-location-bx-img-ftr">
                <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
            </div>
        <?php endif; */ ?>
        <?php if ($loc_small_logo_final) : ?>
            <div class="find-location-bx-img-ftr-small">
                <?php echo wp_get_attachment_image($loc_small_logo_final, 'full'); ?>
            </div>
        <?php endif; ?>
    </a>
    <div class="find-location-bx-con">
        <div class="find-location-bx-title"> <a href="<?php the_permalink(); ?>"><?php echo $loc_title; ?></a></div>

        <?php /*if (!empty($places_details[$placeId]['rating']) && $places_details[$placeId]['rating'] !== 'N/A') : ?>
            <span class="find-location-bx-rating"><i class="icon icon-star"></i><span class="rating"><?php echo $places_details[$placeId]['rating']; ?></span></span>
        <?php endif; */ ?>
        <?php /*if ($reviewActive != '') : ?>
            <span class="find-location-bx-rating"><i class="icon icon-star"></i> <span class="rating"><?php echo $reviewActive; ?></span></span>
        <?php endif; */ ?>
        <ul>
            <li><?php echo $loc_address; ?>, <?php echo $loc_city; ?>, <?php echo $loc_state; ?> <?php echo $loc_zip; ?></li>
            <?php if (!empty($loc_phone)) : ?>
                <li><a href="tel:<?php echo str_replace(array(' ', '-'), '', $loc_phone); ?>"><?php echo $loc_phone; ?></a></li>
            <?php endif; ?>
            <!-- <li><?php //echo $todayHours; 
                        ?></li> -->
        </ul>
        <a href="javascript:;" class="select-location btn-link btn-secondary">View Location</a>
    </div>
</div>