<?php

/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */

$noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';
$profile_img = get_the_post_thumbnail_url();
$profile_title = get_the_title();
$location = get_field('location');
$info = get_field('info');
$education = get_field('education');
$designation = get_field('designation');
$degree = get_field('degree');
$specialty = get_field('specialty');
$languages = get_field('languages');


?>
<div class="accordion-item ">
    <div class="providers-item wow animate__fadeInUp" data-wow-delay=".2s">
        <div class="providers-item-img">
            <a href="<?php echo get_the_permalink(); ?>">
                <img src="<?php echo ($profile_img != '') ? $profile_img : $noImg; ?>" alt="<?php echo $profile_title; ?>">
            </a>
        </div>
        <div class="providers-item-con">
            <div class="providers-item-title"><a href="<?php echo get_the_permalink(); ?>"><?php echo $profile_title; ?><?php echo ($degree != '') ? ', ' . $degree : ''; ?></a></div>
            <?php if (is_page_template('page-templates/about.php') && $designation) : ?>
                <span class="providers-item-sub-title"><?php echo $designation; ?></span>
            <?php elseif ($specialty) : ?>
                <span class="providers-item-sub-title"><?php echo $specialty; ?></span>
            <?php endif; ?>
        </div>
        <?php
        if (is_page_template('page-templates/about.php')) {
        ?>
            <button class="btn btn-outline-orange accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#provider-<?php echo $post->ID; ?>" aria-expanded="false" aria-controls="provider-<?php echo $post->ID; ?>">View Details</button>
        <?php
        } else {
        ?>
            <a href="<?php the_permalink(); ?>" class="btn btn-outline-orange">View Details</a>
        <?php
        }
        ?>
    </div>
    <?php
    if (is_page_template('page-templates/about.php')) {
    ?>
        <div id="provider-<?php echo $post->ID; ?>" class="accordion-collapse collapse " data-bs-parent="#leadershipAccordion">
            <div class="accordion-body">
                <?php if ($info) : ?>
                    <div class="providers-description">
                        <?php echo $info; ?>
                    </div>
                <?php endif; ?>
                <ul class="providers-info-list">
                    <?php if ($location) :
                        //print_r($location);
                        foreach ($location as $locationIndex => $locationID) {
                            $locationBind = $locationIndex + 1;
                            $loc_title = get_the_title($locationID);
                            $loc_address = get_field('address', $locationID);
                    ?>
                            <li>
                                <div class="providers-info-title">Location <?php echo (count($location) > 1) ? $locationBind : ''; ?>:</div>
                                <div class="providers-info-description"><?php echo $loc_title; ?></div>
                                <a href="<?php the_permalink($locationID); ?>" title="Go To Location" class="providers-info-link">View Location</a>
                            </li>
                    <?php }
                    endif; ?>
                    <?php if ($education) : ?>
                        <li>
                            <div class="providers-info-title">Education:</div>
                            <div class="providers-info-description"><?php echo $education; ?></div>
                        </li>
                    <?php endif; ?>
                    <?php if ($degree) : ?>
                        <li>
                            <div class="providers-info-title">Degree:</div>
                            <div class="providers-info-description"><?php echo $degree; ?></div>
                        </li>
                    <?php endif; ?>
                    <?php if ($specialty) : ?>
                        <li>
                            <div class="providers-info-title">Specialty:</div>
                            <div class="providers-info-description"><?php echo $specialty; ?></div>
                        </li>
                    <?php endif; ?>
                    <?php if ($languages) : ?>
                        <li>
                            <div class="providers-info-title">Languages:</div>
                            <div class="providers-info-description"><?php echo $languages; ?></div>
                        </li>
                    <?php endif; ?>
                </ul>
                <div>
                    <a href="<?php the_permalink(); ?>" target="" class="btn btn-orange mt-5">View More</a>
                </div>
            </div>

        </div>
    <?php
    } else {
    }
    ?>

</div>