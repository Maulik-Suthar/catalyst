<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package catalyst
 */

?>
<?php $blog_thumbnail_image = get_field('blog_thumbnail_image'); ?>

<a href="<?php the_permalink(); ?>" class="newsbox">
    <div class="news-img">
        <?php if (!empty($blog_thumbnail_image)) { ?>            
                <img src="<?php echo $blog_thumbnail_image['url']; ?>" alt="<?php echo $blog_thumbnail_image['alt']; ?>" />            
        <?php } else if (has_post_thumbnail()){
            the_post_thumbnail('full');
        } else { ?>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/no-img.jpg" alt="">
        <?php } ?>
    </div>
    <div class="news-con">
        <div class="newscon-inner">
            <?php /*
                $categories = get_the_category();
                if (!empty($categories) && $categories[0]->name !== 'Uncategorized') {
                ?>
                    <span class="news-cat">
                        <?php echo esc_html($categories[0]->name); ?>
                    </span>
                <?php
                }
                */ ?>
            <div class="news-title"><?php the_title('') ?></div>
            <div class="new-bottom">
                <span class="news-date"><?php catalyst_posted_on(); ?></span>
                <span class="readmore-btn">Read more</span>
            </div>
        </div>
    </div>
</a>