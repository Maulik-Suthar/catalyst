<?php

/**
 * catalyst functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package catalyst
 */

if (!defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function catalyst_setup()
{
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on catalyst, use a find and replace
		* to change 'catalyst' to the name of your theme in all the template files.
		*/
	load_theme_textdomain('catalyst', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support('title-tag');

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__('Primary', 'catalyst'),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'catalyst_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'catalyst_setup');


// Add CORS Headers
function add_cors_http_header()
{
	// Allow from any origin
	if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header("Access-Control-Allow-Credentials: true");
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
		header("Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Requested-With");
	}

	// Handle OPTIONS request method
	if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
		if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
			header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
		}
		if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
			header("Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Requested-With");
		}
		exit(0);
	}
}
add_action('init', 'add_cors_http_header');



add_action('send_headers', 'set_permissions_policy_header');
function set_permissions_policy_header()
{
	// Remove existing Permissions-Policy headers in a case-insensitive manner
	foreach (headers_list() as $header) {
		if (stripos($header, 'Permissions-Policy') !== false) {
			header_remove($header);
		}
	}

	// Set the new Permissions-Policy header
	header("Permissions-Policy: geolocation=(self 'https://cpg-endpoint-gkfre4gybvhpc8e7.z02.azurefd.net' 'https://cpg-wp.azurewebsites.net' 'https://maps.googleapis.com')");
}
add_action('send_headers', 'set_permissions_policy_header');


// function SearchFilter($query){
// 	if ($query->is_search) {
// 		$query->set('post_type', 'post');
// 	}
// 	return $query;
// }
// add_filter('pre_get_posts', 'SearchFilter');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function catalyst_content_width()
{
	$GLOBALS['content_width'] = apply_filters('catalyst_content_width', 640);
}
add_action('after_setup_theme', 'catalyst_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function catalyst_widgets_init()
{
	register_sidebar(
		array(
			'name'          => esc_html__('Sidebar', 'catalyst'),
			'id'            => 'sidebar-1',
			'description'   => esc_html__('Add widgets here.', 'catalyst'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action('widgets_init', 'catalyst_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function catalyst_scripts()
{
	wp_enqueue_style('catalyst-style', get_stylesheet_uri(), array(), _S_VERSION);
	wp_style_add_data('catalyst-style', 'rtl', 'replace');

	wp_enqueue_script('jquery');

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'catalyst_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}

/* Add ACF Theme Setting */
if (function_exists('acf_add_options_page')) {
	acf_add_options_page(array(
		'page_title' 	=> 'Theme General Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
}


function my_login_logo()
{ ?>
	<style type="text/css">
		#login h1 a,
		.login h1 a {
			background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/img/site-login-logo.png);
			height: 100px;
			width: 250px;
			background-size: 250px 100px;
			background-repeat: no-repeat;
			padding-bottom: 0;
		}

		body.login #login {
			width: 400px;
			padding: 25px;
			margin: auto;
			border: 1px solid;
			top: 50%;
			transform: translateY(-50%);
			position: relative;
			background: #FFECAF;
			border: 1px solid #f25830;
			border-radius: 25px;
			box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
		}
	</style>
<?php }
add_action('login_enqueue_scripts', 'my_login_logo');

function admin_style()
{ ?>
	<style type="text/css">
		#location_categoriesdiv {
			display: none;
		}
	</style>
	<?php  }
add_action('admin_enqueue_scripts', 'admin_style');

require get_template_directory() . '/inc/opening-hours.php';


function blog_category_list()
{
	$categories = get_categories();
	$current_cat_id = get_query_var('cat');
	$output = '<ul class="filterDropdown">';
	$class = is_home() ? 'active' : '';
	$output .= '<li><a class="blogcate_btn ' . $class . '" href="' . get_permalink(get_option('page_for_posts')) . '" title="View All Posts">All Posts</a></li>';
	foreach ($categories as $category) {
		if ($category->name !== 'Uncategorized') {
			$class = '';
			if ($category->term_id == $current_cat_id) {
				$class = 'active';
			}
			$output .= '<li><a class="blogcate_btn ' . $class . '" href="' . get_category_link($category->term_id) . '" title="View ' . $category->name . '">' . $category->name . '</a></li>';
		}
	}
	$output .= '</ul>';
	echo $output;
}


// Locations post type
function location_register_post_type()
{
	$args = [
		'label'  => esc_html__('Locations', 'catalyst'),
		'labels' => [
			'menu_name'          => esc_html__('Locations', 'catalyst'),
			'name_admin_bar'     => esc_html__('Location', 'catalyst'),
			'add_new'            => esc_html__('Add Location', 'catalyst'),
			'add_new_item'       => esc_html__('Add new Location', 'catalyst'),
			'new_item'           => esc_html__('New Location', 'catalyst'),
			'edit_item'          => esc_html__('Edit Location', 'catalyst'),
			'view_item'          => esc_html__('View Location', 'catalyst'),
			'update_item'        => esc_html__('View Location', 'catalyst'),
			'all_items'          => esc_html__('All Locations', 'catalyst'),
			'search_items'       => esc_html__('Search Locations', 'catalyst'),
			'parent_item_colon'  => esc_html__('Parent Location', 'catalyst'),
			'not_found'          => esc_html__('No Locations found', 'catalyst'),
			'not_found_in_trash' => esc_html__('No Locations found in Trash', 'catalyst'),
			'name'               => esc_html__('Locations', 'catalyst'),
			'singular_name'      => esc_html__('Location', 'catalyst'),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'hierarchical'        => false,
		'has_archive'         => false,
		'query_var'           => true,
		'menu_icon'           => 'dashicons-location-alt',
		'can_export'          => true,
		'rewrite'             => true,
		'capability_type'     => 'post',
		'menu_position'       => 4,
		'supports' => [
			'title',
			'thumbnail',
		]
	];

	register_post_type('location', $args);
}

add_action('init', 'location_register_post_type');


function location_taxonomy()
{
	register_taxonomy(
		'location_categories',
		'location',
		array(
			'hierarchical' => true,
			'label' => 'Location Category',
			'query_var' => true
		)
	);
}
add_action('init', 'location_taxonomy');

function insurance_taxonomy()
{
	register_taxonomy(
		'insurance_categories',
		'location',
		array(
			'hierarchical' => true,
			'label' => 'Insurances',
			'query_var' => true
		)
	);
}
add_action('init', 'insurance_taxonomy');


function get_location_data($post, $locId)
{
	$lat = get_field('latitude', $locId);
	$lng = get_field('longitude', $locId);
	$clinic_image = get_field('clinic_image', $locId);
	$noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';

	$loc_title = get_the_title($locId);
	if ($clinic_image) {
		$first_image_url = $clinic_image[0]['url'];
	} else {
		$first_image_url = $noImg;
	}
	$location_url = get_permalink($locId);
	$location = array(
		'position' => array(
			'lat' => (float) $lat,
			'lng' => (float) $lng,
		),
		'title' => $loc_title,
		'imageUrl' => $first_image_url,
		'url' => $location_url,
	);

	return $location;
}



// Providers post type
function provider_register_post_type()
{
	$args = [
		'label'  => esc_html__('Providers', 'catalyst'),
		'labels' => [
			'menu_name'          => esc_html__('Providers', 'catalyst'),
			'name_admin_bar'     => esc_html__('Provider', 'catalyst'),
			'add_new'            => esc_html__('Add Provider', 'catalyst'),
			'add_new_item'       => esc_html__('Add new Provider', 'catalyst'),
			'new_item'           => esc_html__('New Provider', 'catalyst'),
			'edit_item'          => esc_html__('Edit Provider', 'catalyst'),
			'view_item'          => esc_html__('View Provider', 'catalyst'),
			'update_item'        => esc_html__('View Provider', 'catalyst'),
			'all_items'          => esc_html__('All Providers', 'catalyst'),
			'search_items'       => esc_html__('Search Providers', 'catalyst'),
			'parent_item_colon'  => esc_html__('Parent Provider', 'catalyst'),
			'not_found'          => esc_html__('No Providers found', 'catalyst'),
			'not_found_in_trash' => esc_html__('No Providers found in Trash', 'catalyst'),
			'name'               => esc_html__('Providers', 'catalyst'),
			'singular_name'      => esc_html__('Provider', 'catalyst'),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'hierarchical'        => false,
		'has_archive'         => false,
		'query_var'           => true,
		'menu_icon'           => 'dashicons-id-alt',
		'can_export'          => true,
		'rewrite'             => true,
		'capability_type'     => 'post',
		'menu_position'       => 5,
		'supports' => [
			'title',
			'thumbnail',
		]
	];

	register_post_type('provider', $args);
}

add_action('init', 'provider_register_post_type');



// Services post type
function service_register_post_type()
{
	$args = [
		'label'  => esc_html__('Services', 'catalyst'),
		'labels' => [
			'menu_name'          => esc_html__('Services', 'catalyst'),
			'name_admin_bar'     => esc_html__('Service', 'catalyst'),
			'add_new'            => esc_html__('Add Service', 'catalyst'),
			'add_new_item'       => esc_html__('Add new Service', 'catalyst'),
			'new_item'           => esc_html__('New Service', 'catalyst'),
			'edit_item'          => esc_html__('Edit Service', 'catalyst'),
			'view_item'          => esc_html__('View Service', 'catalyst'),
			'update_item'        => esc_html__('View Service', 'catalyst'),
			'all_items'          => esc_html__('All Services', 'catalyst'),
			'search_items'       => esc_html__('Search Services', 'catalyst'),
			'parent_item_colon'  => esc_html__('Parent Service', 'catalyst'),
			'not_found'          => esc_html__('No Services found', 'catalyst'),
			'not_found_in_trash' => esc_html__('No Services found in Trash', 'catalyst'),
			'name'               => esc_html__('Services', 'catalyst'),
			'singular_name'      => esc_html__('Service', 'catalyst'),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'hierarchical'        => true,
		'has_archive'         => true,
		'query_var'           => true,
		'menu_icon'           => 'dashicons-clipboard',
		'can_export'          => true,
		'rewrite'               => array('slug' => 'services', 'with_front' => true),
		'capability_type'       => 'post',
		'menu_position'       => 4,
		'supports' => [
			'title',
			'thumbnail',
			'editor',
		]
	];

	register_post_type('service', $args);
}

add_action('init', 'service_register_post_type');


// ================== Blog page function
// Enqueue script and localize AJAX URL
function enqueue_custom_scripts()
{
	global $wp_query;
	wp_enqueue_script('blog-script', get_stylesheet_directory_uri() . '/assets/js/blog-script.js', array('jquery'), null, true);
	wp_localize_script('blog-script', 'loadmore_params', array(
		'ajaxurl' => admin_url('admin-ajax.php'),
		'posts_per_page' => get_option('posts_per_page'),
		'current_page' => get_query_var('paged') ? get_query_var('paged') : 1,
		'query' => json_encode($wp_query->query_vars),
		'max_pages' => ($wp_query->found_posts > 0 && $wp_query->post_count > 0) ? ceil($wp_query->found_posts / $wp_query->post_count) : 1,
		'security' => wp_create_nonce('load_more_posts_nonce')
	));
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');

// AJAX handler for loading more posts
function load_more_posts()
{
	check_ajax_referer('load_more_posts_nonce', 'security');
	$args = json_decode(stripslashes($_POST['query']), true);
	$args['paged'] = $_POST['page'] + 1;
	$args['post_status'] = 'publish';

	$query = new WP_Query($args);

	if ($query->have_posts()) :
		while ($query->have_posts()) : $query->the_post();
			echo '<div class="col-xxl-3 col-xl-4 col-lg-3 col-lg-4 col-sm-6">';
			get_template_part('template-parts/content', 'post');
			echo '</div>';
		endwhile;
	endif;
	die;
}
add_action('wp_ajax_loadmore', 'load_more_posts');
add_action('wp_ajax_nopriv_loadmore', 'load_more_posts');



function get_locations_metafileds($post_type = 'location', $meta_key = 'place_id')
{
	$args = array(
		'post_type'      => $post_type,
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'meta_key' => $meta_key,
		'orderby' => 'meta_value',
		'order'   => 'ASC',
		'fields' => 'ids',
	);
	$query = new WP_Query($args);
	$meta_id = array();
	if ($query->have_posts()) {
		foreach ($query->posts as $post_id) {
			$city = get_post_meta($post_id, $meta_key, true);
			if (!empty($city) && !in_array($city, $meta_id)) {
				$meta_id[] = $city;
			}
		}
	}
	return $meta_id;
}

function sort_posts_by_criteria()
{
	if (isset($_POST['sort_by_hours'])) {
		$sort_by_hours = $_POST['sort_by_hours'];
		$locationIds = json_decode($sort_by_hours);
	}
	$location_result = '';
	if (isset($_POST['location_name'])) {
		$location_name = $_POST['location_name'];
		/*
		global $wpdb;
		$location_name_sql = $wpdb->prepare("
		SELECT DISTINCT p.ID as post_id, p.post_title
		FROM {$wpdb->posts} p
		LEFT JOIN {$wpdb->postmeta} pm_city ON p.ID = pm_city.post_id AND pm_city.meta_key = 'city'
		LEFT JOIN {$wpdb->postmeta} pm_zip ON p.ID = pm_zip.post_id AND pm_zip.meta_key = 'zipcode'
		WHERE (p.post_title LIKE %s
		OR pm_city.meta_value LIKE %s
		OR pm_zip.meta_value LIKE %s)
		AND p.post_type = 'location'
		AND p.post_status = 'publish'
	", '%' . $wpdb->esc_like($location_name[0]) . '%', '%' . $wpdb->esc_like($location_name[0]) . '%', '%' . $wpdb->esc_like($location_name[0]) . '%');

		$location_result = $wpdb->get_results($location_name_sql);

		$location_names = array();
		foreach ($location_result as $result) {
			$post = get_post($result->post_id);
			$location_names[] = $post->post_name;
		}
		*/
	}

	if (isset($_POST['sort_by_insurance'])) {
		$sort_by_insurance = filter_var($_POST['sort_by_insurance'], FILTER_VALIDATE_BOOLEAN);
	}

	if (isset($_POST['location_cat'])) {
		$location_cat = $_POST['location_cat'];
	}

	$user_lat = isset($_POST['lat']) ? floatval($_POST['lat']) : null;
	$user_lon = isset($_POST['lon']) ? floatval($_POST['lon']) : null;
	$map_radial = isset($_POST['map_radial']) ? floatval($_POST['map_radial']) : null;


	//echo $current_time;
	$meta_query = array(
		'relation' => 'AND'
	);

	if ($sort_by_insurance) {
		$meta_query[] = array(
			'key' => 'insurance_accepted',
			'value' => '1',
			'compare' => 'EXISTS',
		);
	}

	/*
	if ($_POST['search_type'] == 'loc_city') {
		$meta_query = array('relation' => 'OR');
		foreach ($location_name as $location) {
			$meta_query[] = array(
				'relation' => 'OR',
				array(
					'key'     => 'city',
					'value'   => $location,
					'compare' => '='
				),
				// array(
				// 	'key'     => 'zipcode',
				// 	'value'   => $location,
				// 	'compare' => '='
				// )
			);
		}
	}
	*/

	if ($location_cat) {
		$meta_query[] = array(
			'key' => 'clinic_logo',
			'value' => $location_cat,
			'compare' => 'EXISTS',
		);
	}

	$args = array(
		'post_type' => 'location',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'post__in' => $locationIds,
		'orderby' => 'title',
		'order'   => 'ASC',
		'meta_query' => $meta_query,
	);

	if ($location_name) {
		$args['post_name__in'] = $location_name;
	}

	$query = new WP_Query($args);

	if ($query->have_posts()) {
		while ($query->have_posts()) {
			$query->the_post();
			$lat = get_post_meta(get_the_ID(), 'latitude', true);
			$lon = get_post_meta(get_the_ID(), 'longitude', true);

			// $opening_hours = get_field('opening_hours', get_the_ID());
			$noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';
			$clinic_image = get_field('clinic_image', get_the_ID());

			$loc_logo = get_field('clinic_logo', get_the_ID());
			$loc_logo_final = get_term_meta($loc_logo, 'logo', true);

			$distance = null;
			if ($lat && $lon) {
				$distance = haversineGreatCircleDistance($user_lat, $user_lon, $lat, $lon);
			}

			$currentDay = date('l');
			$todayHours = '';
			$opening_hours = get_field($currentDay, $post->ID);
			if (!empty($opening_hours['hour']['start']) && !empty($opening_hours['hour']['end'])) {
				$todayHours = 'Open today ' . $opening_hours['hour']['start'] . ' - ' . $opening_hours['hour']['end'];
			} else {
				$todayHours = 'Today closed';
			}


			if ($clinic_image) {
				$first_image_url = $clinic_image[0]['url'];
			} else {
				$first_image_url = $noImg;
			}

			$loc_logo_final = get_term_meta($loc_logo, 'small_logo', true);
			//$places_details = fetch_google_place_details();

			$posts[] = array(
				'id' => get_the_ID(),
				'title' => get_the_title(),
				'url' => get_the_permalink(),
				'lat' => $lat,
				'lon' => $lon,
				'distance' => $distance,
				'clinic_image' => $first_image_url,
				'logo' => $loc_logo_final,
				'phone' => get_field('phone', get_the_ID()),
				'address' => get_field('address', get_the_ID()),
				'state' => get_field('state', get_the_ID()),
				'city' => get_field('city', get_the_ID()),
				'zipcode' => get_field('zipcode', get_the_ID()),
				'placeId' => get_field('place_id', get_the_ID()),
				'insurance_accepted' => get_field('insurance_accepted', get_the_ID()),
				'reviews_zero' => get_field('review_location_zero', get_the_ID()),
				'reviews' => get_field('elfsight_location', get_the_ID()),
				'hours' => $todayHours,
			);
		}
		wp_reset_postdata();
	}

	if ($user_lat && $user_lat) {
		$mapMilesSorting = $map_radial / 1000 * 0.621371;
		$posts = array_filter($posts, function ($post) use ($lat, $lon, $mapMilesSorting) {
			$distance = $post['distance'];
			return $distance <= $mapMilesSorting;
		});
		usort($posts, function ($a, $b) {
			return $a['distance'] - $b['distance'];
		});
	}

	if ($posts) {
		if (!$user_lat && !$user_lon) {
			usort($posts, function ($a, $b) {
				return strcmp($a['title'], $b['title']);
			});
		}
	}

	ob_start();
	foreach ($posts as $post) {
		if ($sort_by_insurance && !$post['insurance_accepted']) {
			continue;
		}
		$location_data = get_location_data($post, $post['id']);
		$locations[] = $location_data;
	?>
		<div class="find-location-bx" id="<?php echo $post['placeId']; ?>">
			<!-- <a class="find-location-bx-link" ></a> -->
			<a class="find-location-bx-img d-block" href="<?php echo $post['url']; ?>">
				<img src="<?php echo $post['clinic_image']; ?>" alt="<?php echo $post['clinic_image']; ?>">
				<?php if ($post['logo']) : ?>
					<div class="find-location-bx-img-ftr-small">
						<?php echo wp_get_attachment_image($post['logo'], 'full'); ?>
					</div>
				<?php endif; ?>
			</a>
			<div class="find-location-bx-con">
				<div class="find-location-bx-title"><a href="<?php echo $post['url']; ?>"><?php echo $post['title']; ?></a></div>
				<?php /* if (!$post['reviews_zero']) : ?>
					<?php if ($post['reviews']) : ?>
						<span class="find-location-bx-rating"><i class="icon icon-star"></i> <span class="rating"><?php echo $post['reviews']; ?></span></span>
					<?php endif; ?>
				<?php endif; */ ?>
				<?php /* if (!empty($places_details[$post['placeId']]['rating']) && $places_details[$post['placeId']]['rating'] !== 'N/A') : ?>
					<span class="find-location-bx-rating"><i class="icon icon-star"></i><span class="rating"><?php echo $places_details[$post['placeId']]['rating']; ?></span></span>
				<?php endif; */ ?>
				<ul>
					<li><?php echo $post['address']; ?>, <?php echo $post['city']; ?>, <?php echo $post['state']; ?> <?php echo $post['zipcode']; ?></li>
					<?php if (!empty($post['phone'])) : ?>
						<li><a href="tel:<?php echo $post['phone']; ?>"><?php echo $post['phone']; ?></a></li>
					<?php endif; ?>
					<!-- <li><?php //echo $post['hours']; 
								?></li> -->
					<?php
					if ($user_lat && $user_lon) {
						if (!empty($post['distance'])) : ?>
							<li>Distance: <?php echo number_format($post['distance'], 2); ?> miles</li>
					<?php endif;
					}
					?>
				</ul>
				<a href="javascript:;" class="btn-link btn-secondary select-location">View Location</a>
			</div>
		</div>
<?php
	}
	$output = ob_get_clean();

	if (!empty($locationIds) || $sort_by_hours == '0') {
		$locations = $locations;
		$currentLatLon = [$user_lat, $user_lon];
		if ($output) {
			$output = $output;
		} else {
			$output = '<p>The record does not exist within the selected criteria.</p>';
		}
	} else {
		$locations = [];
		$output = '<p>No locations open right now</p>';
	}

	wp_send_json_success(array(
		'locations' => $locations,
		'currentLatLon' => $currentLatLon,
		'currentRadial' => $map_radial,
		'html' => $output, // If you want to send HTML back as well
	));
	wp_die();
}
add_action('wp_ajax_sort_posts_by_criteria', 'sort_posts_by_criteria');
add_action('wp_ajax_nopriv_sort_posts_by_criteria', 'sort_posts_by_criteria');

function haversineGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371)
{
	$latFrom = deg2rad($latitudeFrom);
	$lonFrom = deg2rad($longitudeFrom);
	$latTo = deg2rad($latitudeTo);
	$lonTo = deg2rad($longitudeTo);

	$latDelta = $latTo - $latFrom;
	$lonDelta = $lonTo - $lonFrom;

	$angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) +
		cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));

	$distanceInKm = $angle * $earthRadius;
	$distanceInMiles = $distanceInKm * 0.621371; // Convert kilometers to miles

	return $distanceInMiles;
}

// AJAX handler for get open now location ids
function open_now_locations_ids()
{
	$open_post_ids = array();

	$currentDateTime = new DateTime();
	$currentDateTime->setTimezone(new DateTimeZone('America/Chicago'));
	// $currentDateTime->setTimezone(new DateTimeZone('Asia/Calcutta'));
	$currentHourMinute = $currentDateTime->format('g:i a');
	$currentDay = $currentDateTime->format('l');

	$args = array(
		'post_type' => 'location',
		'post_status' => 'publish',
		'posts_per_page' => -1,
	);

	$query = new WP_Query($args);

	if ($query->have_posts()) {
		while ($query->have_posts()) {
			$query->the_post();
			$post_id = get_the_ID();
			$workingHours = get_field($currentDay, $post_id);

			if ($workingHours) {
				$startHour = strtotime($workingHours['hour']['start']);
				$endHour = strtotime($workingHours['hour']['end']);
				$startAfterHour = strtotime($workingHours['after_hour']['start']);
				$endAfterHour = strtotime($workingHours['after_hour']['end']);

				$currentTimestamp = strtotime($currentHourMinute);

				if (($currentTimestamp >= $startHour && $currentTimestamp <= $endHour) ||
					($currentTimestamp >= $startAfterHour && $currentTimestamp <= $endAfterHour)
				) {
					$open_post_ids[] = $post_id;
				}
			}
		}
		wp_reset_postdata();
	}
	echo json_encode($open_post_ids);
	wp_die();
}

add_action('wp_ajax_open_now_locations_ids', 'open_now_locations_ids');
add_action('wp_ajax_nopriv_open_now_locations_ids', 'open_now_locations_ids');



//=======================================
// Providers Functions
//=======================================
function get_locations_metafields_to_ids($meta_key, $filter, $search)
{
	global $wpdb;
	$meta_key = esc_sql($meta_key);
	$search = esc_sql($search);
	$query = "SELECT DISTINCT post_id
              FROM {$wpdb->postmeta}
              WHERE meta_key = '{$meta_key}'
              AND meta_value LIKE '%{$search}%';";
	$results = $wpdb->get_col($query);
	return $results;
}

function providers_data_get($search, $paged)
{
	$provider_result = isset($search) ? sanitize_text_field($search) : '';
	echo $provider_result;
	$provider_res = '';
	$paged = isset($paged) ? sanitize_text_field($paged) : 1;
	if ($provider_result) {
		global $wpdb;
		$sql = $wpdb->prepare("
		SELECT DISTINCT p.ID as post_id, p.post_title
		FROM {$wpdb->posts} p
		LEFT JOIN {$wpdb->postmeta} pm_city ON p.ID = pm_city.post_id AND pm_city.meta_key = 'city'
		LEFT JOIN {$wpdb->postmeta} pm_zip ON p.ID = pm_zip.post_id AND pm_zip.meta_key = 'zipcode'
		WHERE (p.post_title LIKE %s
		OR pm_city.meta_value LIKE %s
		OR pm_zip.meta_value LIKE %s)
		AND p.post_type = 'location'
		AND p.post_status = 'publish'
	", '%' . $wpdb->esc_like($provider_result) . '%', '%' . $wpdb->esc_like($provider_result) . '%', '%' . $wpdb->esc_like($provider_result) . '%');

		$provider_res = $wpdb->get_results($sql);
		$location_ids = array();
		foreach ($provider_res as $result) {
			$location_ids[] = $result->post_id;
		}
	}
	$args_providers = array(
		'post_type'      => 'provider',
		'post_status'    => 'publish',
		'posts_per_page' => 12,
		'paged' => $paged,
		// 'orderby' => 'title',
		// 'order'   => 'ASC',
		'meta_key' => 'last_name',
		'orderby' => 'meta_value',
		'order'   => 'ASC',
		'meta_query'     => array(),
	);
	if ($provider_res) {
		$meta_query = array('relation' => 'OR');
		foreach ($location_ids as $location_id) {
			$meta_query[] = array(
				'key'     => 'location',
				'value'   => $location_id,
				'compare' => 'LIKE',
			);
		}
		$args_providers['meta_query'] = $meta_query;
	} else {
		$args_providers['s'] = $provider_result;
	}

	$query_providers = new WP_Query($args_providers);
	$last_page = ($query_providers->found_posts > 0 && $query_providers->post_count > 0) ? ceil($query_providers->found_posts / $query_providers->post_count) : 1;


	if ($query_providers->have_posts()) {
		while ($query_providers->have_posts()) {
			$query_providers->the_post();
			if ($query_providers->post_count == 1) {
				$link = get_the_permalink();
				header("location:" . $link . "");
			}
			get_template_part('template-parts/content', 'provider');
		}
	} else {
		echo '<p>The record does not exist for the selected criteria.</p>';
	}
	wp_reset_postdata();
	return $last_page;
}

function provider_load_more_posts()
{
	check_ajax_referer('provider_loadmore', 'security');

	$search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
	$page = isset($_POST['page']) ? absint($_POST['page']) : 1;
	ob_start();
	$last_page = providers_data_get($search, $page);
	$output = ob_get_clean();

	if ($output) {
		$response = array(
			'page' => $page,
			'last_page' => $last_page,
			'html' => $output,
		);
		wp_send_json_success($response);
	} else {
		wp_send_json_error();
	}

	wp_die();
}

add_action('wp_ajax_provider_loadmore', 'provider_load_more_posts');
add_action('wp_ajax_nopriv_provider_loadmore', 'provider_load_more_posts');


// function update_all_media_alt_tags()
// {
// 	$args = array(
// 		'post_type' => 'attachment',
// 		'post_status' => 'inherit',
// 		'posts_per_page' => -1
// 	);

// 	$attachments = new WP_Query($args);

// 	if ($attachments->have_posts()) {
// 		while ($attachments->have_posts()) {
// 			$attachments->the_post();
// 			$attachment_id = get_the_ID();
// 			$image_meta = wp_get_attachment_metadata($attachment_id);
// 			$image_title = get_the_title($attachment_id);
// 			$alt_text = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);

// 			if (empty($alt_text)) {
// 				$alt_text = $image_title; // You can customize the alt text here
// 				update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);
// 			}
// 		}
// 	}
// }

// update_all_media_alt_tags();





function load_more_providers_by_city_zip()
{
	session_start();

	$providerIds = isset($_SESSION['open_post_ids']) ? $_SESSION['open_post_ids'] : array();
	$page = isset($_POST['page']) ? absint($_POST['page']) : 1;
	$search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
	$args_provi = array(
		'post_type'      => 'provider',
		'post_status'    => 'publish',
		'posts_per_page' => get_option('posts_per_page'),
	);

	if ($search && $providerIds) {
		$args_provi['post__in'] = $providerIds[$page];
		$args_provi['orderby'] = 'post__in';
	} else {
		$args_provi['paged'] = $page + 1;
		$args_provi['meta_key'] = 'last_name';
		$args_provi['orderby'] = 'meta_value';
		$args_provi['order'] = 'ASC';
	}

	$args_provi_loop = new WP_Query($args_provi);
	if ($args_provi_loop->have_posts()) {
		while ($args_provi_loop->have_posts()) {
			$args_provi_loop->the_post();
			if ($args_provi_loop->post_count == 1) {
				$link = get_the_permalink();
				header("location:" . $link . "");
			}
			get_template_part('template-parts/content', 'provider');;
		}
		wp_reset_postdata();
	} else {
		wp_send_json_error('No providers found.');
	}

	wp_die();
}

add_action('wp_ajax_load_more_provi', 'load_more_providers_by_city_zip');
add_action('wp_ajax_nopriv_load_more_provi', 'load_more_providers_by_city_zip');




function get_providers_posts_ids()
{
	$user_lat = isset($_POST['lat']) ? floatval($_POST['lat']) : null;
	$user_lon = isset($_POST['lon']) ? floatval($_POST['lon']) : null;

	$argsLoc = array(
		'post_type' => 'location',
		'post_status' => 'publish',
		'posts_per_page' => -1
	);
	$queryLoc = new WP_Query($argsLoc);
	$locations = array();
	while ($queryLoc->have_posts()) : $queryLoc->the_post();
		$post = $queryLoc->post;
		$location_lat = get_field('latitude', $post->ID);
		$location_lng = get_field('longitude', $post->ID);
		$locations[] = array(
			'title' => get_the_ID(),
			'latitude'  => $location_lat,
			'longitude' => $location_lng,
		);
	endwhile;
	wp_reset_postdata();

	foreach ($locations as $key => $location) {
		$distance = haversineGreatCircleDistance($user_lat, $user_lon, $location['latitude'], $location['longitude']);
		$locations[$key]['distance'] = $distance;
	}
	usort($locations, function ($a, $b) {
		return $a['distance'] <=> $b['distance'];
	});

	global $wpdb;
	$providers_results = array();
	$providers = array();
	foreach ($locations as $key => $location) {
		$search = esc_sql($location["title"]);
		$sql = "SELECT p.*, pm.meta_value AS location
            FROM {$wpdb->prefix}posts p
            LEFT JOIN {$wpdb->prefix}postmeta pm ON p.ID = pm.post_id
            WHERE p.post_type = 'provider'
            AND p.post_status = 'publish'
            AND pm.meta_key = 'location'
            AND pm.meta_value LIKE '%$search%' 
            ORDER BY pm.meta_value ASC";

		$providers_results[] = $wpdb->get_results($sql);
	}
	$providers = array_merge(...$providers_results);
	if (!empty($providers)) {
		foreach ($providers as $provider) {
			$providerIds[] = $provider->ID;
		}
	}
	$args_ppp = array(
		'post_type'      => 'provider',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'post__in' => $providerIds,
		'orderby' => 'post__in'
	);
	$queryPP = new WP_Query($args_ppp);
	$open_post_ids = array();
	$chunks = array();
	if ($queryPP->have_posts()) {
		while ($queryPP->have_posts()) {
			$queryPP->the_post();
			$open_post_ids[] = get_the_ID();
		}
		wp_reset_postdata();
	}
	$chunks = array_chunk($open_post_ids, get_option('posts_per_page'));

	$_SESSION['open_post_ids'] = array();
	session_start();
	$_SESSION['open_post_ids'] = $chunks;
	echo json_encode($chunks);
	wp_die();
}

add_action('wp_ajax_get_providers_ids', 'get_providers_posts_ids');
add_action('wp_ajax_nopriv_get_providers_ids', 'get_providers_posts_ids');


