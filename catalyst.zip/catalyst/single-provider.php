<?php
get_header();
$path = get_stylesheet_directory_uri();
$noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';
$logoIcon = get_stylesheet_directory_uri() . '/img/logo-icon.svg';
$profile_img = get_the_post_thumbnail_url();
$profile_title = get_the_title();

$location = get_field('location');
$info = get_field('info');
$education = get_field('education');
$degree = get_field('degree');
$specialty = get_field('specialty');
$languages = get_field('languages');
$review_zero = get_field('review_zero');

$phone_number = get_field('phone_number');
$second_phone_number = get_field('second_phone_number');

$book_online_link = get_field('book_online_link');
$book_online_link_2 = get_field('book_online_link_second');

// $patient_portal_link = get_field('patient_portal_link');
$patient_portal_link = get_field('patient_portal_link', 'option');


$professional_organizations = get_field('professional_organizations');
$provider_video_link = get_field('provider_video_link');
$dr_name = ((empty($profile_title) ? '' : $profile_title) . (', ' . empty($degree) ? '' : $degree));;



$select_display_reviews = get_field('select_display_reviews');
$reviewActive = '';
// if ($select_display_reviews == 'elfsight') {
$elfsight_reviews = get_field('elfsight_reviews');
if (!$review_zero) {
    if ($elfsight_reviews) {
        $reviewActive = $elfsight_reviews;
    } else {
        $reviewActive = '';
    }
}

// }

// if ($select_display_reviews == 'google') {
//     $placeId = get_field('place_id', get_the_ID());
//     $places_details = fetch_google_place_details();
//     $rating = $places_details[$placeId]['rating'];
//     $ratingTotal = $places_details[$placeId]['user_ratings_total'];
//     if (!empty($rating) && $rating !== 'N/A') {
//         $reviewActive = '
//     Rating&nbsp;<b class="rating">' . $rating . '</b> <span class="star-rating"><span style="width:' . ($rating * 100 / 5) . '%"></span></span> ' . $ratingTotal . ' Reviews';
//     } else {
//         $reviewActive = '';
//     }
// }





if ($location != null) {
    $loc_logo = get_field('clinic_logo', $location['0']);
    $loc_logo_final = get_term_meta($loc_logo, 'small_logo', true);

    $loc_title = get_the_title($location['0']);
    $loc_address = get_field('address', $location['0']);
    $loc_city = get_field('city', $location['0']);
    $loc_state = get_field('state', $location['0']);
    $loc_zipcode = get_field('zipcode', $location['0']);
    $loc_full_address = $loc_title; //((empty($loc_title) ? '' : $loc_title . ' ') . (empty($loc_address) ? '' : $loc_address . ' ') . (empty($loc_city) ? '' : $loc_city . ', ') . (empty($loc_state) ? '' : $loc_state . ', ') . (empty($loc_zipcode) ? '' : $loc_zipcode));
}
?>
<section class="bio-sec">
    <div class="container-fluid">
        <div class="bio-inner">
            <div class="row align-items-center flex-row-reverse">
                <div class="col-sm-12 col-lg-6">
                    <div class="profile-box">
                        <div class="profile wow animate__fadeInUp" data-wow-delay="0.1s">
                            <img class="profile-img" src="<?php echo ($profile_img != '') ? $profile_img : $noImg; ?>" alt="<?php echo $dr_name; ?>">
                            <?php if (!empty($loc_logo)) : ?>
                                <div class="profile-info-img">
                                    <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if ($dr_name != '') : ?>
                            <h3 class="profile-title wow animate__fadeInUp" data-wow-delay="0.3s"><?php echo $dr_name; ?><?php echo ', ' . $degree ?></h3>
                        <?php endif; ?>
                        <?php
                        if ($reviewActive != '') : ?>
                            <div class="profile-rate">
                                <?php echo $reviewActive; ?>
                            </div>
                        <?php endif; ?>

                        <?php
                        $locationCount = count($location); ?>
                        <?php if ($locationCount >= '2') :
                            $locationData = array();

                            foreach ($location as $locationIndex => $locationID) {
                                $locationBind = $locationIndex + 1;
                                $loc_title = get_the_title($locationID);
                                $loc_address = get_field('address', $locationID);
                                $loc_city = get_field('city', $locationID);
                                $loc_state = get_field('state', $locationID);
                                $loc_zipcode = get_field('zipcode', $locationID);
                                $loc_phone = get_field('phone', $locationID);

                                $loc_full_address = ((empty($loc_title) ? '' : $loc_title . ' ') . (empty($loc_address) ? '' : $loc_address . ' ') . (empty($loc_city) ? '' : $loc_city . ', ') . (empty($loc_state) ? '' : $loc_state . ', ') . (empty($loc_zipcode) ? '' : $loc_zipcode));

                                $locationDataItem = array(
                                    'phone' => $loc_phone,
                                    'address' => $loc_full_address
                                );

                                // Check if the phone number already exists in the array
                                $existingPhone = array_filter($locationData, function ($item) use ($loc_phone) {
                                    return $item['phone'] == $loc_phone;
                                });

                                if (empty($existingPhone)) {
                                    // Add the location data to the array
                                    $locationData[] = $locationDataItem;
                                }
                            }
                            $locationDataCount = count($locationData);
                            if ($locationDataCount == 1) {
                                foreach ($locationData as $locationDatum) { ?>
                                    <div class="profile-btns wow animate__fadeInUp" data-wow-delay="0.5s">
                                        <a href="tel:<?php echo str_replace(array(' ', '-'), '', $locationDatum['phone']); ?>" title="Call Now" class="btn btn-outline-orange">Call: <?php echo $locationDatum['phone']; ?></a>
                                    </div>
                                <?php }
                            } else {
                                ?>
                                <div class="profile-btns style-2 wow animate__fadeInUp" data-wow-delay="0.5s">
                                    <button title="Book Online Now" class="btn btn-outline-orange mx-auto btn-dropdown-booknow">Call Now</button>
                                    <div class="profile-btn-dropdown">
                                        <?php
                                        foreach ($locationData as $locationDatum) {
                                        ?>
                                            <a href="tel:<?php echo str_replace(array(' ', '-'), '', $locationDatum['phone']); ?>" title="Call Now">
                                                <span><?php echo $locationDatum['address']; ?></span>
                                                <b class="d-block"><?php echo $locationDatum['phone']; ?></b>
                                            </a>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php
                            }  ?>

                        <?php else : ?>
                            <?php $loc_phone = get_field('phone', $location['0']);
                            if (!empty($loc_phone)) : ?>
                                <div class="profile-btns wow animate__fadeInUp" data-wow-delay="0.5s">
                                    <a href="tel:<?php echo str_replace(array(' ', '-'), '', $loc_phone); ?>" title="Call Now" class="btn btn-outline-orange">Call: <?php echo $loc_phone; ?></a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if (!empty($book_online_link_2)) : ?>
                            <div class="profile-btns wow animate__fadeInUp" data-wow-delay="0.5s">
                                <button title="Book Online Now" class="btn btn-orange mx-auto btn-dropdown-booknow">Book Online</button>
                                <div class="profile-btn-dropdown">
                                    <?php if (!empty($book_online_link)) : ?>
                                        <a href="<?php echo $book_online_link['url']; ?>" target="<?php echo ($book_online_link['target'] != '') ? $book_online_link['target'] : '_self'; ?>" title="<?php echo get_the_title($location[0]); ?>"><?php echo get_the_title($location[0]); ?></a>
                                    <?php endif; ?>
                                    <?php //if (!empty($book_online_link_2)) : ?>
                                        <a href="<?php echo $book_online_link_2['url']; ?>" target="<?php echo ($book_online_link_2['target'] != '') ? $book_online_link_2['target'] : '_self'; ?>" title="<?php echo get_the_title($location[1]); ?>"><?php echo get_the_title($location[1]); ?></a>
                                    <?php //endif; ?>
                                </div>
                            </div>
                        <?php else : ?>
                            <?php if (!empty($book_online_link)) : ?>
                                <div class="profile-btns wow animate__fadeInUp" data-wow-delay="0.5s">
                                    <a href="<?php echo $book_online_link['url']; ?>" target="<?php echo ($book_online_link['target'] != '') ? $book_online_link['target'] : '_self'; ?>" title="Book Online Now" class="btn btn-orange">Book Online</a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>



                        <?php /*if (!empty($book_online_link)) : ?>
                            <div class="profile-btns  wow animate__fadeInUp" data-wow-delay="0.5s">
                                <a href="<?php echo $book_online_link['url']; ?>" target="<?php echo ($book_online_link['target'] != '') ? $book_online_link['target'] : '_self'; ?>" title="Book Online Now" class="btn btn-orange mx-auto">Book Online</a>
                            </div>
                        <?php endif; */ ?>

                        <?php
                        if ($location != null) :
                            $locationtitle = '';
                            $uniqueLocations = array();
                            foreach ($location as $locationIndex => $locationID) {
                                $multiple_address_in_one = get_the_title($locationID);
                                $parts = explode(', ', $multiple_address_in_one);
                                $currentTitle = $parts[0];
                                if (!empty($parts[1])) {
                                    $currentLocation = $parts[1];
                                } else {
                                    $currentLocation = '';
                                }
                                if ($locationtitle === $currentTitle) {
                                    $uniqueLocations[count($uniqueLocations) - 1] .= ' and ' . $currentLocation;
                                } else {
                                    $locationtitle = $currentTitle;
                                    $uniqueLocations[] = $multiple_address_in_one;
                                }
                            }
                            $joinedString = implode(' and ', $uniqueLocations);
                            echo '<p class="wow animate__fadeInUp" data-wow-delay="0.2s">' . $joinedString . '</p>';
                        endif;
                        /* MEHUL - 16-7-24
                        $locationCount = count($location);
                        if ($locationCount >= 2) {
                            $addressDisplayed = false; // Flag to track if an address has been displayed

                            foreach ($location as $locationIndex => $locationID) {
                                $multiple_address_in_one = get_field('multiple_address_in_one', $locationID);
                                if (!empty($multiple_address_in_one)) {
                                    echo '<p class="wow animate__fadeInUp" data-wow-delay="0.2s">' . $multiple_address_in_one . '</p>';
                                    $addressDisplayed = true;
                                    break; // Display only the first found address
                                }
                            }
                            if (!$addressDisplayed && !empty($loc_title)) {
                                echo '<p class="wow animate__fadeInUp" data-wow-delay="0.2s">' . $loc_title . '</p>';
                            }
                        } elseif (!empty($loc_title)) {
                            echo '<p class="wow animate__fadeInUp" data-wow-delay="0.2s">' . $loc_title . '</p>';
                        }
                        */
                        ?>
                    </div>
                </div>
                <div class="col-sm-12 col-lg-6">
                    <div class="bio-con">
                        <div class="sec-head">
                            <?php if ($dr_name != '') : ?>
                                <h1 class="sec-title  wow animate__fadeInUp" data-wow-delay="0.1s"><?php echo $dr_name; ?><?php echo ', ' . $degree ?></h1>
                            <?php endif; ?>
                            <?php if ($info != '') : ?>
                                <p class=" wow animate__fadeInUp" data-wow-delay="0.2s"><?php echo $info; ?></p>
                            <?php endif; ?>
                            <?php if (!empty($patient_portal_link)) : ?>
                                <a href="<?php echo $patient_portal_link['url']; ?>" target="<?php echo ($patient_portal_link['target'] != '') ? $patient_portal_link['target'] : '_self'; ?>" title="Patient Portal" class="btn btn-yellow wow animate__fadeInUp" data-wow-delay="0.3s">Patient Portal</a>
                            <?php endif; ?>
                        </div>
                        <?php if ($education !== '' || $degree !== '' || $specialty !== '' || $languages !== '') : ?>
                            <ul class="bio-info  wow animate__fadeInUp" data-wow-delay="0.4s">
                                <?php if ($education != '') : ?>
                                    <li>
                                        <span>Education:</span>
                                        <?php echo $education; ?>
                                    </li>
                                <?php endif; ?>
                                <?php if ($degree != '') : ?>
                                    <li>
                                        <span>Degree:</span>
                                        <?php echo $degree; ?>
                                    </li>
                                <?php endif; ?>
                                <?php if ($specialty != '') : ?>
                                    <li>
                                        <span>Specialty:</span>
                                        <?php echo $specialty; ?>
                                    </li>
                                <?php endif; ?>
                                <?php if ($languages != '') : ?>
                                    <li>
                                        <span>Languages:</span>
                                        <?php echo $languages; ?>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if (have_rows('professional_organizations')) : ?>
    <section class="professional-organizations-sec pt-0">
        <div class="container-fluid">
            <div class="professional-title wow animate__fadeInUp" data-wow-delay="0.1s">Professional Organizations</div>
            <ul class="professional-list">
                <?php while (have_rows('professional_organizations')) : the_row();
                    $organization = get_sub_field('organization');
                    if ($organization != '') : ?>
                        <li class=" wow animate__fadeInUp" data-wow-delay="<?php echo get_row_index() / 10 ?>s">
                            <div class="professional-box"><?php echo $organization; ?></div>
                        </li>
                <?php endif;
                endwhile; ?>
            </ul>
        </div>
    </section>
<?php endif; ?>

<?php
if ($location != null) :
    $locationCount = count($location); ?>
    <section class="bio-location-sec">
        <div class="container-fluid">
            <div class="row flex-row-reverse align-items-center">
                <div class="col-md-12 col-lg-7 col-xl-8">
                    <div id="map" class="provider-map"></div>
                </div>
                <div class="col-md-12 col-lg-5 col-xl-4">
                    <?php if ($locationCount >= '2') : ?>
                        <ul class="nav nav-pills" id="location-tab">
                            <?php
                            foreach ($location as $locationIndex => $locationID) {
                                $locationBind = $locationIndex + 1;
                            ?>
                                <li class="nav-item">
                                    <button class="select-location nav-link <?php echo ($locationBind == 1) ? 'active' : ''; ?> " id="location-<?php echo $locationBind; ?>-tab" data-bs-toggle="pill" data-bs-target="#location-<?php echo $locationBind; ?>">Location <?php echo $locationBind; ?></button>
                                </li>
                            <?php
                            }
                            ?>
                        </ul>
                    <?php endif; ?>
                    <?php if ($locationCount >= '2') : ?>
                        <div class="tab-content" id="location-tabContent">
                        <?php endif; ?>

                        <?php
                        foreach ($location as $locationIndex => $locationID) {
                            $locationBind = $locationIndex + 1;
                            $loc_title = get_the_title($locationID);
                            $loc_address = get_field('address', $locationID);
                            $loc_city = get_field('city', $locationID);
                            $loc_state = get_field('state', $locationID);
                            $loc_zipcode = get_field('zipcode', $locationID);
                            $loc_phone = get_field('phone', $locationID);
                            $loc_fax = get_field('fax', $locationID);
                            $opening_hours = get_field('opening_hours', $locationID);

                            $loc_full_address = ((empty($loc_title) ? '' : $loc_title . '<br>') . (empty($loc_address) ? '' : $loc_address . '<br>') . (empty($loc_city) ? '' : $loc_city . ', ') . (empty($loc_state) ? '' : $loc_state . ' ') . (empty($loc_zipcode) ? '' : $loc_zipcode));
                            $location_data = get_location_data($post, $locationID);
                            $locations[] = $location_data;

                        ?>
                            <div class="tab-pane fade <?php echo ($locationBind == 1) ? 'show active' : ''; ?>" id="location-<?php echo $locationBind; ?>">
                                <div class="bio-location-details">
                                    <?php if (!empty($loc_full_address)) : ?>
                                        <div class="loc-row location-del <?php echo ($locationBind == 1) ? 'wow animate__fadeInUp" data-wow-delay="0.1s' : ''; ?>">
                                            <div class="loc-icon">
                                                <img src="<?php echo $path; ?>/assets/img/location-icon.svg" alt="location-icon">
                                            </div>
                                            <div class="loc-dtl">
                                                <div class="loc-dtl-title">Location:</div>
                                                <span><?php echo $loc_full_address; ?></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($loc_phone) || !empty($loc_fax)) : ?>
                                        <div class="loc-row  <?php echo ($locationBind == 1) ? 'wow animate__fadeInUp" data-wow-delay="0.2s' : ''; ?>">
                                            <div class="loc-icon">
                                                <img src="<?php echo $path; ?>/assets/img/phone-icon.svg" alt="phone-icon">
                                            </div>
                                            <div class="loc-dtl">
                                                <?php if (!empty($loc_phone)) : ?>
                                                    <div class="loc-dtl-title">Phone:</div>
                                                    <a href="tel:<?php echo str_replace(array(' ', '-'), '', $loc_phone); ?>" title="Call Now"><?php echo $loc_phone; ?></a> <br>
                                                <?php endif; ?>
                                                <?php if (!empty($loc_fax)) : ?>
                                                    <div class="loc-dtl-title">Fax:</div>
                                                    <a href="<?php echo $loc_fax; ?>"><?php echo $loc_fax; ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($loc_title) || !empty($opening_hours)) : ?>
                                        <div class="loc-row location-del <?php echo ($locationBind == 1) ? 'wow animate__fadeInUp" data-wow-delay="0.3s' : ''; ?>">
                                            <div class="loc-icon">
                                                <img src="<?php echo $path; ?>/assets/img/clock-icon.svg" alt="clock-icon">
                                            </div>
                                            <div class="loc-dtl location-detail-box">
                                                <div class="loc-dtl-title"><?php echo $loc_title; ?>:</div>
                                                <?php get_opening_hours($locationID); ?>
                                                <?php /*
                                                foreach ($opening_hours as $opening_hour => $hours) {
                                                    echo '<div class="time-row">';
                                                    echo '<span>' . $opening_hour . ':</span> ';
                                                    if (!empty($hours['hour'])) {
                                                        echo $hours['hour'] . '<br/>';
                                                        if (!empty($hours['after_hour'])) {
                                                            echo $hours['after_hour'];
                                                        }
                                                    } else {
                                                        echo 'Closed';
                                                    }
                                                    echo '</div>';
                                                }
                                                */ ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php
                        }
                        if ($locationCount >= '2') : ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if ($provider_video_link != '') : ?>
    <section class="providers-video-sec">
        <div class="container-fluid">
            <div class="sec-head text-center wow animate__fadeInUp" data-wow-delay="0.1s">
                <h2 class="sec-title">Provider Video</h2>
            </div>
            <div class="provider-video-sl wow animate__fadeInUp" data-wow-delay="0.2s">
                <div class="provider-video-box">
                    <iframe src="<?php echo $provider_video_link; ?>" width="100%" height="518" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if ($reviewActive != '') : ?>
    <section class="write-review-sec common-sec bio-write-review-sec position-relative pt-0">
        <div class="container-fluid">
            <div class="write-review-con style-2">
                <div class="write-review-box d-flex align-items-center justify-content-between">
                    <div class="write-left">
                        <div class="write-review-img">
                            <img src="<?php echo ($profile_img != '') ? $profile_img : $noImg; ?>" alt="doctor-review-profile">
                            <?php if (!empty($loc_logo)) : ?>
                                <div class="write-review-info-img">
                                    <?php echo wp_get_attachment_image($loc_logo_final, 'full'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if ($dr_name != '') : ?>
                            <div class="review-title"><?php echo $dr_name; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="loc_result">
                        <?php echo $reviewActive; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php
endif;

if ($location != null) {
?>
    <section class="insurance-sec bio-insurance-sec common-sec gray-bg">
        <div class="container">
            <div class="sec-head text-center">
                <div class="sec-title wow animate__fadeInUp">Insurance</div>
                <?php
                foreach ($location as $locationIndex => $locationID) {
                    $insurance_content = get_field('insurance_content', $locationID);
                    if ($insurance_content != '') {
                        echo '<p class="wow animate__fadeInUp" data-wow-delay=".1s">' . $insurance_content . '</p>';
                        break;
                    }
                }
                ?>
            </div>
            <div class="insurance-boxes">
                <div class="row justify-content-center align-items-center">
                    <?php
                    $displayed_terms = array();

                    foreach ($location as $locationIndex => $locationID) {
                        $insurance_cats = get_terms(array(
                            'taxonomy' => 'insurance_categories',
                            'object_ids' => $locationID,
                            'hide_empty' => false,
                        ));
                        if (!empty($insurance_cats) && !is_wp_error($insurance_cats)) {
                            foreach ($insurance_cats as $insurance_cat) {
                                if (!in_array($insurance_cat->term_id, $displayed_terms)) {
                                    $insurance_logo = get_field('logo', 'insurance_categories_' . $insurance_cat->term_id);
                                    if (!empty($insurance_logo)) { ?>
                                        <div class="col-lg-3 col-6">
                                            <div class="insurance-box wow animate__fadeInUp" data-wow-delay=".2s">
                                                <img src="<?php echo esc_url($insurance_logo['url']); ?>" alt="<?php echo esc_url($insurance_logo['alt']); ?>">
                                            </div>
                                        </div>
                    <?php $displayed_terms[] = $insurance_cat->term_id;
                                    }
                                }
                            }
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
<?php
}
get_footer();
?>


<script>
    (g => {
        var h, a, k, p = "The Google Maps JavaScript API",
            c = "google",
            l = "importLibrary",
            q = "__ib__",
            m = document,
            b = window;
        b = b[c] || (b[c] = {});
        var d = b.maps || (b.maps = {}),
            r = new Set,
            e = new URLSearchParams,
            u = () => h || (h = new Promise(async (f, n) => {
                await (a = m.createElement("script"));
                e.set("libraries", [...r] + "");
                for (k in g) e.set(k.replace(/[A-Z]/g, t => "_" + t[0].toLowerCase()), g[k]);
                e.set("callback", c + ".maps." + q);
                a.src = `https://maps.${c}apis.com/maps/api/js?` + e;
                d[q] = f;
                a.onerror = () => h = n(Error(p + " could not load."));
                a.nonce = m.querySelector("script[nonce]")?.nonce || "";
                m.head.append(a)
            }));
        d[l] ? console.warn(p + " only loads once. Ignoring:", g) : d[l] = (f, ...n) => r.add(f) && u().then(() => d[l](f, ...n))
    })
    ({
        key: "<?php echo get_field('google_api_key', 'option'); ?>",
        v: "beta"
    });
</script>
<script>
    async function initMap() {
        const locations = <?php echo json_encode($locations); ?>;

        const {
            Map,
            InfoWindow,
            Polygon
        } = await google.maps.importLibrary("maps");
        const {
            AdvancedMarkerElement
        } = await google.maps.importLibrary("marker");

        const styledMapType = new google.maps.StyledMapType(
            [{
                    "featureType": "administrative",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "landscape",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.attraction",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.business",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.business",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.business",
                    "elementType": "labels.icon",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "poi.government",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.school",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.school",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "road",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "road",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "off"
                    }]
                }
            ]
        );

        const map = new Map(document.getElementById("map"), {
            zoom: 12,
            center: locations[0].position,
            mapId: "DEMO_MAP_ID",
            streetViewControl: false,
            mapTypeControl: false,
            zoomControl: true,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_TOP,
            },
            fullscreenControl: false,
        });
        map.mapTypes.set("styled_map", styledMapType);
        map.setMapTypeId("styled_map");

        const infoWindow = new InfoWindow();

        const markers = locations.map(({
            position,
            title,
            imageUrl,
            url
        }, i) => {
            const markerImg = document.createElement("img");
            markerImg.src = "<?php echo $path; ?>/assets/img/marker.svg";
            markerImg.alt = `${title}`;
            markerImg.height = "30";

            const contentString = `
            <div class="mapSmallBox"><a href="${url}"><div class="map-place-img">
                <img src="${imageUrl}" alt="${title}" />
            </div>
            <div class="map-place-con">
                <h4 class="map-place-title">${title}</h4>
                <span class="map-place-link">View Location</span>
            </div></a></div>`;
            const marker = new AdvancedMarkerElement({
                position,
                map,
                title: title,
                content: markerImg,
                gmpClickable: false,
            });

            marker.addListener("gmp-click", () => {
                infoWindow.close();
                infoWindow.setContent(contentString);
                infoWindow.open(map, marker);
            });

            return {
                marker,
                position,
                contentString
            };
        });

        const allLocationsPaths = locations.map(location => location.position);
        document.querySelectorAll('.select-location').forEach((button, index) => {
            button.addEventListener('click', () => {
                const {
                    marker,
                    position,
                    contentString
                } = markers[index];
                map.setCenter(position);
                infoWindow.close();
                infoWindow.setContent(contentString);
                infoWindow.open(map, marker);
            });
        });
    }
    initMap();
</script>