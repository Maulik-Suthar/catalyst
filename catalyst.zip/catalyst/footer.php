<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package catalyst
 */
$path = get_stylesheet_directory_uri();
// $place_ids = get_locations_metafileds('location', 'place_id');
global $display_service_post;
?>

<footer class="footer-main">
	<div class="container-fluid">
		<div class="footer-top">
			<div class="row">
				<div class="col-sm-4">
					<a class="foot-logo" href="<?php echo site_url(); ?>" title="<?php echo bloginfo('name'); ?>">
						<?php
						$footer_logo = get_field('logo', 'option');
						if (!empty($footer_logo)) { ?>
							<img src="<?php echo $footer_logo['url']; ?>" alt="<?php echo bloginfo('name'); ?>">
						<?php } else { ?>
							<img src="<?php echo $path; ?>/assets/img/logo.svg" alt="<?php echo bloginfo('name'); ?>" />
						<?php } ?>
					</a>
				</div>
				<div class="col-sm-8">
					<div class="foot-right">
						<div class="foot-box quickLinks">
							<div class="footTitle">Company</div>
							<div class="footCon">
								<?php wp_nav_menu(array(
									'menu_id'        => 'company',
									'menu'            => 'Company',
									'container'       => '',
									'container_class' => 'footCon',
									'container_id'    => '',
									'menu_class'      => '',
									'menu_id'         => '',
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<ul>%3$s</ul>',
								)); ?>
							</div>
						</div>
						<div class="foot-box helpLinks">
							<div class="footTitle">Help</div>
							<div class="footCon">
								<?php wp_nav_menu(array(
									'menu_id'        => 'help',
									'menu'            => 'Help',
									'container'       => '',
									'container_class' => 'footCon',
									'container_id'    => '',
									'menu_class'      => '',
									'menu_id'         => '',
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<ul>%3$s</ul>',
								)); ?>
							</div>
							<button onclick="window.interdeal.a11y.openMenu()" class="accessibility-btn">Accessibility</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="copyright-sec">
			<div class="row align-items-center">
				<div class="col-sm-4 d-none	">
					<div class="social-media">
						<?php echo get_field('instagram', 'option') ? '<a class="instagram" target="_blank" href="' . get_field('instagram', 'option') . '"><span class="d-none">instagram</span><i class="icon icon-instagram"></i></a>' : ''; ?>
						<?php echo get_field('facebook', 'option') ? '<a class="fb" target="_blank" href="' . get_field('facebook', 'option') . '"><span class="d-none">facebook</span><i class="icon icon-facebook"></i></a>' : ''; ?>
						<?php echo get_field('linkedin', 'option') ? '<a class="linkedin" target="_blank" href="' . get_field('linkedin', 'option') . '"><span class="d-none">linkedin</span><i class="icon icon-linkedin"></i></a>' : ''; ?>
						<?php echo get_field('twitter', 'option') ? '<a class="twitter" target="_blank" href="' . get_field('twitter', 'option') . '"><span class="d-none">twitter</span><i class="icon icon-twitter-new"></i></a>' : ''; ?>
						<?php echo get_field('youtube', 'option') ? '<a class="youtube" target="_blank" href="' . get_field('youtube', 'option') . '"><span class="d-none">youtube</span><i class="icon icon-youtube"></i></a>' : ''; ?>
					</div>
				</div>
				<div class="col-sm-12">
					<p class="copright-text justify-content-center">
						&#169; <?php echo date('Y'); ?> <a href="<?php echo site_url(); ?>" title="<?php echo bloginfo('name'); ?>"> <?php echo bloginfo('name'); ?></a>. All rights reserved.
					</p>
				</div>
			</div>
		</div>
	</div>
</footer>


<svg width="0" height="0" class="hidden">
	<symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 653.38 859.99" id="arrow-up">
		<path d="M317.68.47C303.92,2.15,287.92,9,276.8,18.07c-3.2,2.56-62.88,61.84-132.72,131.76C6.8,287.27,11.84,281.91,5.76,296.63,1.36,307.19-.08,314.79,0,327.27c0,9.52.32,12.4,2.16,19.2a78.27,78.27,0,0,0,118.56,45.84c5.12-3.28,17.68-15.44,66.88-64.56l60.64-60.4.24,263.12.16,263.2,1.76,6.4c9,33.36,35.28,56.16,68.4,59.52a78,78,0,0,0,85-66.32c1-6.48,1.2-44.48,1.2-266.8V267.27l60.64,60.56c64.64,64.56,65.6,65.44,79,71,11.2,4.72,17.2,5.92,30,6,15.6.08,26.4-2.56,39-9.6,40.56-22.64,52.16-75.2,25.2-113.92C635,275.67,386.32,26.15,377,18.47,371.2,13.67,359.6,7,353.68,5,341.12.71,328.32-.89,317.68.47Z"></path>
	</symbol>
</svg>
<div class="back-to-top" aria-hidden="true">
	<div class="arrow">
		<svg class="arrow-up">
			<use xlink:href="#arrow-up"></use>
		</svg>
	</div>
	<div class="text">Back to top</div>
</div>



</div>

<div class="modal service-modal fade" id="serviceModal">
	<div class="modal-dialog modal-xl modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header border-0 p-0">
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body p-0">
				<div class="row g-0">
					<div class="col-lg-5">
						<div class="service-img-box">
							<img src="" alt="service-img">
						</div>
					</div>
					<div class="col-lg-7">
						<div class="service-modal-content">
							<div class="sec-head mb-0">
								<div class="sec-title"></div>
							</div>
							<div class="cms-con"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php wp_footer(); ?>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/slick.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/wow.min.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/swiper-bundle.min.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/sticksy.min.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/select2.min.js"></script>
<script type="text/javascript" src="<?php echo $path; ?>/assets/js/custom.js"></script>

<script>
	new WOW().init();

	jQuery(document).ready(function($) {
		$('.serviceBtn').click(function() {
			var title = $(this).prev('.sec-head').find('.sec-title').text();
			var content = $(this).prev('.sec-head').find('.cms-con').html();
			var imgSrc = $(this).parents('.services-row').find('img').attr('src');
			$('.modal').find('.sec-title').text(title);
			$('.modal').find('.cms-con').html(content);
			$('.modal').find('img').attr('src', imgSrc);
		});
	});


	<?php if (is_singular('post')) {
	?>
		jQuery(document).ready(function($) {
			var stickyEl = new Sticksy(".blog-details-recent", {
				topSpacing: $(".header-main").outerHeight(),
			});
		});
	<?php
	} elseif (get_the_ID() == "448" || get_the_ID() == "467") {
	?>
		jQuery(document).ready(function($) {
			var stickyE2 = new Sticksy(".item-list", {
				topSpacing: $(".header-main").outerHeight(),
			});
		});
	<?php
	} ?>
</script>

<script>
	window.interdeal = {
		"sitekey": "b8e611047474d6f2d65e0158e70e77bc",
		"Position": "Left",
		"Menulang": "EN",
		"domains": {
			"js": "https://urldefense.com/v3/__https://cdn.equalweb.com/__;!!DFOa6qJtBQ0!THypPtL8gd_CsezQwrd3EW74-3nGwaDIRxzgvtHrdDcW6GTKv0jwWr8JKk1wlrhxeadh0aQjZfg8gF9CuN_Y3Xa67Q$ ",
			"acc": "https://urldefense.com/v3/__https://access.equalweb.com/__;!!DFOa6qJtBQ0!THypPtL8gd_CsezQwrd3EW74-3nGwaDIRxzgvtHrdDcW6GTKv0jwWr8JKk1wlrhxeadh0aQjZfg8gF9CuN8zZiu_sA$ "
		},
		"btnStyle": {
			"vPosition": [
				"bottom-left",
				"bottom-left"
			],
			"scale": [
				"0.5",
				"0.5"
			],
			"color": {
				"main": "#363936",
				"second": "#ffffff"
			},
			"icon": {
				"type": 11,
				"shape": "circle"
			}
		}
	};
	(function(doc, head, body) {
		var coreCall = doc.createElement('script');
		coreCall.src = 'https://urldefense.com/v3/__https://cdn.equalweb.com/core/5.0.0/accessibility.js__;!!DFOa6qJtBQ0!THypPtL8gd_CsezQwrd3EW74-3nGwaDIRxzgvtHrdDcW6GTKv0jwWr8JKk1wlrhxeadh0aQjZfg8gF9CuN_CHncvqA$ ';
		coreCall.defer = true;
		coreCall.integrity = 'sha512-IxU4Ri4fE2rR9dl7NnxGj3DQGj5T21YWeqIVzymflYXFCrzXicaPBWRz2+p31fMI+vby7RG/3tqnu6etUOSQ6w==';
		coreCall.crossOrigin = 'anonymous';
		coreCall.setAttribute('data-cfasync', true);
		body ? body.appendChild(coreCall) : head.appendChild(coreCall);
	})(document, document.head, document.body);
</script>
</body>

</html>