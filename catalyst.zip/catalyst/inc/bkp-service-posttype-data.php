

function add_custom_taxonomies()
{
	register_taxonomy('service_category', 'service', array(
		'hierarchical' => true,
		'labels' => array(
			'name' => _x('Categories', 'taxonomy general name'),
			'singular_name' => _x('category', 'taxonomy singular name'),
			'search_items' =>  __('Search Categories'),
			'all_items' => __('All Categories'),
			'parent_item' => __('Parent category'),
			'parent_item_colon' => __('Parent category:'),
			'edit_item' => __('Edit category'),
			'update_item' => __('Update category'),
			'add_new_item' => __('Add New category'),
			'new_item_name' => __('New category Name'),
			'menu_name' => __('Categories'),
		),
		'rewrite' => array(
			'slug' => 'service-categories',
			'with_front' => true,
			'hierarchical' => true
		),
	));
}
add_action('init', 'add_custom_taxonomies', 0);



// Services post type
function service_register_post_type()
{
	$args = [
		'label'  => esc_html__('Services', 'catalyst'),
		'labels' => [
			'menu_name'          => esc_html__('Services', 'catalyst'),
			'name_admin_bar'     => esc_html__('Service', 'catalyst'),
			'add_new'            => esc_html__('Add Service', 'catalyst'),
			'add_new_item'       => esc_html__('Add new Service', 'catalyst'),
			'new_item'           => esc_html__('New Service', 'catalyst'),
			'edit_item'          => esc_html__('Edit Service', 'catalyst'),
			'view_item'          => esc_html__('View Service', 'catalyst'),
			'update_item'        => esc_html__('View Service', 'catalyst'),
			'all_items'          => esc_html__('All Services', 'catalyst'),
			'search_items'       => esc_html__('Search Services', 'catalyst'),
			'parent_item_colon'  => esc_html__('Parent Service', 'catalyst'),
			'not_found'          => esc_html__('No Services found', 'catalyst'),
			'not_found_in_trash' => esc_html__('No Services found in Trash', 'catalyst'),
			'name'               => esc_html__('Services', 'catalyst'),
			'singular_name'      => esc_html__('Service', 'catalyst'),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'hierarchical'        => true,
		'has_archive'         => true,
		'query_var'           => true,
		'menu_icon'           => 'dashicons-clipboard',
		'can_export'          => true,
		'rewrite'               => array('slug' => 'services', 'with_front' => true),
		'capability_type'       => 'post',
		'menu_position'       => 4,
		'supports' => [
			'title',
			'thumbnail',
			'excerpt',
		]
	];

	register_post_type('service', $args);
}

add_action('init', 'service_register_post_type');





$display_service_post = 4;
global $display_service_post;

// service loadmore data
function service_loadmore_function()
{
	global $display_service_post;
	$paged = $_POST['page'];
	if (is_tax()) {
		$category = get_queried_object();
		$category_id = $category->term_id;
		$args = array(
			'post_type' => 'service',
			'post_status' => 'publish',
			'posts_per_page' => $display_service_post,
			'paged' => $paged,
			'tax_query' => array(
				array(
					'taxonomy' => 'service_category',
					'field' => 'term_id',
					'terms' => $category_id
				)
			)
		);
	} else {
		$args = array(
			'post_type' => 'service',
			'post_status' => 'publish',
			'posts_per_page' => $display_service_post,
			'paged' => $paged,
		);
	}
	$loop = new WP_Query($args);
	while ($loop->have_posts()) : $loop->the_post();
		get_template_part('template-parts/content', 'service');
	endwhile;
	wp_reset_postdata();
	die();
}

add_action('wp_ajax_nopriv_service_loadmore_function', 'service_loadmore_function'); // for logged-out users
add_action('wp_ajax_service_loadmore_function', 'service_loadmore_function'); // for logged-in users




<script>
	jQuery(document).ready(function($) {
		var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
		var $loadMoreButton = $('#load-more-button');
		var currentPage = parseInt($loadMoreButton.attr("data-current-page"));
		var totalPosts = parseInt($loadMoreButton.attr("data-total-post"));
		var finalPostTotal = totalPosts - '<?php echo $display_service_post;  ?>'

		$loadMoreButton.on('click', function() {
			currentPage++;
			var data = {
				'action': 'service_loadmore_function',
				'page': currentPage
			};

			$.ajax({
				url: ajaxurl,
				data: data,
				type: 'POST',
				beforeSend: function(xhr) {
					$('.loader-wrapper').removeClass("d-none"); // Show loading overlay
				},
				success: function(response) {
					if (response) {
						console.log(response);
						console.log('end');
						$('#service-list').append(response); // Append new service items

						var $responseItems = $(response);
						var $resTotal = finalPostTotal - $responseItems.length
						if ($resTotal == 0) {
							$loadMoreButton.hide();
						}
					} else {
						$loadMoreButton.hide(); // Hide the load more button if no more posts
					}
				},
				error: function(xhr, status, error) {
					console.error('AJAX Error: ' + status + ' - ' + error);
				},
				complete: function() {
					$('.loader-wrapper').addClass("d-none"); // Hide loading overlay after AJAX completes
				}
			});
		});
	});
</script>