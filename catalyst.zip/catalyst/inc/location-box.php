<?php
function location_box_function($post, $postId) {
    $lat = get_field('latitude', $postId);
    $lng = get_field('longitude', $postId);
    $clinic_image = get_field('clinic_image', $postId);
    $noImg = get_stylesheet_directory_uri() . '/assets/img/no-img.jpg';

    $loc_title = get_the_title($postId);
    if ($clinic_image) {
        $first_image_url = $clinic_image[0]['url'];
    } else {
        $first_image_url = $noImg;
    }
    $location_url = get_permalink($postId);
    $location = array(
        'position' => array(
            'lat' => (float) $lat,
            'lng' => (float) $lng,
        ),
        'title' => $loc_title,
        'imageUrl' => $first_image_url,
        'url' => $location_url,
    );

    return $location;
}
?>
