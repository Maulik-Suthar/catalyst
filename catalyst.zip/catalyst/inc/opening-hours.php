<?php
function get_opening_hours($postId)
{
    $workingHours = array(
        'Monday' => get_field('Monday', $postId),
        'Tuesday' => get_field('Tuesday', $postId),
        'Wednesday' => get_field('Wednesday', $postId),
        'Thursday' => get_field('Thursday', $postId),
        'Friday' => get_field('Friday', $postId),
        'Saturday' => get_field('Saturday', $postId),
        'Sunday' => get_field('Sunday', $postId)
    );

    $has_after_hours = false;
    foreach ($workingHours as $day => $schedule) {
        if (!empty($schedule['after_hour']['start']) && !empty($schedule['after_hour']['end'])) {
            $has_after_hours = true;
            break;
        }
    }

    $has_opening_hours = false;
    foreach ($workingHours as $day => $schedule) {
        if (!empty($schedule['hour']['start']) && !empty($schedule['hour']['end'])) {
            $has_opening_hours = true;
            break;
        }
    }

    $has_holiday_hours = false;
    foreach ($workingHours as $day => $schedule) {
        if (empty($schedule['hour']['start']) && empty($schedule['hour']['end']) && empty($schedule['after_hour']['start']) && empty($schedule['after_hour']['end'])) {
            $has_holiday_hours = true;
            break;
        }
    }


?>
    <div class="accordion" id="hoursAccordian">
        <?php if ($has_opening_hours) { ?>
            <div class="accordion-item">
                <?php
                echo '<h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#hoursAccordian1" aria-expanded="false" aria-controls="hoursAccordian1">View Hours</button></h2>';
                echo "<div id='hoursAccordian1' class='accordion-collapse collapse show' data-bs-parent='#hoursAccordian'><div class='accordion-body'>";
                foreach ($workingHours as $day => $schedule) {
                    if (!empty($schedule['hour']['start']) && !empty($schedule['hour']['end'])) {
                        echo "<div class='time-row'>";
                        echo "<span>{$day}:</span>";
                        if (!empty($schedule['hour']['start']) && !empty($schedule['hour']['end'])) {
                            echo "{$schedule['hour']['start']} - {$schedule['hour']['end']}";
                        }
                        echo "</div>";
                    }
                }
                echo "</div></div>";
                ?>
            </div>
        <?php } ?>
        <?php if ($has_after_hours) { ?>
            <div class="accordion-item">
                <?php
                echo '<h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#hoursAccordian2" aria-expanded="false" aria-controls="hoursAccordian2">View After-hours</button></h2>';
                echo "<div id='hoursAccordian2' class='accordion-collapse collapse' data-bs-parent='#hoursAccordian'><div class='accordion-body'>";
                foreach ($workingHours as $day => $schedule) {
                    if (!empty($schedule['after_hour']['start']) && !empty($schedule['after_hour']['end'])) {
                        echo "<div class='time-row'>";
                        echo "<span>{$day}:</span>";
                        if (!empty($schedule['after_hour']['start']) && !empty($schedule['after_hour']['end'])) {
                            echo "{$schedule['after_hour']['start']} - {$schedule['after_hour']['end']}";
                        }
                        echo "</div>";
                    }
                }
                echo "</div></div>";
                ?>
            </div>
        <?php } ?>
        <?php /* if ($has_holiday_hours) { ?>
            <div class="accordion-item">
                <?php
                echo '<h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#hoursAccordian3" aria-expanded="false" aria-controls="hoursAccordian3">View Holiday-hours</button></h2>';
                echo "<div id='hoursAccordian3' class='accordion-collapse collapse' data-bs-parent='#hoursAccordian'><div class='accordion-body'>";
                foreach ($workingHours as $day => $schedule) {
                    if (empty($schedule['hour']['start']) && empty($schedule['hour']['end']) && empty($schedule['after_hour']['start']) && empty($schedule['after_hour']['end'])) {
                        echo "<div class='time-row'><span>{$day}:</span> ";
                        echo "Closed";
                        echo "</div>";
                    }
                }
                echo "</div></div>";
                ?>
            </div>
        <?php } */ ?>
    </div>
<?php
}
?>