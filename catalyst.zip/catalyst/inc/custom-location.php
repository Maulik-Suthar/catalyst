<?php
$mapApiKey = get_field('google_api_key', 'option');
$path = get_stylesheet_directory_uri();
$cities = get_locations_metafileds('location', 'city');
$zipcode = get_locations_metafileds('location', 'zipcode');

$location_cat = get_field('location', get_the_ID());

$meta_query = array(
    'relation' => 'AND'
);

if ($location_cat) {
    $meta_query[] = array(
        'key' => 'clinic_logo',
        'value' => $location_cat,
        'compare' => 'IN',
    );
}
?>

<section class="find-location-sec common-sec main-find-location-sec" id="location">
    <div class="container-fluid">
        <div class="sec-head">
            <h2 class="sec-title">
                View Our Locations
            </h2>
        </div>
        <div class="find-location-inr">
            <div class="row">
                <div class="col-xl-6">

                    <div class="find-location-nav">
                        <div class="find-location-nav-btns">
                            <button type="button" onclick="getLocation()" class="btn btn-outline-secondary nearBy">Near Me</button>
                            <button type="button" onclick="getOpenToday()" class="btn btn-outline-secondary openNow">Open Now</button>
                            <button type="button" onclick="mapClear()" class="btn btn-outline-secondary mapClearFunction" disabled>Clear</button>
                            <!-- <button type="button" onclick="getInsurance()" class="btn btn-outline-secondary insuranceAcc">Insurance Accepted</button> -->
                        </div>
                        <div id="locations-inputs">
                            <input type="hidden" id="user-lat" class="form-control" value="">
                            <input type="hidden" id="user-lon" class="form-control" value="">
                            <input type="hidden" id="user-open-now" value="">
                            <input type="hidden" id="user-insurance" value="">
                        </div>

                        <input type="hidden" id="user-cat" value="<?php echo $location_cat; ?>">

                        <!-- <button type="button" class="border-0 bg-transparent find-location-filter-btn">
                            <span class="d-none">Filter</span>
                            <i class="icon-filter-2"></i>
                        </button> -->
                        <div class="filter-dropdown">
                            <div class="filter-dropdown-item">
                                <input type="radio" name="filter_loc" id="filter_loc_1" value="loc_name" checked>
                                <label for="filter_loc_1">By Name</label>
                            </div>
                            <div class="filter-dropdown-item">
                                <input type="radio" name="filter_loc" id="filter_loc_3" value="loc_zipcode">
                                <label for="filter_loc_3">By Zip Code</label>
                            </div>
                            <div class="filter-dropdown-item">
                                <input type="radio" name="filter_loc" id="filter_loc_2" value="loc_city">
                                <label for="filter_loc_2">By City</label>
                            </div>
                        </div>
                    </div>
                    <div class="location-search-group row ">
                        <div class="col-sm-6">
                            <form class="find-location-filter " id="location-form">
                                <label class="invisible" for="select-location">Search By</label>
                                <select id="select-location" class="select2-multiple" multiple="multiple" required></select>
                                <button id="select-location-btn" type="submit" class="btn-square btn-blue" aria-label="Search">
                                    <span class="invisible">Search</span>
                                    <i class="icon-search-2"></i>
                                </button>
                            </form>
                        </div>
                        <div class="col-sm-6">
                            <form class="find-location-filter " id="location-zip-form">
                                <label class="invisible" for="select-location-zip">Search By city or zip</label>
                                <input id="select-location-zip" class="only-number" type="text" minlength="3" name="locationzip" placeholder="Search by city or zip">
                                <div id="zipcode-eroor" style="display:none">City or zip is invalid</div>
                                <button id="location-zip-btn" type="submit" class="btn-square btn-blue" aria-label="Search">
                                    <span class="invisible">Search</span>
                                    <i class="icon-search-2"></i>
                                </button>
                            </form>
                        </div>
                    </div>


                    <div id="location-wrapeer" class="find-location-bxs with-scrollbar">
                        <?php
                        $args = array(
                            'post_type'      => 'location',
                            'post_status' => 'publish',
                            'posts_per_page' => '-1',
                            'orderby' => 'title',
                            'order'   => 'ASC',
                            'meta_query' => $meta_query,
                        );
                        $loop = new WP_Query($args);
                        $post_titles = array();
                        if ($loop->have_posts()) {
                            while ($loop->have_posts()) : $loop->the_post();
                                get_template_part('template-parts/content', 'location');
                                $location_data = get_location_data($post, $post->ID);
                                $locations[] = $location_data;
                                $locations_data[] = get_the_title();
                            endwhile;
                            wp_reset_postdata();
                        }else{
                            echo '<p>No record found.</p>';
                        }
                        ?>
                    </div>
                </div>
                <div class="col-xl-6">
                    <input id="radial_map" type="hidden" value="50000" class="form-control">
                    <div id="map" class="gmap"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    (g => {
        var h, a, k, p = "The Google Maps JavaScript API",
            c = "google",
            l = "importLibrary",
            q = "__ib__",
            m = document,
            b = window;
        b = b[c] || (b[c] = {});
        var d = b.maps || (b.maps = {}),
            r = new Set,
            e = new URLSearchParams,
            u = () => h || (h = new Promise(async (f, n) => {
                await (a = m.createElement("script"));
                e.set("libraries", [...r] + "");
                for (k in g) e.set(k.replace(/[A-Z]/g, t => "_" + t[0].toLowerCase()), g[k]);
                e.set("callback", c + ".maps." + q);
                a.src = `https://maps.${c}apis.com/maps/api/js?` + e;
                d[q] = f;
                a.onerror = () => h = n(Error(p + " could not load."));
                a.nonce = m.querySelector("script[nonce]")?.nonce || "";
                m.head.append(a)
            }));
        d[l] ? console.warn(p + " only loads once. Ignoring:", g) : d[l] = (f, ...n) => r.add(f) && u().then(() => d[l](f, ...n))
    })
    ({
        key: "<?php echo $mapApiKey; ?>",
        v: "beta"
    });
</script>
<script>
    async function initMap(locationsArray, currentLatLon, currentRadial = 15000) {
        //console.log(locationsArray[0].position.lat);
        const locations = locationsArray ? locationsArray : '';


        if (currentLatLon && currentLatLon.length >= 2 && !(currentLatLon[0] === 0 && currentLatLon[1] === 0)) {
            centerCoordinates = {
                lat: currentLatLon[0],
                lng: currentLatLon[1]
            };
        } else {
            if (locations == '') {
                centerCoordinates = {
                    lat: 29.749907,
                    lng: -95.358421
                };
            } else {
                centerCoordinates = {
                    lat: locations[0].position.lat,
                    lng: locations[0].position.lng
                };
            }
        }

        const {
            Map,
            InfoWindow,
            Circle
        } = await google.maps.importLibrary("maps");
        const {
            AdvancedMarkerElement
        } = await google.maps.importLibrary("marker");

        const styledMapType = new google.maps.StyledMapType(
            [{
                    "featureType": "administrative",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "landscape",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.attraction",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.business",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.business",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.business",
                    "elementType": "labels.icon",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "poi.government",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.school",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "poi.school",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "road",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "on"
                    }]
                },
                {
                    "featureType": "road",
                    "elementType": "labels",
                    "stylers": [{
                        "visibility": "off"
                    }]
                }
            ]
        );

        const map = new Map(document.getElementById("map"), {
            zoom: getZoomLevelFromDistance(parseInt(currentRadial)),
            streetViewControl: false,
            mapTypeControl: false,
            zoomControl: true,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_TOP,
            },
            fullscreenControl: false,
            center: centerCoordinates,
            mapId: "DEMO_MAP_ID",
        });

        map.mapTypes.set("styled_map", styledMapType);
        map.setMapTypeId("styled_map");

        const infoWindow = new InfoWindow();

        if (locations !== '') {

            const markers = locations.map(({
                position,
                title,
                imageUrl,
                url
            }, i) => {
                const markerImg = document.createElement("img");
                markerImg.src = "<?php echo $path; ?>/assets/img/marker.svg";
                markerImg.alt = `${title}`;
                markerImg.height = "30";

                const contentString = `
      <div class="mapSmallBox"><a href="${url}"><div class="map-place-img">
          <img src="${imageUrl}" alt="${title}" />
      </div>
      <div class="map-place-con">
          <h4 class="map-place-title">${title}</h4>
          <span class="map-place-link">View Location</span>
      </div></a></div>`;

                // <span class="map-place-rating"><img src="/catalyst/wp-content/themes/catalyst/assets/img/star.svg" alt="star" /> 4.8</span>
                const marker = new AdvancedMarkerElement({
                    position,
                    map,
                    title: title,
                    content: markerImg,
                    gmpClickable: false,
                });

                marker.addListener("gmp-click", () => {
                    infoWindow.close();
                    infoWindow.setContent(contentString);
                    infoWindow.open(map, marker);
                });

                return {
                    marker,
                    position,
                    contentString
                };

            });


            document.querySelectorAll('.select-location').forEach((button, index) => {
                button.addEventListener('click', () => {
                    const {
                        marker,
                        position,
                        contentString
                    } = markers[index];
                    if (currentLatLon?.length > 0) {
                        if (currentLatLon[0] === 0 || currentLatLon[1] === 0) {
                            map.setCenter(position);
                        }
                    } else {
                        map.setCenter(position);
                    }
                    // if (!currentLatLon.length > 0) {
                    //     map.setCenter(position);
                    // }
                    infoWindow.close();
                    infoWindow.setContent(contentString);
                    infoWindow.open(map, marker);

                    // circle.setCenter(position);
                    // circle.setRadius(radius);
                    // adjustZoomLevel(map, circle);
                });
            });
        }

        let circle;
        // let radius = currentRadial; // 10km radius

        const selectedLocation = new google.maps.LatLng(currentLatLon[0], currentLatLon[1]);
        circle = new Circle({
            center: selectedLocation,
            radius: currentRadial,
            strokeColor: "#5E81F4",
            strokeOpacity: 1,
            strokeWeight: 2,
            fillColor: "#5E81F4",
            fillOpacity: 0.1,
            map: map,
            editable: true
        });

        // Add an event listener to update the circle when the user drags it
        circle.addListener("radius_changed", () => {
            currentRadial = circle.getRadius();
            //adjustZoomLevel(map, circle);
            jQuery('#radial_map').val(currentRadial);
            opentodayFunction();
        });
        let centerMapLoc;
        circle.addListener("center_changed", () => {
            centerMapLoc = circle.getCenter();
            const lat = centerMapLoc.lat();
            const lng = centerMapLoc.lng();
            jQuery('#user-lat').val(lat);
            jQuery('#user-lon').val(lng);
            opentodayFunction();
            jQuery('#select-location-zip').val('');
        });

        function getZoomLevelFromDistance(radius) {
            if (0 >= radius) {
                return 11;
            } else if (35000 >= radius) {
                return 10;
            } else if (70000 >= radius) {
                return 10;
            } else if (100000 >= radius) {
                return 8;
            } else {
                return 6;
            }
        }
    }
    const locationsArray = <?php echo json_encode($locations); ?>;
    const currentLatLon = [];
    const currentRadial = 50000;
    initMap(locationsArray, currentLatLon, currentRadial);
</script>

<script>
    jQuery(function($) {
        $('#locations-inputs input').val('');
        $('#select-location-zip').val('');
        $('#radial_map').val('50000');
        jQuery('.mapClearFunction').prop('disabled', true);
        $('#location input:radio[name=filter_loc][value=loc_name]').click();
        var locations_all_data = <?php echo json_encode($locations_data); ?>;
        //console.log(locations_all_data);
        // var locations_data = <?php //echo json_encode($locations_data); 
                                ?>;
        // var locations_city = <?php //echo json_encode($cities); 
                                ?>;
        // var locations_zip = <?php //echo json_encode($zipcode);  
                                ?>;


        var selectLocation2 = $('#select-location').select2({
            maximumSelectionLength: 1,
            placeholder: "Search by location",
            allowClear: false,
            minimumInputLength: 2,
        });
        selectLocation2.on("select2:open", function(e) {
            $(".select2-dropdown").addClass("d-none");
        });
        /*
        selectLocation2.on('change', function(e) {
            if (jQuery('#select-location').val() == '') {
                if ($('input[name="filter_loc"]:checked').val() == 'loc_city') {
                    $('#location-form textarea').attr('placeholder', 'Search by city');
                } else if ($('input[name="filter_loc"]:checked').val() == 'loc_zipcode') {
                    $('#location-form textarea').attr('placeholder', 'Search by zip code');
                } else {
                    $('#location-form textarea').attr('placeholder', 'Search by name');
                }
            }
        });
        */

        $(document).on("keyup", ".select2-search__field", function() {
            if ($(this).val().length >= 2) {
                $(".select2-dropdown").removeClass("d-none");
            } else {
                $(".select2-dropdown").addClass("d-none");
            }
        });
        const selectMultiple = $('#select-location');
        locations_all_data?.map((name) => {
            selectMultiple.append(new Option(name, name, false, false));
        });

        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const loc1 = urlParams.get('loc1');
        const loc2 = urlParams.get('loc2');

        const locations = urlParams.get('loc');
        if (locations) {
            const locationsArray = locations?.split(' ');
            selectMultiple.val(locationsArray).trigger('change');
            opentodayFunction();
        }


        /*
        $(document).on('change', 'input[name=filter_loc]', function(e) {
            $('.find-location-filter-btn').removeClass('active');
            selectMultiple.html('');
            jQuery('#select-location-zip').val('');
            if (e.target.defaultValue == 'loc_city') {
                $("#select-location-zip").addClass('d-none').prop('required', false);
                $('#location-form #select-location, #location-form .select2').show();
                $('#location-form #select-location').prop('required', true);
                locations_city?.map((name) => {
                    selectMultiple.append(new Option(name, name, false, false));
                });
                setTimeout(function() {
                    $('#location-form textarea').attr('placeholder', 'Search by city');
                }, 20);
            } else if (e.target.defaultValue == 'loc_zipcode') {
                // locations_zip?.map((name) => {
                //     selectMultiple.append(new Option(name, name, false, false));
                // });
                $("#select-location-zip").removeClass('d-none');
                $('#location-form #select-location, #location-form .select2').hide();
                $('#location-form #select-location').prop('required', false);
                setTimeout(function() {
                    $('#location-form textarea').attr('placeholder', 'Search by zip code');
                }, 20);
            } else {
                $("#select-location-zip").addClass('d-none').prop('required', false);
                $('#location-form #select-location, #location-form .select2').show();
                $('#location-form #select-location').prop('required', true);
                locations_data?.map((name) => {
                    selectMultiple.append(new Option(name.title, name.id, false, false));
                });
                setTimeout(function() {
                    $('#location-form textarea').attr('placeholder', 'Search by name');
                }, 20);
            }
        });
        */

        $('#location-form').on('submit', function(e) {
            e.preventDefault();
            jQuery('#select-location-zip').val('');
            jQuery('#user-lat').val('');
            jQuery('#user-lon').val('');
            var location_name = jQuery('#select-location').val();
            if (location_name != '') {
                opentodayFunction();
            }
        });

        $(document).on('click', '.select2-selection__choice__remove', function(e) {
            $('#select-location').select2('close');
            opentodayFunction();
        });


        $('#location-zip-form').on('submit', function(e) {
            e.preventDefault();
            var location_zip = jQuery('#select-location-zip').val();
            if (location_zip != '') {
                getLatLng(location_zip);
            }
        });


        const searchCityZip = urlParams.get('search');
        if (searchCityZip) {
            jQuery(window).scrollTop(jQuery("#location").offset().top - 70);
            jQuery('#select-location-zip').val(searchCityZip);
            jQuery('#location-zip-btn').trigger('click');
        }


    });

    function getLatLng(zipCode) {
        jQuery('#zipcode-eroor').hide();
        const apiKey = '<?php echo $mapApiKey; ?>';
        const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${zipCode}&key=${apiKey}`;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'OK') {
                    jQuery('.nearBy').removeClass('active');
                    const location = data.results[0].geometry.location;
                    jQuery('#user-lat').val(location.lat);
                    jQuery('#user-lon').val(location.lng);
                    jQuery('#select-location').val('');
                    jQuery('#location-form #select2-select-location-container li').remove();
                    opentodayFunction();
                    setTimeout(function() {
                        jQuery('#location-form textarea').attr('placeholder', 'Search by location');
                    }, 20);
                } else if (data.status === 'ZERO_RESULTS') {
                    jQuery('#zipcode-eroor').show();
                } else {
                    console.error('Geocode was not successful for the following reason:', data.status);
                }
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    function getLocation() {
        jQuery('.nearBy').toggleClass('active');
        if (jQuery('.nearBy').hasClass('active')) {
            jQuery('#select-location-zip').val('');
            // jQuery('#user-lat').val(23.05281196506666);
            // jQuery('#user-lon').val(72.46859478925782);
            // opentodayFunction();
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        var latitude = position.coords.latitude;
                        var longitude = position.coords.longitude;
                        jQuery('#user-lat').val(latitude);
                        jQuery('#user-lon').val(longitude);
                        opentodayFunction();
                    },
                    function(error) {
                        if (error.code === error.PERMISSION_DENIED) {
                            jQuery('.nearBy').removeClass('active');
                            alert('You have denied access to your location. Please enable location sharing to use this feature.');
                        } else {
                            jQuery('.nearBy').removeClass('active');
                            alert('Error getting geolocation: ' + error.message);
                        }
                    }
                );
            } else {
                jQuery('.nearBy').removeClass('active');
                alert("Geolocation is not supported by this browser.");
            }
        } else {
            jQuery('#user-lat').val('');
            jQuery('#user-lon').val('');
            opentodayFunction();
        }
    }

    function mapClearFunction(val) {
        if (val) {
            jQuery('.mapClearFunction').prop('disabled', true);
        } else {
            jQuery('.mapClearFunction').prop('disabled', false);
        }
    }

    function getOpenToday() {
        jQuery('.openNow').toggleClass('active');
        opentodayFunction();
    }

    function getInsurance() {
        jQuery('.insuranceAcc').toggleClass('active');
        opentodayFunction();
    }

    function mapClear() {
        if (jQuery('#select-location').val() != '' || jQuery('#select-location-zip').val() != '' || jQuery('.openNow').hasClass('active') || jQuery('.nearBy').hasClass('active')) {
            jQuery('#user-lat').val('');
            jQuery('#user-lon').val('');
            jQuery('#select-location').val('');
            jQuery('#select-location-zip').val('');
            jQuery('.nearBy').removeClass('active');
            jQuery('.openNow').removeClass('active');
            jQuery('#location-form #select2-select-location-container li').remove();
            setTimeout(function() {
                jQuery('#location-form textarea').attr('placeholder', 'Search by location');
            }, 20);
            opentodayFunction();
        }
    }


    function locationFilter(latitude, longitude, map_radial, openNow, insurance, location_name, location_cat, search_type) {
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action: 'sort_posts_by_criteria',
                lat: latitude,
                lon: longitude,
                map_radial: map_radial,
                sort_by_hours: openNow,
                sort_by_insurance: insurance,
                location_name: location_name,
                location_cat: location_cat,
                search_type: search_type

            },
            beforeSend: function() {
                jQuery('#location-wrapeer').addClass('loading');
            },
            success: function(response) {
                if (jQuery(window).width() > 1024) {
                    jQuery(".with-scrollbar").mCustomScrollbar("destroy");
                }
                var locations = response.data.locations;
                var currentLatLon = response.data.currentLatLon;
                var currentRadial = response.data.currentRadial;
                var html = response.data.html;
                jQuery('#location-wrapeer').html(html);
                if (jQuery(window).width() > 1024) {
                    jQuery(".with-scrollbar").mCustomScrollbar({
                        scrollbarPosition: "outside",
                        scrollInertia: 100,
                        mouseWheelPixels: 100
                    });
                }
                jQuery('#location-wrapeer').removeClass('loading');
                initMap(locations, currentLatLon, currentRadial);
                //console.log(currentLatLon);
            },
            error: function(errorThrown) {
                console.log('Error:', errorThrown);
            }
        });
    }




    function opentodayFunction() {
        var search_type = jQuery('input[name="filter_loc"]:checked').val();
        var location_name = jQuery('#select-location').val();
        var location_zip = jQuery('#select-location-zip').val();

        // if (jQuery('.nearBy').hasClass('active') || location_zip != '') {
        //     var latitude = jQuery('#user-lat').val();
        //     var longitude = jQuery('#user-lon').val();
        // } else {
        //     jQuery('#user-lat').val('');
        //     jQuery('#user-lon').val('');
        //     var latitude = '';
        //     var longitude = '';
        // }

        var latitude = jQuery('#user-lat').val();
        var longitude = jQuery('#user-lon').val();

        jQuery('#zipcode-eroor').hide();
        var insurance = jQuery('.insuranceAcc').hasClass('active') ? '1' : '';
        var location_cat = jQuery('#user-cat').val();
        jQuery('#user-insurance').val(insurance);
        var map_radial = jQuery('#radial_map').val();


        if (jQuery('#select-location').val() != '' || jQuery('#select-location-zip').val() != '' || jQuery('.openNow').hasClass('active') || jQuery('.nearBy').hasClass('active')) {
            mapClearFunction(false);
        } else {
            mapClearFunction(true);
        }

        if (jQuery('.openNow').hasClass('active')) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
            jQuery.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {
                    action: 'open_now_locations_ids',
                },
                success: function(response) {
                    var locationsIds = response;
                    locationFilter(latitude, longitude, map_radial, locationsIds, insurance, location_name, location_cat, search_type);
                },
                error: function(errorThrown) {
                    console.log('Error:', errorThrown);
                }
            });
        } else {
            locationFilter(latitude, longitude, map_radial, '0', insurance, location_name, location_cat, search_type);
        }

    }
</script>