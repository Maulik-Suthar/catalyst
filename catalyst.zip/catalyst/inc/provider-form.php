<?php
$mapApiKey = get_field('google_api_key', 'option');
$searchZip = isset($_GET['search']) ? esc_attr($_GET['search']) : '';
$searchProvider = isset($_GET['provider_name']) ? esc_attr($_GET['provider_name']) : '';


$args_providers = array(
    'post_type'      => 'provider',
    'post_status'    => 'publish',
    'posts_per_page' => -1,
);
$query_providers = new WP_Query($args_providers);
$provider_names = array();
while ($query_providers->have_posts()) {
    $query_providers->the_post();
    //$provider_names[] = get_the_title();
    $provider_names[] = array(
        'title'     => get_the_title(),
        'id'   => get_the_permalink(),
    );
}
wp_reset_postdata();

$args_location = array(
    'post_type'      => 'location',
    'post_status'    => 'publish',
    'posts_per_page' => -1,
);
$query_locations = new WP_Query($args_location);
$provider_locations = array();
while ($query_locations->have_posts()) {
    $query_locations->the_post();
    $provider_locations[] = get_the_title();
}
wp_reset_postdata();

$provider_cities = get_locations_metafileds('location', 'city');
$provider_zipcode = get_locations_metafileds('location', 'zipcode');


// $provider_all_data = array_merge($provider_names, $provider_locations, $provider_cities, $provider_zipcode);

?>

<?php
$formUrl = '';
if (is_front_page()) {
    $formUrl = site_url() . '/providers/';
}
?>

<div class="row">
    <!-- <form class="col-md-6" action="<?php //echo $formUrl; 
                                        ?>" method="get"> -->
    <form class="col-sm-6" id="formProviderName">
        <div class="filter-box wow animate__fadeInUp" data-wow-delay=".2s">
            <label for="select-providers" class="invisible">Search By</label>
            <select id="select-providers" name="provider_name" class="select2-multiple" multiple="multiple" required></select>
            <button id="searchButton" type="submit" class="btn-square btn-blue" aria-label="Search"><span class="invisible">Search</span><i class="icon-search"></i></button>
        </div>
    </form>
    <form class="col-sm-6" id="formCityZip">
        <div class="filter-box wow animate__fadeInUp" data-wow-delay=".2s">
            <label for="select-providers-zip" class="invisible">Search By</label>
            <input id="select-providers-zip" class="only-number w-100" name="search" type="text" minlength="3" name="providerszip" placeholder="Search by city or zip" required>
            <span id="provider-eroor" class="error-msg" style="display: none;">City or zip is invalid</span>
            <button id="searchButton" type="submit" class="btn-square btn-blue" aria-label="Search"><span class="invisible">Search</span><i class="icon-search"></i></button>
        </div>
    </form>
</div>


<script>
    jQuery(function($) {
        var provider_data = <?php echo json_encode($provider_names) ?>;
        //console.log(provider_data);
        $('#select-providers').select2({
            maximumSelectionLength: 1,
            placeholder: 'Search by provider',
            allowClear: false,
            minimumInputLength: 2,
        }).on("select2:open", function(e) {
            $(".select2-dropdown").addClass("d-none");
        });

        $(document).on("keyup", ".select2-search__field", function() {
            if ($(this).val().length >= 2) {
                $(".select2-dropdown").removeClass("d-none");
            } else {
                $(".select2-dropdown").addClass("d-none");
            }
        });

        const selectMultipleProvider = $('#select-providers');
        provider_data?.map((name) => {
            selectMultipleProvider.append(new Option(name.title, name.id, false, false));
        });

        // Parse query string
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const provider_name = urlParams.get('provider_name');
        const searchzip = urlParams.get('search');

        if (provider_name) {
            jQuery(window).scrollTop(jQuery("#providers").offset().top - 70);
            selectMultipleProvider.val('<?php echo $searchProvider; ?>').trigger('change');
        }

        if (searchzip) {
            jQuery(window).scrollTop(jQuery("#providers").offset().top - 70);
            jQuery('#select-providers-zip').val('<?php echo $searchZip; ?>').trigger('change');
        }


        $('#formCityZip').on('submit', function(e) {
            jQuery('#provider-eroor').hide();
            e.preventDefault();
            const apiKey = '<?php echo $mapApiKey; ?>';
            const searchLoc = jQuery('#select-providers-zip').val();
            const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${searchLoc}&key=${apiKey}`;
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'OK') {
                        const location = data.results[0].geometry.location;
                        get_providers_ids(searchLoc, location.lat, location.lng);
                    } else if (data.status === 'ZERO_RESULTS') {
                        jQuery('#provider-eroor').show();
                    } else {
                        console.error('Geocode was not successful for the following reason:', data.status);
                    }
                })
                .catch(error => console.error('Error fetching data:', error));

        });


        $('#formProviderName').on('submit', function(e) {
            e.preventDefault();
            const providerName = jQuery('#select-providers').val();
            window.location.href = providerName[0];
        });

    });

    function get_providers_ids(location, latitude, longitude) {
        jQuery.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            data: {
                action: 'get_providers_ids',
                lat: latitude,
                lon: longitude,
            },
            dataType: 'json',
            success: function(response) {
                if (response) {
                    if (jQuery('body').hasClass('home')) {
                        window.location.href = "<?php echo site_url(); ?>/locations?search=" + location + "";
                    } else {
                        window.location.href = "<?php echo site_url(); ?>/providers?search=" + location + "";
                    }
                }
            },
            error: function(xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    }
</script>